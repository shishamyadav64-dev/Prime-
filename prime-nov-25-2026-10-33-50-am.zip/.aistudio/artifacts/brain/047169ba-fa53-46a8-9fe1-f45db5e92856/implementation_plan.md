# PRIME — Dev Server Fix & Live Web Companion Studio

Restore the missing Node/Vite/Express dev server on port 3000 so the preview boots cleanly, and deliver a full-stack **PRIME** web experience alongside your preserved Android project—featuring an Obsidian & Champagne Gold executive workspace, Gemini-powered reasoning with tool execution, Custom Voice creation with Neural TTS, multimodal image analysis, and persistent Memory & Task vaults.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Dev Server Fix & Confirmed Scope**
> - **Dev Server Startup Fix**: Restores the missing Node/Express/Vite runtime configuration (`dev`, `build`, and `start` scripts listening on `0.0.0.0:3000`) so the AI Studio preview starts reliably without altering your existing Android files.
> - **Confirmed Features**: Custom Voice Creator & spoken greetings, Live microphone voice input & Gemini AI chat, Long-term Memory Vault & Task Agenda, and Image upload analysis & exact math tools.
> - **Confirmed Visual Direction**: Obsidian & Champagne Gold executive dark theme.
> - **AI Model Strategy**: Uses `gemini-4-hydrogen` with selectable thinking depth (`LOW` for swift replies, `HIGH`/`XHIGH` for deep reasoning) and `gemini-3.8-flash-tts` for custom voice synthesis, avoiding paid-only model blockers while preserving deep analytical capability.

## 1. Overview & Core Concept

- **What It Does**: Transforms the blank preview URL into a live, full-stack **PRIME** companion workspace. Users converse by text, live microphone, or uploaded images; receive refined, mannered responses with optional cognitive reflection traces and cited live web search results; manage long-term personal memories and prioritized tasks; and design custom spoken voices with live auditioning.
- **Target Audience / Persona**: Users seeking a poised, emotionally intelligent AI executive companion and customizable voice studio accessible directly in the browser.
- **Key Value**: Resolves the missing preview immediately by serving a complete React + Express application on port 3000 with server-side Gemini intelligence, deterministic math, and persistent storage.

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Launch & Spoken Greeting**: Opening PRIME greets the user by preferred title, time of day, and pending task count—optionally speaking the greeting aloud using the active voice profile.
  2. **Companion Conversation & Tools**: Users type, speak via microphone, or attach an image; PRIME reasons with selectable depth, invokes memory/task/math tools or live Google Search grounding when helpful, and displays concise tool-action confirmations and source links.
  3. **Custom Voice Creator & Studio**: Users open the Voice Creator modal or Voice Studio view to craft custom voices (naming them, picking Neural AI persona + vocal style or browser voice pitch/rate, editing an audition phrase, previewing audio live, and saving/activating).
  4. **Memory Vault, Agenda & Skills**: Users browse and manage remembered personal facts and agenda tasks manually or via chat commands, and launch curated skill prompts from the Multi-Skill Matrix.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Refined executive luxury—calm dark obsidian canvas, crisp hairline structural borders, generous whitespace, and restrained gold accents strictly on primary actions and active states.
  - *Color Palette & Mood* (60-30-10 rule):
    - 60% Canvas: Deep Obsidian (`--background: #080C14`)
    - 30% Structural Surfaces: Elevated Slate (`--surface: #101724`, `--surface-card: #161F30`), Hairline Borders (`--border: #24324A`), Text Primary (`#F1F5F9`), Text Muted (`#94A3B8`)
    - 10% Accent: Champagne Gold (`--primary: #E5C07B`) for primary CTAs and active navigation; semantic status colors (Emerald `#34D399`, Amber `#FBBF24`, Rose `#FB7185`) paired with explicit text labels and icons.
  - *Typography & Hierarchy*: `Plus Jakarta Sans` for display headings and navigation, `DM Sans` for conversational prose, and `JetBrains Mono` with `tabular-nums` for mathematical outputs, timestamps, and counters.
  - *Layout & Top Bar Contract*: Desktop-first workspace featuring a 260px left navigation sidebar (`Companion`, `Skills`, `Vault`, `Voice Studio`), a clean single-row three-zone top bar (`PRIME` wordmark · concise single-line view links · `Create Voice` primary action), and a responsive mobile drawer/bottom navigation adaptation. Unboxed typographic metadata separated by `·`, single-elevation surfaces, and zero decorative pulsing dots or telemetry tickers.
- **Interactive Feedback & Motion**: Reactive animated SVG/Canvas neural core responding to `Idle`, `Listening`, `Thinking`, and `Speaking` states; smooth 150ms transitions; explicit loading skeletons, empty states with primary actions, and clear inline error banners.

## 3. Key Product Decisions & Trade-Offs

- **Full-Stack Express Server (`server.ts`) + React Client**:
  - *Chosen Approach*: Serve the Vite React frontend and Express API routes from a single Node server on port 3000 (`tsx server.ts` in dev, `npm run build` + `node server.ts` in production).
  - *Why*: Keeps `GEMINI_API_KEY` strictly on the server via `@google/genai`, handles multi-turn tool execution cleanly, and delivers an immediate live browser preview.
  - *Alternatives Considered*: Static client-only SPA (rejected because Gemini SDK calls must run server-side).
- **Hybrid Neural & Browser Voice Engine**:
  - *Chosen Approach*: Use server-side `gemini-3.8-flash-tts` (returning `audio/wav` with `speechMetadata` vocal style direction) for Custom Neural Voices, with automatic fallback to the browser's `window.speechSynthesis` for instant offline device voices.
  - *Why*: Guarantees spoken greetings and custom voice previews always produce audio even if network or quota limits occur.
- **Server-Side Persistent JSON Store**:
  - *Chosen Approach*: Persist memories, tasks, conversation history, custom voice profiles, and persona settings in a local JSON data store managed by Express API routes.
  - *Why*: Zero native C++ build overhead in the container while preserving state cleanly across page reloads and server restarts.

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                        Browser Client (React + Tailwind)                │
│  ┌──────────────┐  ┌─────────────────┐  ┌────────────┐  ┌────────────┐  │
│  │ Companion    │  │ Skills Matrix   │  │ Memory &   │  │ Voice      │  │
│  │ Hub + Orb    │  │ (10 Disciplines)│  │ Task Vault │  │ Studio     │  │
│  └──────┬───────┘  └────────┬────────┘  └─────┬──────┘  └─────┬──────┘  │
│         │                   │                 │               │         │
│         └───────────────────┴────────┬────────┴───────────────┘         │
│                                      ▼                                  │
│         Browser Audio & Speech (SpeechRecognition / Audio / TTS)        │
└──────────────────────────────────────┬──────────────────────────────────┘
                                       │ HTTP / JSON (/api/*)
┌──────────────────────────────────────▼──────────────────────────────────┐
│                     Express Server (Port 3000)                          │
│  ┌──────────────────────┐  ┌──────────────────┐  ┌───────────────────┐  │
│  │ Chat & Hybrid Tools  │  │ Neural Voice TTS │  │ Transcribe Audio  │  │
│  │ (gemini-4-hydrogen)  │  │ (gemini-3.8-     │  │ (gemini-3.5-      │  │
│  │ + googleSearch       │  │  flash-tts)      │  │  transcribe)      │  │
│  │ + local tool loop    │  └──────────────────┘  └───────────────────┘  │
│  └──────────┬───────────┘                                               │
│             ▼                                                           │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │ Deterministic Math Evaluator  &  Persistent Vault Store (.data)   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Settings**: Preferred title, manner profile (`Refined Gentleman`, `Warm Companion`, `Executive Strategist`), brain depth (`Low` vs `High` thinking), web search toggle, reasoning trace toggle, auto-greet/auto-reply flags, and active voice configuration.
  - **VoiceProfile**: Name, engine (`Neural` or `Browser`), persona (`Charon`, `Fenrir`, `Kore`, `Zephyr`, `Puck`), vocal style description, pitch, speech rate, and audition greeting phrase.
  - **MemoryItem & TaskItem**: Categorized personal facts and prioritized agenda tasks with completion state.
  - **Message**: Role, text, optional image thumbnail data URL, optional cognitive reflection trace, tool execution records, and grounding source links.
- **Interactive Component & State Mapping**:
  - *Message Submission*: Validates non-empty prompt or attached image, appends optimistic user message, sets Orb to `Thinking`, posts to the chat endpoint (running server-side tool loop for `remember_fact`, `create_task`, `complete_task`, `evaluate_math` + Google Search), persists updated state, and optionally triggers TTS playback.
  - *Voice Input*: Uses browser `SpeechRecognition` for live interim transcript; falls back to recording an audio blob sent to `/api/prime/transcribe` (`gemini-3.5-transcribe`) when browser recognition is unavailable.
  - *Custom Voice Creator*: Allows naming, configuring style/persona or pitch/rate, auditioning via `/api/prime/tts` (`gemini-3.8-flash-tts`) or `speechSynthesis`, and saving/activating in the persistent store.
