import {useCallback, useEffect, useRef, useState} from 'react';
import type {User} from 'firebase/auth';
import {
  Archive,
  AudioLines,
  Brain,
  Briefcase,
  Copy,
  Download,
  Film,
  Gamepad2,
  Globe,
  LogOut,
  MessageSquare,
  Plus,
  RefreshCw,
  Shield,
  Sparkles,
  UserCheck,
  Volume2,
  X,
} from 'lucide-react';
import {
  DEFAULT_GAME_SPACE_STATE,
  DEFAULT_YOUTUBE_AGENTS,
  DEFAULT_YOUTUBE_AGENT_SETTINGS,
  PRIMARY_ADMIN_EMAIL,
  type AuthUserProfile,
  type DeviceAnalysisResult,
  type GameSpaceMode,
  type GameSpaceState,
  type HowToGuideResult,
  type LearnedTopicResult,
  type MemoryItem,
  type PrimeSettings,
  type PrimeVaultSnapshot,
  type PrimeView,
  type SkillDefinition,
  type SubTask,
  type TaskItem,
  type VoiceProfile,
  type VoiceShortcutDefinition,
  type VoiceState,
} from './types/prime.ts';
import {AccountModal} from './components/AccountModal.tsx';
import {BackgroundBossHud} from './components/BackgroundBossHud.tsx';
import {CompanionView} from './components/CompanionView.tsx';
import {GameSpaceView} from './components/GameSpaceView.tsx';
import {
  InstallAppModal,
  type BeforeInstallPromptEvent,
} from './components/InstallAppModal.tsx';
import {SkillsView} from './components/SkillsView.tsx';
import {VaultView} from './components/VaultView.tsx';
import {VoiceStudioView} from './components/VoiceStudioView.tsx';
import {YouTubePipelineView} from './components/YouTubePipelineView.tsx';
import {WorkforceView} from './components/WorkforceView.tsx';
import {AdminConsoleView} from './components/AdminConsoleView.tsx';
import {captureScreenFrameDataUrl, collectDeviceTelemetry} from './utils/deviceAnalyzer.ts';
import {extractSuggestedTasks, resolveTaskDueMs} from './utils/taskHelpers.ts';
import {speakWithPrimeVoice, stopAllSpeech} from './utils/speechClient.ts';
import {
  attachInputMediaStream,
  startPassiveMicAnalyser,
  stopPassiveMicAnalyser,
  triggerVoicePulse,
} from './utils/audioAnalyser.ts';
import {
  initAppUserListener,
  signInWithYouTubeGoogle,
  signOutYouTubeGoogle,
} from './utils/youtubeAuth.ts';

interface BrowserSpeechRecognitionEvent {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal: boolean;
      [altIndex: number]: {transcript: string};
    };
  };
}

interface BrowserSpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: BrowserSpeechRecognitionEvent) => void) | null;
  onerror: ((event?: {error?: string}) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

const VOICE_HISTORY_STORAGE_KEY = 'prime_voice_commands_v1';
const LOCAL_AUTH_TOKEN_KEY = 'prime_local_auth_token_v1';

function loadVoiceCommandHistory(): string[] {
  try {
    const raw = window.localStorage.getItem(VOICE_HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is string => typeof item === 'string').slice(0, 10);
  } catch {
    return [];
  }
}

const DEFAULT_SETTINGS: PrimeSettings = {
  preferredTitle: 'sir',
  mannerProfile: 'refined_gentleman',
  autoSpeakGreeting: false,
  autoSpeakReplies: true,
  voiceEngine: 'neural_tts',
  geminiVoicePersona: 'Charon',
  vocalStyle: 'refined_butler',
  devicePitch: 1.0,
  deviceSpeechRate: 1.0,
  deviceVoiceName: '',
  activeCustomVoiceId: null,
  activeCustomVoiceName: null,
  brainDepth: 'fast',
  webSearchEnabled: true,
  showReasoningTrace: true,
  autoLearnEnabled: true,
  passiveLearnEnabled: true,
  smartContextEnabled: false,
  wakeWordEnabled: false,
  wakeResponsePhrase: 'What happened, boss?',
  backgroundListenMode: false,
  expressiveVoiceMode: true,
  voiceDesignPrompt: '',
};

const NAV_ITEMS: Array<{id: PrimeView; label: string; icon: typeof MessageSquare}> = [
  {id: 'companion', label: 'Companion', icon: MessageSquare},
  {id: 'gamespace', label: 'Game Space', icon: Gamepad2},
  {id: 'workforce', label: 'AI Workforce', icon: Briefcase},
  {id: 'skills', label: 'Skills', icon: Sparkles},
  {id: 'vault', label: 'Vault & Agenda', icon: Archive},
  {id: 'studio', label: 'Voice Studio', icon: AudioLines},
  {id: 'youtube', label: 'YouTube Studio', icon: Film},
];

export default function App() {
  const [snapshot, setSnapshot] = useState<PrimeVaultSnapshot>({
    settings: DEFAULT_SETTINGS,
    messages: [],
    memories: [],
    tasks: [],
    voiceProfiles: [],
    passiveObservations: [],
    gameSpace: DEFAULT_GAME_SPACE_STATE,
    youtubeAgents: DEFAULT_YOUTUBE_AGENTS,
    youtubePostQueue: [],
    youtubeAgentSettings: DEFAULT_YOUTUBE_AGENT_SETTINGS,
  });
  const [activeView, setActiveView] = useState<PrimeView>('companion');
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [partialTranscript, setPartialTranscript] = useState('');
  const [draftInput, setDraftInput] = useState('');
  const [attachedImageDataUrl, setAttachedImageDataUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStage, setProcessingStage] = useState<
    'idle' | 'analyzing' | 'thinking' | 'executing'
  >('idle');
  const [notice, setNotice] = useState<string | null>(null);
  const [voiceCreatorModalOpen, setVoiceCreatorModalOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [installPromptEvent, setInstallPromptEvent] =
    useState<BeforeInstallPromptEvent | null>(null);
  const [isStandaloneApp, setIsStandaloneApp] = useState(false);
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true,
  );
  const [vaultRequestedTab, setVaultRequestedTab] = useState<'agenda' | 'memories' | null>(null);
  const [clearMemorySignal, setClearMemorySignal] = useState(0);
  const [isRefreshingState, setIsRefreshingState] = useState(false);
  const [voiceCommandHistory, setVoiceCommandHistory] = useState<string[]>(loadVoiceCommandHistory);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [localUser, setLocalUser] = useState<AuthUserProfile | null>(null);
  const [youtubePrefillTopic, setYoutubePrefillTopic] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [activeHowToGuide, setActiveHowToGuide] = useState<HowToGuideResult | null>(null);
  const [isBuildingGuide, setIsBuildingGuide] = useState(false);
  const [activeDeviceAnalysis, setActiveDeviceAnalysis] = useState<DeviceAnalysisResult | null>(
    null,
  );
  const [isAnalyzingDevice, setIsAnalyzingDevice] = useState(false);
  const [freeFirePlaystyle, setFreeFirePlaystyle] = useState('One-Tap Headshot');
  const [freeFireGrip, setFreeFireGrip] = useState('2-Finger / Thumb');
  const [lastBossTriggerAtMs, setLastBossTriggerAtMs] = useState<number | null>(null);

  const recognitionRef = useRef<BrowserSpeechRecognition | null>(null);
  const wakeRecognitionRef = useRef<BrowserSpeechRecognition | null>(null);
  const wakeRestartTimerRef = useRef<number | null>(null);
  const wakeDebounceTimerRef = useRef<number | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedAudioChunksRef = useRef<Blob[]>([]);
  const spokenGreetingRef = useRef(false);
  const triggeredAutoStartIdsRef = useRef<Set<string>>(new Set());
  const micToggleRef = useRef<() => void>(() => {});

  useEffect(() => {
    const unsubscribe = initAppUserListener(async (user) => {
      setAuthUser(user);
      if (!user) {
        setIsAdmin(false);
        setActiveView((prev) => (prev === 'admin' ? 'companion' : prev));
        return;
      }
      try {
        const idToken = await user.getIdToken();
        const res = await fetch('/api/prime/auth/session', {
          method: 'POST',
          headers: {Authorization: `Bearer ${idToken}`},
        });
        if (res.ok) {
          const data = (await res.json()) as {email?: string; isAdmin?: boolean};
          const adminFlag = Boolean(data.isAdmin);
          setIsAdmin(adminFlag);
          if (!adminFlag) {
            setActiveView((prev) => (prev === 'admin' ? 'companion' : prev));
          }
          return;
        }
      } catch {
        // Fallback to email check only for UI visibility; backend still requires valid token
      }
      const fallbackAdmin =
        user.email?.trim().toLowerCase() === PRIMARY_ADMIN_EMAIL.toLowerCase();
      setIsAdmin(fallbackAdmin);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    let token = '';
    try {
      token = window.localStorage.getItem(LOCAL_AUTH_TOKEN_KEY) ?? '';
    } catch {
      return;
    }
    if (!token) return;
    let cancelled = false;
    fetch('/api/prime/auth/me', {
      headers: {Authorization: `Bearer ${token}`},
    })
      .then(async (res) => {
        if (!res.ok) throw new Error('Session expired');
        return (await res.json()) as {user?: AuthUserProfile};
      })
      .then((data) => {
        if (!cancelled && data.user) {
          setLocalUser(data.user);
        }
      })
      .catch(() => {
        try {
          window.localStorage.removeItem(LOCAL_AUTH_TOKEN_KEY);
        } catch {
          // ignore
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as {standalone?: boolean}).standalone === true;
    setIsStandaloneApp(standalone);

    const onBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPromptEvent(event as BeforeInstallPromptEvent);
    };
    const onAppInstalled = () => {
      setIsStandaloneApp(true);
      setInstallPromptEvent(null);
      setNotice('PRIME Latest Version installed onto your device.');
    };
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('beforeinstallprompt', onBeforeInstallPrompt);
    window.addEventListener('appinstalled', onAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt);
      window.removeEventListener('appinstalled', onAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleGlobalSignIn = async () => {
    setIsSigningIn(true);
    try {
      const {user} = await signInWithYouTubeGoogle();
      const idToken = await user.getIdToken();
      const res = await fetch('/api/prime/auth/session', {
        method: 'POST',
        headers: {Authorization: `Bearer ${idToken}`},
      });
      if (res.ok) {
        const data = (await res.json()) as {isAdmin?: boolean};
        setIsAdmin(Boolean(data.isAdmin));
        if (data.isAdmin) {
          showNotice(`Admin power unlocked for ${user.email}.`);
        } else {
          showNotice(`Signed in as ${user.email}.`);
        }
      }
    } catch (err) {
      showNotice(err instanceof Error ? err.message : 'Google sign-in failed.');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleLocalLogin = async (email: string, password: string) => {
    const res = await fetch('/api/prime/auth/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({email, password}),
    });
    const data = (await res.json()) as {
      token?: string;
      user?: AuthUserProfile;
      error?: string;
    };
    if (!res.ok || !data.token || !data.user) {
      throw new Error(data.error || 'Sign in failed.');
    }
    try {
      window.localStorage.setItem(LOCAL_AUTH_TOKEN_KEY, data.token);
    } catch {
      // ignore storage errors
    }
    setLocalUser(data.user);
    showNotice(`Signed in as ${data.user.name} (${data.user.email}).`);
  };

  const handleLocalRegister = async (name: string, email: string, password: string) => {
    const res = await fetch('/api/prime/auth/register', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name, email, password}),
    });
    const data = (await res.json()) as {
      token?: string;
      user?: AuthUserProfile;
      error?: string;
    };
    if (!res.ok || !data.token || !data.user) {
      throw new Error(data.error || 'Registration failed.');
    }
    try {
      window.localStorage.setItem(LOCAL_AUTH_TOKEN_KEY, data.token);
    } catch {
      // ignore storage errors
    }
    setLocalUser(data.user);
    showNotice(`Account created. Welcome, ${data.user.name}.`);
  };

  const handleGlobalSignOut = async () => {
    await signOutYouTubeGoogle();
    try {
      window.localStorage.removeItem(LOCAL_AUTH_TOKEN_KEY);
    } catch {
      // ignore
    }
    setAuthUser(null);
    setLocalUser(null);
    setIsAdmin(false);
    setActiveView((prev) => (prev === 'admin' ? 'companion' : prev));
    showNotice('Signed out.');
  };

  const showNotice = useCallback((msg: string) => {
    setNotice(msg);
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 4500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const speakText = useCallback(
    async (text: string, overrideSettings?: PrimeSettings, styleOverride?: string) => {
      const targetSettings = overrideSettings ?? snapshot.settings;
      await speakWithPrimeVoice(text, targetSettings, {
        onStart: () => setVoiceState('speaking'),
        onEnd: () => setVoiceState('idle'),
        onError: (errMsg) => showNotice(errMsg),
        styleOverride,
      });
    },
    [snapshot.settings, showNotice],
  );

  const handleStopSpeaking = useCallback(() => {
    stopAllSpeech();
    setVoiceState('idle');
  }, []);

  const handleSpeakGreeting = useCallback(async () => {
    try {
      const res = await fetch('/api/prime/greeting', {method: 'POST'});
      const data = (await res.json()) as {greeting?: string};
      if (data.greeting) {
        await speakText(data.greeting);
      }
    } catch {
      showNotice('Could not synthesize spoken greeting.');
    }
  }, [speakText, showNotice]);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/prime/state')
      .then((res) => res.json())
      .then((data: PrimeVaultSnapshot) => {
        if (cancelled) return;
        setSnapshot(data);
        if (data.settings.autoSpeakGreeting && !spokenGreetingRef.current) {
          spokenGreetingRef.current = true;
          fetch('/api/prime/greeting', {method: 'POST'})
            .then((r) => r.json())
            .then((g: {greeting?: string}) => {
              if (g.greeting) speakWithPrimeVoice(g.greeting, data.settings);
            })
            .catch(() => {});
        }
      })
      .catch(() => {
        if (!cancelled) showNotice('Unable to reach PRIME local backend.');
      });
    return () => {
      cancelled = true;
    };
  }, [showNotice]);

  const handleUpdateSettings = useCallback(async (patch: Partial<PrimeSettings>) => {
    setSnapshot((prev) => ({
      ...prev,
      settings: {...prev.settings, ...patch},
    }));
    const res = await fetch('/api/prime/settings', {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(patch),
    });
    if (res.ok) {
      const updated = (await res.json()) as PrimeVaultSnapshot;
      setSnapshot(updated);
    }
  }, []);

  const handleUpdateGameSpace = useCallback(async (patch: Partial<GameSpaceState>) => {
    setSnapshot((prev) => ({
      ...prev,
      gameSpace: {...(prev.gameSpace ?? DEFAULT_GAME_SPACE_STATE), ...patch},
    }));
    const res = await fetch('/api/prime/gamespace', {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(patch),
    });
    if (res.ok) {
      const updated = (await res.json()) as PrimeVaultSnapshot;
      setSnapshot(updated);
    }
  }, []);

  const refreshState = useCallback(async () => {
    setIsRefreshingState(true);
    setProcessingStage('executing');
    try {
      const res = await fetch('/api/prime/state');
      if (!res.ok) throw new Error('Refresh failed.');
      const data = (await res.json()) as PrimeVaultSnapshot;
      setSnapshot(data);
      showNotice('Workspace refreshed.');
    } catch {
      showNotice('Unable to refresh PRIME workspace.');
    } finally {
      setIsRefreshingState(false);
      setProcessingStage('idle');
    }
  }, [showNotice]);

  const handleAddTask = useCallback(
    async (
      title: string,
      priority: TaskItem['priority'],
      dueNote: string,
      dueAtMs?: number | null,
      autoStartOnDue?: boolean,
      tags?: string[],
    ) => {
      const res = await fetch('/api/prime/tasks', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({title, priority, dueNote, dueAtMs, autoStartOnDue, tags}),
      });
      if (res.ok) {
        setSnapshot((await res.json()) as PrimeVaultSnapshot);
      }
    },
    [],
  );

  const handleUpdateTaskDetails = useCallback(
    async (
      id: string,
      patch: {
        notes?: string;
        subTasks?: SubTask[];
        tags?: string[];
        dueNote?: string;
        dueAtMs?: number | null;
        autoStartOnDue?: boolean;
        autoStartedAtMs?: number | null;
      },
    ) => {
      setSnapshot((prev) => ({
        ...prev,
        tasks: prev.tasks.map((task) => (task.id === id ? {...task, ...patch} : task)),
      }));
      try {
        const res = await fetch(`/api/prime/tasks/${encodeURIComponent(id)}`, {
          method: 'PATCH',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(patch),
        });
        if (res.ok) {
          setSnapshot((await res.json()) as PrimeVaultSnapshot);
        }
      } catch {
        // Optimistic update stays applied locally
      }
    },
    [],
  );

  const recordVoiceCommand = useCallback((command: string) => {
    const cleaned = command.trim();
    if (!cleaned) return;
    setVoiceCommandHistory((prev) => {
      const next = [cleaned, ...prev.filter((item) => item.toLowerCase() !== cleaned.toLowerCase())].slice(
        0,
        10,
      );
      try {
        window.localStorage.setItem(VOICE_HISTORY_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage errors in private mode
      }
      return next;
    });
  }, []);

  const clearVoiceCommandHistory = useCallback(() => {
    setVoiceCommandHistory([]);
    try {
      window.localStorage.removeItem(VOICE_HISTORY_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
    showNotice('Cleared voice command history.');
  }, [showNotice]);

  const handleSend = useCallback(
    async (overrideText?: string) => {
      const promptToSend = (overrideText ?? draftInput).trim();
      const imageToSend = overrideText ? undefined : attachedImageDataUrl;
      if ((!promptToSend && !imageToSend) || isProcessing) return;

      stopAllSpeech();
      if (!overrideText) {
        setDraftInput('');
        setAttachedImageDataUrl(null);
      }

      setIsProcessing(true);
      setProcessingStage(imageToSend || snapshot.settings.smartContextEnabled ? 'analyzing' : 'thinking');
      setVoiceState('thinking');

      try {
        if (
          snapshot.settings.smartContextEnabled &&
          promptToSend.length > 50 &&
          snapshot.settings.brainDepth !== 'deep'
        ) {
          await handleUpdateSettings({brainDepth: 'deep'});
          showNotice('Smart Context engaged Deep Brain for detailed prompt.');
        }

        setProcessingStage('thinking');
        const res = await fetch('/api/prime/chat', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            prompt: promptToSend,
            imageDataUrl: imageToSend,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Failed to get response from PRIME.');
        }

        setSnapshot(data.snapshot as PrimeVaultSnapshot);
        setVoiceState('idle');
        setProcessingStage('idle');

        if (
          data.snapshot?.settings?.autoSpeakReplies &&
          typeof data.replyMessage?.text === 'string'
        ) {
          await speakText(
            data.replyMessage.text,
            data.snapshot.settings,
            typeof data.replyMessage?.suggestedVocalStyle === 'string'
              ? data.replyMessage.suggestedVocalStyle
              : undefined,
          );
        }
      } catch (err) {
        setVoiceState('idle');
        showNotice(err instanceof Error ? err.message : 'Unable to complete chat request.');
      } finally {
        setIsProcessing(false);
        setProcessingStage('idle');
      }
    },
    [
      attachedImageDataUrl,
      draftInput,
      handleUpdateSettings,
      isProcessing,
      showNotice,
      snapshot.settings.brainDepth,
      snapshot.settings.smartContextEnabled,
      speakText,
    ],
  );

  const handleBuildHowToGuide = useCallback(
    async (customQuery?: string) => {
      const q = (customQuery ?? draftInput).trim() || 'How to optimize PRIME workflow and phone settings';
      if (isBuildingGuide) return;
      setIsBuildingGuide(true);
      setProcessingStage('thinking');
      setActiveView('companion');
      if (!customQuery && draftInput.trim()) setDraftInput('');
      try {
        const res = await fetch('/api/prime/how-to-guide', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            query: q,
            imageDataUrl: attachedImageDataUrl || undefined,
          }),
        });
        const data = (await res.json()) as {
          guide?: HowToGuideResult;
          snapshot?: PrimeVaultSnapshot;
          error?: string;
        };
        if (!res.ok || !data.guide) {
          throw new Error(data.error || 'Could not generate visual guide.');
        }
        if (data.snapshot) setSnapshot(data.snapshot);
        setActiveHowToGuide(data.guide);
        showNotice(`Visual walkthrough ready (${data.guide.steps.length} steps).`);
        if (snapshot.settings.autoSpeakReplies) {
          const firstStep = data.guide.steps[0];
          await speakText(
            `${data.guide.title}. ${firstStep ? `Step 1: ${firstStep.actionTitle}. ${firstStep.instruction}` : data.guide.summary}`,
          );
        }
      } catch (err) {
        showNotice(err instanceof Error ? err.message : 'Unable to build visual guide.');
      } finally {
        setIsBuildingGuide(false);
        setProcessingStage('idle');
      }
    },
    [
      attachedImageDataUrl,
      draftInput,
      isBuildingGuide,
      showNotice,
      snapshot.settings.autoSpeakReplies,
      speakText,
    ],
  );

  const handleAnalyzeMobileDevice = useCallback(
    async (options?: {captureScreen?: boolean; customQuery?: string}) => {
      if (isAnalyzingDevice) return;
      setIsAnalyzingDevice(true);
      setProcessingStage('analyzing');
      setActiveView('companion');
      try {
        let imageDataUrl = attachedImageDataUrl || undefined;
        if (options?.captureScreen && !imageDataUrl) {
          try {
            imageDataUrl = await captureScreenFrameDataUrl();
          } catch (capErr) {
            showNotice(
              capErr instanceof Error
                ? `${capErr.message} Running mobile hardware analysis instead.`
                : 'Screen capture skipped — running mobile hardware analysis.',
            );
          }
        }
        const telemetry = await collectDeviceTelemetry();
        const res = await fetch('/api/prime/analyze-device', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            query:
              options?.customQuery ||
              'Analyze my mobile hardware and create the best Free Fire headshot sensitivity preset.',
            playstyle: freeFirePlaystyle,
            fingerGrip: freeFireGrip,
            telemetry,
            imageDataUrl,
          }),
        });
        const data = (await res.json()) as {
          analysis?: DeviceAnalysisResult;
          snapshot?: PrimeVaultSnapshot;
          error?: string;
        };
        if (!res.ok || !data.analysis) {
          throw new Error(data.error || 'Mobile analysis failed.');
        }
        if (data.snapshot) setSnapshot(data.snapshot);
        setActiveDeviceAnalysis(data.analysis);
        showNotice(
          `Analyzed ${telemetry.deviceModelHint} (${telemetry.estimatedRefreshHz}Hz) · Free Fire sensitivity calibrated.`,
        );
        if (snapshot.settings.autoSpeakReplies && data.analysis.freeFireSensitivity) {
          const ff = data.analysis.freeFireSensitivity;
          await speakText(
            `Analyzed your ${telemetry.deviceModelHint}. For ${ff.playstyle}, set General to ${ff.general}, Red Dot to ${ff.redDot}, 2x Scope ${ff.scope2x}, 4x Scope ${ff.scope4x}, and Android DPI ${ff.recommendedDpi}.`,
          );
        }
      } catch (err) {
        showNotice(err instanceof Error ? err.message : 'Unable to analyze mobile device.');
      } finally {
        setIsAnalyzingDevice(false);
        setProcessingStage('idle');
      }
    },
    [
      attachedImageDataUrl,
      freeFireGrip,
      freeFirePlaystyle,
      isAnalyzingDevice,
      showNotice,
      snapshot.settings.autoSpeakReplies,
      speakText,
    ],
  );

  const handleVoiceTranscript = useCallback(
    async (rawTranscript: string, options?: {skipRecord?: boolean}) => {
      const cleaned = rawTranscript.trim();
      if (!cleaned) return;
      if (!options?.skipRecord) {
        recordVoiceCommand(cleaned);
      }

      const lower = cleaned.toLowerCase().replace(/[.!?]+$/, '').trim();

      const addTaskMatch = cleaned.match(
        /^(?:hey\s+prime[,:\s]+)?(?:add\s+a\s+task|create\s+(?:a\s+)?task|new\s+task)\b[:\s-]*(.*)$/i,
      );
      if (addTaskMatch) {
        const taskTitle = (addTaskMatch[1] || '').trim().replace(/[.!?]+$/, '');
        if (taskTitle.length > 0) {
          setProcessingStage('executing');
          try {
            await handleAddTask(taskTitle, 'Normal', '');
            showNotice(`Voice shortcut: Added task "${taskTitle}" to Vault.`);
            if (snapshot.settings.autoSpeakReplies) {
              await speakText(`Added task ${taskTitle} to your agenda.`);
            }
          } finally {
            setProcessingStage('idle');
          }
        } else {
          setActiveView('vault');
          setVaultRequestedTab('agenda');
          showNotice('Opened Vault Agenda to add a task.');
        }
        return;
      }

      if (/^(?:clear\s+memory|clear\s+memories|wipe\s+memory)$/i.test(lower)) {
        setActiveView('vault');
        setVaultRequestedTab('memories');
        setClearMemorySignal((n) => n + 1);
        showNotice('Voice shortcut: Confirm to clear Memory Vault.');
        return;
      }

      if (/^(?:open\s+vault|show\s+vault|show\s+tasks|open\s+agenda|open\s+tasks)$/i.test(lower)) {
        setActiveView('vault');
        setVaultRequestedTab('agenda');
        showNotice('Opened Vault & Executive Agenda.');
        return;
      }

      if (/^(?:open\s+memories|show\s+memories|memory\s+vault)$/i.test(lower)) {
        setActiveView('vault');
        setVaultRequestedTab('memories');
        showNotice('Opened Memory Vault.');
        return;
      }

      const ytMatch = cleaned.match(
        /^(?:hey\s+prime[,:\s]+)?(?:open\s+youtube(?:\s+studio|\s+agents)?|youtube\s+(?:studio|agents)|auto\s+create\s+(?:a\s+)?video)(?:[:\s-]+(.*))?[.!?]*$/i,
      );
      if (ytMatch) {
        const topic = (ytMatch[1] || '').trim().replace(/[.!?]+$/, '');
        if (topic.length > 0) {
          setYoutubePrefillTopic(topic);
          showNotice(`Opened YouTube Auto-Create & Auto-Post Studio for "${topic}".`);
        } else {
          showNotice('Opened YouTube Auto-Create & Auto-Post Studio.');
        }
        setActiveView('youtube');
        return;
      }

      if (/^(?:open\s+skills|show\s+skills)$/i.test(lower)) {
        setActiveView('skills');
        return;
      }

      if (/^(?:open\s+voice\s+studio|voice\s+studio)$/i.test(lower)) {
        setActiveView('studio');
        return;
      }

      if (/^(?:open\s+companion|go\s+home)$/i.test(lower)) {
        setActiveView('companion');
        return;
      }

      if (
        /^(?:enable\s+deep\s+brain|deep\s+brain(?:\s+mode)?|switch\s+to\s+deep\s+brain)$/i.test(
          lower,
        )
      ) {
        await handleUpdateSettings({brainDepth: 'deep'});
        showNotice('Voice shortcut: Deep Brain enabled.');
        return;
      }

      if (
        /^(?:enable\s+fast\s+brain|fast\s+brain(?:\s+mode)?|switch\s+to\s+fast\s+brain)$/i.test(
          lower,
        )
      ) {
        await handleUpdateSettings({brainDepth: 'fast'});
        showNotice('Voice shortcut: Fast Brain enabled.');
        return;
      }

      if (/^(?:open\s+workforce|workforce|ai\s+workforce|open\s+agents)$/i.test(lower)) {
        setActiveView('workforce');
        showNotice('Opened Jarvis Command & AI Workforce.');
        return;
      }

      if (/^(?:open\s+game\s*space|launch\s+game\s*space|game\s*space)$/i.test(lower)) {
        setActiveView('gamespace');
        showNotice('Entered RedMagic Game Space Cockpit.');
        return;
      }

      const modeMatch = lower.match(/^(?:enable\s+|switch\s+to\s+|set\s+)?(eco|balance|rise|diablo)\s+mode$/i);
      if (modeMatch) {
        const mode = modeMatch[1].toLowerCase() as GameSpaceMode;
        await handleUpdateGameSpace({
          performanceMode: mode,
          fanEnabled: mode === 'rise' || mode === 'diablo',
          fanMode: mode === 'diablo' ? 'max' : 'smart',
          fanRpm: mode === 'diablo' ? 22000 : mode === 'rise' ? 20000 : 14000,
          targetFps: mode === 'eco' ? 60 : mode === 'balance' ? 90 : mode === 'rise' ? 120 : 144,
        });
        setActiveView('gamespace');
        showNotice(`Game Space switched to ${mode.toUpperCase()} mode.`);
        return;
      }

      if (/^(?:morning\s+briefing|jarvis\s+briefing|daily\s+briefing)$/i.test(lower)) {
        setActiveView('workforce');
        showNotice('Opened OpenJarvis Morning Briefing HUD.');
        return;
      }

      if (/^(?:retry\s+failed(?:\s+tasks)?|do\s+again\s+failed(?:\s+tasks)?)$/i.test(lower)) {
        setProcessingStage('executing');
        try {
          const res = await fetch('/api/prime/tasks/retry-failed', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({rescheduleMinutes: 15}),
          });
          if (res.ok) {
            const data = (await res.json()) as {
              snapshot?: PrimeVaultSnapshot;
              retriedIds?: string[];
            };
            if (data.snapshot) setSnapshot(data.snapshot);
            const count = data.retriedIds?.length ?? 0;
            showNotice(
              count > 0
                ? `Re-queued ${count} failed/overdue task(s) for another run.`
                : 'No failed or overdue tasks found to retry.',
            );
          }
        } finally {
          setProcessingStage('idle');
        }
        return;
      }

      if (/^(?:add\s+all\s+suggestions|save\s+all\s+suggestions)$/i.test(lower)) {
        const items = extractSuggestedTasks(snapshot.messages, snapshot.tasks);
        if (items.length === 0) {
          showNotice('No new suggested tasks found in the current conversation.');
          return;
        }
        setProcessingStage('executing');
        try {
          for (const item of items) {
            await handleAddTask(item.title, item.priority, '');
          }
          showNotice(`Added all ${items.length} suggested task(s) to Vault.`);
        } finally {
          setProcessingStage('idle');
        }
        return;
      }

      if (/^(?:refresh|refresh\s+data|reload\s+state)$/i.test(lower)) {
        await refreshState();
        return;
      }

      if (
        /(?:analy[sz]e\s+(?:this|my\s+mobile|my\s+phone|my\s+screen|device)|free\s*fire\s+sensitiv|create\s+(?:a\s+)?sensitiv)/i.test(
          lower,
        )
      ) {
        await handleAnalyzeMobileDevice({
          captureScreen: /\b(?:screen|this)\b/i.test(lower),
          customQuery: cleaned,
        });
        return;
      }

      if (/^(?:how\s+(?:to|do\s+i)|show\s+me\s+how|guide\s+me)\b/i.test(lower)) {
        await handleBuildHowToGuide(cleaned);
        return;
      }

      await handleSend(cleaned);
    },
    [
      handleAddTask,
      handleAnalyzeMobileDevice,
      handleBuildHowToGuide,
      handleSend,
      handleUpdateGameSpace,
      handleUpdateSettings,
      recordVoiceCommand,
      refreshState,
      showNotice,
      snapshot.messages,
      snapshot.settings.autoSpeakReplies,
      snapshot.tasks,
      speakText,
    ],
  );

  const handleExecuteVoiceShortcutExample = useCallback(
    (shortcut: VoiceShortcutDefinition) => {
      switch (shortcut.id) {
        case 'how_to_guide':
          void handleBuildHowToGuide('How to boost mobile FPS and battery performance');
          break;
        case 'analyze_mobile':
          void handleAnalyzeMobileDevice({
            customQuery: 'Analyze my mobile and create Free Fire sensitivity',
          });
          break;
        case 'add_task':
          void handleVoiceTranscript('Add a task Review Q3 metrics', {skipRecord: true});
          break;
        case 'clear_memory':
          void handleVoiceTranscript('Clear memory', {skipRecord: true});
          break;
        case 'add_all_suggestions':
          void handleVoiceTranscript('Add all suggestions', {skipRecord: true});
          break;
        case 'open_vault':
          void handleVoiceTranscript('Open vault', {skipRecord: true});
          break;
        case 'open_youtube':
          void handleVoiceTranscript('Open YouTube studio', {skipRecord: true});
          break;
        case 'open_workforce':
          void handleVoiceTranscript('Open workforce', {skipRecord: true});
          break;
        case 'open_gamespace':
          void handleVoiceTranscript('Open game space', {skipRecord: true});
          break;
        case 'morning_briefing':
          void handleVoiceTranscript('Morning briefing', {skipRecord: true});
          break;
        case 'retry_failed':
          void handleVoiceTranscript('Retry failed tasks', {skipRecord: true});
          break;
        case 'deep_brain':
          void handleVoiceTranscript('Enable deep brain', {skipRecord: true});
          break;
        case 'refresh_data':
          void handleVoiceTranscript('Refresh data', {skipRecord: true});
          break;
        default:
          break;
      }
    },
    [handleAnalyzeMobileDevice, handleBuildHowToGuide, handleVoiceTranscript],
  );

  const startFallbackAudioRecorder = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({audio: true});
      const detachMic = attachInputMediaStream(stream);
      const recorder = new MediaRecorder(stream);
      recordedAudioChunksRef.current = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedAudioChunksRef.current.push(ev.data);
      };
      recorder.onstop = async () => {
        detachMic();
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(recordedAudioChunksRef.current, {type: 'audio/webm'});
        const reader = new FileReader();
        reader.onloadend = async () => {
          const result = typeof reader.result === 'string' ? reader.result : '';
          const base64 = result.split(',')[1] ?? '';
          if (!base64) {
            setVoiceState('idle');
            return;
          }
          setVoiceState('thinking');
          setProcessingStage('analyzing');
          try {
            const trRes = await fetch('/api/prime/transcribe', {
              method: 'POST',
              headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({audioBase64: base64, mimeType: blob.type || 'audio/webm'}),
            });
            const trData = (await trRes.json()) as {transcript?: string; error?: string};
            if (!trRes.ok || !trData.transcript) {
              throw new Error(trData.error || 'No speech detected.');
            }
            setPartialTranscript('');
            setProcessingStage('idle');
            await handleVoiceTranscript(trData.transcript);
          } catch (err) {
            setVoiceState('idle');
            setProcessingStage('idle');
            showNotice(err instanceof Error ? err.message : 'Voice transcription failed.');
          }
        };
        reader.readAsDataURL(blob);
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setVoiceState('listening');
      setPartialTranscript('Recording voice... click orb again when finished');
    } catch {
      setVoiceState('idle');
      showNotice('Microphone access is unavailable in this browser.');
    }
  }, [handleVoiceTranscript, showNotice]);

  const beginListeningSession = useCallback(() => {
    stopAllSpeech();

    const win = window as unknown as {
      SpeechRecognition?: new () => BrowserSpeechRecognition;
      webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
    };
    const SpeechRecCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRecCtor) {
      void startFallbackAudioRecorder();
      return;
    }

    const recognition = new SpeechRecCtor();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    let finalTranscript = '';

    recognition.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const text = event.results[i][0]?.transcript ?? '';
        if (event.results[i].isFinal) {
          finalTranscript += `${text} `;
        } else {
          interim += text;
        }
      }
      triggerVoicePulse(0.8);
      setPartialTranscript((finalTranscript + interim).trim());
    };

    recognition.onerror = () => {
      stopPassiveMicAnalyser();
      recognitionRef.current = null;
      setVoiceState('idle');
      setPartialTranscript('');
      void startFallbackAudioRecorder();
    };

    recognition.onend = () => {
      stopPassiveMicAnalyser();
      recognitionRef.current = null;
      const cleaned = finalTranscript.trim();
      setPartialTranscript('');
      setVoiceState('idle');
      if (cleaned) {
        void handleVoiceTranscript(cleaned);
      }
    };

    recognitionRef.current = recognition;
    setPartialTranscript('');
    setVoiceState('listening');
    startPassiveMicAnalyser();
    try {
      recognition.start();
    } catch {
      stopPassiveMicAnalyser();
      recognitionRef.current = null;
      void startFallbackAudioRecorder();
    }
  }, [handleVoiceTranscript, startFallbackAudioRecorder]);

  const handleMicToggle = useCallback(() => {
    if (voiceState === 'speaking') {
      handleStopSpeaking();
      return;
    }

    if (voiceState === 'listening') {
      stopPassiveMicAnalyser();
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current = null;
      }
      setVoiceState('idle');
      return;
    }

    beginListeningSession();
  }, [beginListeningSession, handleStopSpeaking, voiceState]);

  const handleBargeInAndListen = useCallback(() => {
    stopAllSpeech();
    beginListeningSession();
  }, [beginListeningSession]);

  useEffect(() => {
    micToggleRef.current = handleMicToggle;
  }, [handleMicToggle]);

  // Hands-free Wake Word Listener ("Prime" / "Hey PRIME") -> responds "What happened, boss?" & listens
  useEffect(() => {
    if (!snapshot.settings.wakeWordEnabled || voiceState !== 'idle' || isProcessing) {
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => BrowserSpeechRecognition;
      webkitSpeechRecognition?: new () => BrowserSpeechRecognition;
    };
    const SpeechRecCtor = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SpeechRecCtor) {
      return;
    }

    let cancelled = false;
    let triggeredWake = false;

    const startWakeListener = () => {
      if (cancelled) return;
      const rec = new SpeechRecCtor();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';
      wakeRecognitionRef.current = rec;

      rec.onresult = (event) => {
        if (cancelled || triggeredWake) return;
        let combined = '';
        let latestIsFinal = false;
        for (let i = event.resultIndex; i < event.results.length; i++) {
          combined += `${event.results[i][0]?.transcript ?? ''} `;
          if (event.results[i].isFinal) latestIsFinal = true;
        }
        const wakeMatch = combined.match(/(?:^|\b)(?:(?:hey|ok|hi)\s+)?prime\b[,:\s]*(.*)$/i);
        if (!wakeMatch) return;

        const trailing = (wakeMatch[1] || '').trim();
        const triggerNow = () => {
          if (cancelled || triggeredWake) return;
          triggeredWake = true;
          try {
            rec.stop();
          } catch {
            // ignore stop errors
          }
          wakeRecognitionRef.current = null;
          triggerVoicePulse(1.0);
          setLastBossTriggerAtMs(Date.now());

          if (trailing.length >= 2) {
            void handleVoiceTranscript(trailing);
          } else {
            const wakeReply =
              snapshot.settings.wakeResponsePhrase?.trim() || 'What happened, boss?';
            showNotice(`PRIME: "${wakeReply}"`);
            void speakWithPrimeVoice(wakeReply, snapshot.settings, {
              onStart: () => setVoiceState('speaking'),
              onEnd: () => {
                setVoiceState('idle');
                window.setTimeout(() => {
                  if (!cancelled) micToggleRef.current();
                }, 120);
              },
              onError: () => {
                setVoiceState('idle');
                if (!cancelled) micToggleRef.current();
              },
            });
          }
        };

        if (wakeDebounceTimerRef.current) {
          window.clearTimeout(wakeDebounceTimerRef.current);
          wakeDebounceTimerRef.current = null;
        }

        if (latestIsFinal) {
          triggerNow();
        } else {
          wakeDebounceTimerRef.current = window.setTimeout(triggerNow, 550);
        }
      };

      rec.onerror = (ev) => {
        const errCode = ev?.error || '';
        if (errCode === 'not-allowed' || errCode === 'service-not-allowed') {
          cancelled = true;
          showNotice('Microphone permission required for "Prime" wake word.');
          void handleUpdateSettings({wakeWordEnabled: false, backgroundListenMode: false});
        }
      };

      rec.onend = () => {
        wakeRecognitionRef.current = null;
        if (!cancelled && !triggeredWake) {
          wakeRestartTimerRef.current = window.setTimeout(() => {
            startWakeListener();
          }, 450);
        }
      };

      try {
        rec.start();
      } catch {
        // Will retry cleanly via state change or next activation
      }
    };

    wakeRestartTimerRef.current = window.setTimeout(startWakeListener, 300);

    return () => {
      cancelled = true;
      if (wakeRestartTimerRef.current) {
        window.clearTimeout(wakeRestartTimerRef.current);
        wakeRestartTimerRef.current = null;
      }
      if (wakeDebounceTimerRef.current) {
        window.clearTimeout(wakeDebounceTimerRef.current);
        wakeDebounceTimerRef.current = null;
      }
      if (wakeRecognitionRef.current) {
        try {
          wakeRecognitionRef.current.stop();
        } catch {
          // ignore
        }
        wakeRecognitionRef.current = null;
      }
    };
  }, [
    handleUpdateSettings,
    handleVoiceTranscript,
    isProcessing,
    showNotice,
    snapshot.settings,
    voiceState,
  ]);

  // Task time-limit watcher: auto-start when due countdown expires
  useEffect(() => {
    const timer = window.setInterval(() => {
      const now = Date.now();
      for (const task of snapshot.tasks) {
        if (
          task.isCompleted ||
          !task.autoStartOnDue ||
          task.autoStartedAtMs ||
          triggeredAutoStartIdsRef.current.has(task.id)
        ) {
          continue;
        }
        const dueMs = resolveTaskDueMs(task);
        if (dueMs !== null && dueMs <= now) {
          triggeredAutoStartIdsRef.current.add(task.id);
          void handleUpdateTaskDetails(task.id, {autoStartedAtMs: now});
          setActiveView('companion');
          showNotice(`Time limit over — auto-starting task "${task.title}".`);
          if (!isProcessing) {
            const contextNotes = task.notes ? ` Notes: ${task.notes}` : '';
            void handleSend(
              `Time limit reached for my scheduled task "${task.title}". Auto-start it now with an immediate kickoff plan and first action.${contextNotes}`,
            );
          } else {
            void speakText(`Time limit reached for task ${task.title}. Ready to begin.`);
          }
          break;
        }
      }
    }, 2000);
    return () => window.clearInterval(timer);
  }, [
    handleSend,
    handleUpdateTaskDetails,
    isProcessing,
    showNotice,
    snapshot.tasks,
    speakText,
  ]);

  const handleRetryTask = useCallback(
    async (id: string) => {
      const res = await fetch(`/api/prime/tasks/${encodeURIComponent(id)}/retry`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({rescheduleMinutes: 15}),
      });
      if (res.ok) {
        triggeredAutoStartIdsRef.current.delete(id);
        setSnapshot((await res.json()) as PrimeVaultSnapshot);
        showNotice('Re-queued task and reset countdown timer (+15m).');
      }
    },
    [showNotice],
  );

  const handleRetryAllFailedTasks = useCallback(async () => {
    const res = await fetch('/api/prime/tasks/retry-failed', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({rescheduleMinutes: 15}),
    });
    if (res.ok) {
      const data = (await res.json()) as {
        snapshot?: PrimeVaultSnapshot;
        retriedIds?: string[];
      };
      for (const id of data.retriedIds ?? []) {
        triggeredAutoStartIdsRef.current.delete(id);
      }
      if (data.snapshot) setSnapshot(data.snapshot);
      const count = data.retriedIds?.length ?? 0;
      showNotice(
        count > 0
          ? `Re-queued ${count} failed/overdue task(s) to do again (+15m).`
          : 'No failed or overdue tasks found.',
      );
    }
  }, [showNotice]);

  const handleLaunchSkill = (skill: SkillDefinition) => {
    if (skill.id === 'youtube_auto_post') {
      setActiveView('youtube');
      showNotice('Opened YouTube Auto-Create & Auto-Post Studio.');
      return;
    }
    if (skill.id === 'workforce_orchestrator' || skill.id === 'morning_briefing_hud') {
      setActiveView('workforce');
      showNotice('Opened Jarvis Command & AI Workforce.');
      return;
    }
    if (skill.id === 'device_freefire_analyzer') {
      void handleAnalyzeMobileDevice({
        customQuery: 'Analyze my mobile hardware and create Free Fire sensitivity',
      });
      return;
    }
    if (skill.id === 'visual_how_to') {
      setActiveView('companion');
      setDraftInput('Show me how to ');
      showNotice('Type or speak what you want PRIME to show you step-by-step.');
      return;
    }
    if (skill.requiresDeepBrain && snapshot.settings.brainDepth !== 'deep') {
      handleUpdateSettings({brainDepth: 'deep'});
    }
    setActiveView('companion');
    if (skill.starterPrompt.endsWith(' ')) {
      setDraftInput(skill.starterPrompt);
    } else {
      handleSend(skill.starterPrompt);
    }
  };

  const pendingTaskCount = snapshot.tasks.filter((t) => !t.isCompleted).length;
  const visibleNavItems = isAdmin
    ? [...NAV_ITEMS, {id: 'admin' as PrimeView, label: 'Admin Console', icon: Shield}]
    : NAV_ITEMS;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#080C14] text-[#F1F5F9]">
      {/* Desktop Left Navigation Rail */}
      <aside className="hidden w-[252px] shrink-0 flex-col justify-between border-r border-[#24324A] bg-[#101724] p-4 md:flex">
        <div>
          <div className="flex items-center justify-between px-2 py-2">
            <div>
              <span className="font-display text-lg font-bold tracking-tight text-[#F1F5F9]">
                PRIME
              </span>
              <p className="text-[11px] text-[#94A3B8]">Executive Companion</p>
            </div>
          </div>

          <nav className="mt-5 flex flex-col gap-1" aria-label="Primary Navigation">
            {visibleNavItems.map((item) => {
              const Icon = item.icon;
              const active = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveView(item.id)}
                  className={`flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    active
                      ? 'bg-[#161F30] text-[#E5C07B]'
                      : 'text-[#94A3B8] hover:bg-[#161F30]/60 hover:text-[#F1F5F9]'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </span>
                  {item.id === 'vault' && pendingTaskCount > 0 && (
                    <span className="text-xs font-mono-tabular text-[#E5C07B]">
                      {pendingTaskCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="flex flex-col gap-2.5 border-t border-[#24324A] pt-3">
          {authUser || localUser ? (
            <div className="flex items-center justify-between gap-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2">
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold text-[#F1F5F9]">
                  {authUser?.displayName || localUser?.name || authUser?.email || localUser?.email}
                </p>
                <p className="truncate text-[11px] text-[#94A3B8]">
                  {isAdmin ? (
                    <span className="font-semibold text-[#E5C07B]">Admin Power Active</span>
                  ) : (
                    authUser?.email || localUser?.email
                  )}
                </p>
              </div>
              <button
                type="button"
                onClick={handleGlobalSignOut}
                aria-label="Sign out"
                className="rounded p-1 text-[#94A3B8] hover:text-[#FB7185]"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={isSigningIn}
              onClick={() => setAccountModalOpen(true)}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-3 py-2 text-xs font-semibold text-[#E5C07B] transition-colors hover:border-[#E5C07B] disabled:opacity-50"
            >
              <UserCheck className="h-3.5 w-3.5" />
              <span>{isSigningIn ? 'Signing in...' : 'Sign In / Create Account'}</span>
            </button>
          )}

          <div className="rounded-lg border border-[#24324A] bg-[#080C14] p-3">
            <p className="text-[11px] font-medium text-[#94A3B8]">Active Voice</p>
            <p className="mt-0.5 truncate text-xs font-semibold text-[#F1F5F9]">
              {snapshot.settings.activeCustomVoiceName ||
                `${snapshot.settings.geminiVoicePersona} · Neural`}
            </p>
            <button
              type="button"
              onClick={handleSpeakGreeting}
              className="mt-2.5 inline-flex w-full items-center justify-center gap-1.5 rounded-md border border-[#24324A] bg-[#161F30] px-2.5 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
            >
              <Volume2 className="h-3.5 w-3.5" />
              <span>Speak Greeting</span>
            </button>
            <div className="mt-2 flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setInstallModalOpen(true)}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-md border border-[#E5C07B]/50 bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#E5C07B] transition-colors hover:border-[#E5C07B] hover:text-[#F1F5F9]"
              >
                <Download className="h-3.5 w-3.5" />
                <span>{isStandaloneApp ? 'App Info (v2.5)' : 'Install Latest App'}</span>
              </button>
              <button
                type="button"
                title="Copy latest preview app URL"
                aria-label="Copy latest preview app URL"
                onClick={() => {
                  const previewUrl = window.location.origin;
                  void navigator.clipboard?.writeText(previewUrl);
                  showNotice(`Copied latest preview URL: ${previewUrl}`);
                }}
                className="inline-flex items-center justify-center rounded-md border border-[#24324A] bg-[#080C14] p-1.5 text-[#94A3B8] transition-colors hover:border-[#E5C07B]/60 hover:text-[#E5C07B]"
              >
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Workspace */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* 3-Zone Top Bar */}
        <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-[#24324A] bg-[#101724] px-4 md:px-6">
          {/* Left Zone: Brand on mobile + current view title + PRIME live status indicator */}
          <div className="flex items-center gap-3 min-w-0">
            <span className="font-display text-base font-bold text-[#F1F5F9] md:hidden">
              PRIME
            </span>
            <span className="truncate font-display text-sm font-semibold text-[#F1F5F9]">
              {visibleNavItems.find((n) => n.id === activeView)?.label}
            </span>
            {(() => {
              const stageKey =
                voiceState === 'listening'
                  ? 'listening'
                  : voiceState === 'speaking'
                    ? 'speaking'
                    : processingStage !== 'idle'
                      ? processingStage
                      : isAnalyzingDevice
                        ? 'analyzing'
                        : isRefreshingState
                          ? 'executing'
                          : isProcessing || voiceState === 'thinking' || isBuildingGuide
                            ? 'thinking'
                            : 'idle';

              const statusCfg =
                stageKey === 'listening'
                  ? {
                      stageLabel: 'Listening...',
                      dotClass: 'bg-[#38BDF8] animate-pulse',
                      wrapClass: 'border-[#38BDF8]/45 bg-[#38BDF8]/10 text-[#38BDF8]',
                    }
                  : stageKey === 'analyzing'
                    ? {
                        stageLabel: 'Analyzing...',
                        dotClass: 'bg-[#38BDF8] animate-pulse',
                        wrapClass: 'border-[#38BDF8]/45 bg-[#38BDF8]/10 text-[#38BDF8]',
                      }
                    : stageKey === 'executing'
                      ? {
                          stageLabel: 'Executing...',
                          dotClass: 'bg-[#E5C07B] animate-pulse',
                          wrapClass: 'border-[#E5C07B]/50 bg-[#E5C07B]/10 text-[#E5C07B]',
                        }
                      : stageKey === 'thinking'
                        ? {
                            stageLabel: 'Thinking...',
                            dotClass: 'bg-[#E5C07B] animate-pulse',
                            wrapClass: 'border-[#E5C07B]/50 bg-[#E5C07B]/10 text-[#E5C07B]',
                          }
                        : stageKey === 'speaking'
                          ? {
                              stageLabel: 'Speaking...',
                              dotClass: 'bg-[#34D399] animate-pulse',
                              wrapClass: 'border-[#34D399]/45 bg-[#34D399]/10 text-[#34D399]',
                            }
                          : {
                              stageLabel: 'Idle',
                              dotClass: 'bg-[#64748B]',
                              wrapClass: 'border-[#24324A] bg-[#080C14] text-[#94A3B8]',
                            };

              return (
                <div
                  role="status"
                  aria-live="polite"
                  aria-label={`PRIME Status: ${statusCfg.stageLabel}`}
                  title={`PRIME Status: ${statusCfg.stageLabel}`}
                  className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium font-mono-tabular whitespace-nowrap shrink-0 transition-colors ${statusCfg.wrapClass}`}
                >
                  <span className={`h-1.5 w-1.5 rounded-full ${statusCfg.dotClass}`} />
                  <span className="hidden lg:inline opacity-75">PRIME Status:</span>
                  <span>{statusCfg.stageLabel}</span>
                </div>
              );
            })()}
          </div>

          {/* Center Zone: Brain Depth & Web Search toggles */}
          <div className="hidden items-center gap-2 sm:flex">
            <button
              type="button"
              onClick={() =>
                handleUpdateSettings({
                  brainDepth: snapshot.settings.brainDepth === 'deep' ? 'fast' : 'deep',
                })
              }
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                snapshot.settings.brainDepth === 'deep'
                  ? 'border-[#E5C07B]/60 bg-[#161F30] text-[#E5C07B]'
                  : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
              }`}
            >
              <Brain className="h-3.5 w-3.5" />
              <span>{snapshot.settings.brainDepth === 'deep' ? 'Deep Brain' : 'Fast Brain'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                handleUpdateSettings({webSearchEnabled: !snapshot.settings.webSearchEnabled})
              }
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                snapshot.settings.webSearchEnabled
                  ? 'border-[#38BDF8]/50 bg-[#161F30] text-[#38BDF8]'
                  : 'border-[#24324A] bg-[#080C14] text-[#64748B]'
              }`}
            >
              <Globe className="h-3.5 w-3.5" />
              <span>{snapshot.settings.webSearchEnabled ? 'Web Search On' : 'Offline Mode'}</span>
            </button>
          </div>

          {/* Right Zone: Refresh, Account, Android APK & Create Voice CTA */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={refreshState}
              disabled={isRefreshingState}
              aria-label="Refresh PRIME workspace"
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#94A3B8] transition-colors hover:border-[#E5C07B]/60 hover:text-[#F1F5F9] disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <RefreshCw
                className={`h-3.5 w-3.5 text-[#38BDF8] ${isRefreshingState ? 'animate-spin' : ''}`}
              />
              <span className="hidden lg:inline">Refresh</span>
            </button>

            <button
              type="button"
              onClick={() => setAccountModalOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#F1F5F9] transition-colors hover:border-[#E5C07B]/60 whitespace-nowrap shrink-0"
            >
              <UserCheck className="h-3.5 w-3.5 text-[#E5C07B]" />
              <span className="hidden sm:inline">
                {authUser || localUser ? (isAdmin ? 'Admin' : 'Account') : 'Sign In'}
              </span>
            </button>

            {!isStandaloneApp && (
              <button
                type="button"
                onClick={() => setInstallModalOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5C07B]/45 bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] transition-colors hover:border-[#E5C07B] whitespace-nowrap shrink-0"
              >
                <Download className="h-3.5 w-3.5 text-[#E5C07B]" />
                <span className="hidden md:inline">Install App</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                setActiveView('studio');
                setVoiceCreatorModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3.5 py-1.5 text-xs font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] whitespace-nowrap shrink-0"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Create Voice</span>
            </button>
          </div>
        </header>

        {/* Notification Banner */}
        {notice && (
          <div className="flex items-center justify-between gap-3 border-b border-[#24324A] bg-[#161F30] px-4 py-2 text-xs text-[#F1F5F9] md:px-6">
            <span>{notice}</span>
            <button
              type="button"
              onClick={() => setNotice(null)}
              aria-label="Dismiss notification"
              className="text-[#94A3B8] hover:text-[#F1F5F9]"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {/* Active View Content */}
        <main className="min-h-0 flex-1 overflow-hidden p-4 md:p-6">
          <div className="mx-auto h-full max-w-[1100px]">
            {activeView === 'companion' && (
              <CompanionView
                messages={snapshot.messages}
                tasks={snapshot.tasks}
                settings={snapshot.settings}
                voiceState={voiceState}
                partialTranscript={partialTranscript}
                draftInput={draftInput}
                attachedImageDataUrl={attachedImageDataUrl}
                isProcessing={isProcessing}
                isAnalyzingDevice={isAnalyzingDevice}
                isBuildingGuide={isBuildingGuide}
                activeHowToGuide={activeHowToGuide}
                activeDeviceAnalysis={activeDeviceAnalysis}
                freeFirePlaystyle={freeFirePlaystyle}
                freeFireGrip={freeFireGrip}
                voiceCommandHistory={voiceCommandHistory}
                tokenStats={snapshot.tokenStats}
                onDraftChange={setDraftInput}
                onSend={handleSend}
                onReplayVoiceCommand={(cmd) => void handleVoiceTranscript(cmd)}
                onClearCommandHistory={clearVoiceCommandHistory}
                onAttachImage={setAttachedImageDataUrl}
                onMicToggle={handleMicToggle}
                onBargeInAndListen={handleBargeInAndListen}
                onSpeakMessage={(text, styleOverride) =>
                  void speakText(text, undefined, styleOverride)
                }
                onStopSpeaking={handleStopSpeaking}
                onUpdateSettings={handleUpdateSettings}
                onAddSuggestedTask={async (title, priority) => {
                  await handleAddTask(title, priority, '');
                  showNotice(`Added suggested task "${title}" to Vault.`);
                }}
                onAddAllSuggestedTasks={async (items) => {
                  if (items.length === 0) return;
                  for (const item of items) {
                    await handleAddTask(item.title, item.priority, '');
                  }
                  showNotice(`Added all ${items.length} suggested task(s) to Vault.`);
                }}
                onExecuteVoiceShortcutExample={handleExecuteVoiceShortcutExample}
                onAnalyzeMobile={() =>
                  void handleAnalyzeMobileDevice({
                    customQuery:
                      'Analyze my mobile hardware and create Free Fire sensitivity settings.',
                  })
                }
                onAnalyzeScreen={() =>
                  void handleAnalyzeMobileDevice({
                    captureScreen: true,
                    customQuery:
                      draftInput.trim() ||
                      'Analyze this screen and provide actionable steps and device settings.',
                  })
                }
                onShowMeHow={() =>
                  void handleBuildHowToGuide(
                    draftInput.trim() ||
                      'Show me how to set up PRIME voice boss mode, Free Fire sensitivity, and automated YouTube posting',
                  )
                }
                onSaveFactToVault={async (fact) => {
                  const res = await fetch('/api/prime/memories', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({category: 'Preference', fact}),
                  });
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    showNotice('Saved calibrated settings to Memory Vault.');
                  }
                }}
                onChangeFreeFirePlaystyle={setFreeFirePlaystyle}
                onChangeFreeFireGrip={setFreeFireGrip}
                onDismissHowToGuide={() => setActiveHowToGuide(null)}
                onDismissDeviceAnalysis={() => setActiveDeviceAnalysis(null)}
                onOpenWorkforce={() => setActiveView('workforce')}
                onNotify={showNotice}
              />
            )}

            {activeView === 'gamespace' && (
              <GameSpaceView
                gameSpace={snapshot.gameSpace ?? DEFAULT_GAME_SPACE_STATE}
                onUpdateGameSpace={handleUpdateGameSpace}
                onSpeakStatus={(text) => void speakText(text)}
                onNotify={showNotice}
              />
            )}

            {activeView === 'workforce' && (
              <WorkforceView
                settings={snapshot.settings}
                tasks={snapshot.tasks}
                tokenStats={snapshot.tokenStats}
                workforcePlan={snapshot.workforcePlan}
                nexusImport={snapshot.nexusImport}
                onSnapshotUpdated={(updated) => setSnapshot(updated)}
                onUpdateSettings={handleUpdateSettings}
                onSpeakText={speakText}
                onRetryAllAgendaFailed={handleRetryAllFailedTasks}
                onNotify={showNotice}
              />
            )}

            {activeView === 'skills' && (
              <SkillsView
                autoLearnEnabled={snapshot.settings.autoLearnEnabled}
                passiveLearnEnabled={snapshot.settings.passiveLearnEnabled}
                learnedCount={
                  snapshot.memories.filter((m) => m.category === 'Learned').length
                }
                passiveObservations={snapshot.passiveObservations ?? []}
                onToggleAutoLearn={(enabled) =>
                  handleUpdateSettings({autoLearnEnabled: enabled})
                }
                onTogglePassiveLearn={(enabled) =>
                  handleUpdateSettings({passiveLearnEnabled: enabled})
                }
                onAutoLearnTopic={async (topic, notes) => {
                  const res = await fetch('/api/prime/auto-learn', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({topic, notes}),
                  });
                  const data = await res.json();
                  if (!res.ok) {
                    throw new Error(data.error || 'Auto-learn failed.');
                  }
                  setSnapshot(data.snapshot as PrimeVaultSnapshot);
                  return {
                    topic: data.topic,
                    summary: data.summary,
                    learnedFacts: data.learnedFacts,
                  } as LearnedTopicResult;
                }}
                onScanPassiveActivity={async () => {
                  const res = await fetch('/api/prime/passive-learn/scan', {method: 'POST'});
                  const data = await res.json();
                  if (!res.ok) throw new Error(data.error || 'Passive scan failed.');
                  setSnapshot(data.snapshot as PrimeVaultSnapshot);
                }}
                onPromoteObservation={async (id) => {
                  const res = await fetch(
                    `/api/prime/passive-learn/${encodeURIComponent(id)}/promote`,
                    {method: 'POST'},
                  );
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    showNotice('Saved passive observation into Memory Vault.');
                  }
                }}
                onDismissObservation={async (id) => {
                  const res = await fetch(
                    `/api/prime/passive-learn/${encodeURIComponent(id)}`,
                    {method: 'DELETE'},
                  );
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                  }
                }}
                onLaunchSkill={handleLaunchSkill}
                onNotify={showNotice}
              />
            )}

            {activeView === 'vault' && (
              <VaultView
                memories={snapshot.memories}
                tasks={snapshot.tasks}
                requestedTab={vaultRequestedTab}
                clearMemorySignal={clearMemorySignal}
                onAddTask={handleAddTask}
                onToggleTask={async (id) => {
                  const res = await fetch(`/api/prime/tasks/${encodeURIComponent(id)}/toggle`, {
                    method: 'PATCH',
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onDeleteTask={async (id) => {
                  const res = await fetch(`/api/prime/tasks/${encodeURIComponent(id)}`, {
                    method: 'DELETE',
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onUpdateTaskDetails={handleUpdateTaskDetails}
                onBulkToggleTasks={async (ids) => {
                  if (ids.length === 0) return;
                  const res = await fetch('/api/prime/tasks/bulk-toggle', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ids}),
                  });
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    return;
                  }
                  let latest: PrimeVaultSnapshot | null = null;
                  for (const id of ids) {
                    const step = await fetch(`/api/prime/tasks/${encodeURIComponent(id)}/toggle`, {
                      method: 'PATCH',
                    });
                    if (step.ok) latest = (await step.json()) as PrimeVaultSnapshot;
                  }
                  if (latest) setSnapshot(latest);
                }}
                onBulkDeleteTasks={async (ids) => {
                  if (ids.length === 0) return;
                  const res = await fetch('/api/prime/tasks/bulk-delete', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ids}),
                  });
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    return;
                  }
                  let latest: PrimeVaultSnapshot | null = null;
                  for (const id of ids) {
                    const step = await fetch(`/api/prime/tasks/${encodeURIComponent(id)}`, {
                      method: 'DELETE',
                    });
                    if (step.ok) latest = (await step.json()) as PrimeVaultSnapshot;
                  }
                  if (latest) setSnapshot(latest);
                }}
                onReorderTasks={async (orderedIds) => {
                  if (orderedIds.length === 0) return;
                  setSnapshot((prev) => {
                    const byId = new Map(prev.tasks.map((t) => [t.id, t]));
                    const nextTasks = [];
                    const seen = new Set<string>();
                    for (const id of orderedIds) {
                      const task = byId.get(id);
                      if (task && !seen.has(id)) {
                        nextTasks.push(task);
                        seen.add(id);
                      }
                    }
                    for (const task of prev.tasks) {
                      if (!seen.has(task.id)) nextTasks.push(task);
                    }
                    return {...prev, tasks: nextTasks};
                  });
                  try {
                    const res = await fetch('/api/prime/tasks/reorder', {
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({orderedIds}),
                    });
                    if (res.ok) {
                      setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    }
                  } catch {
                    // Optimistic UI order remains intact
                  }
                }}
                onAddMemory={async (category, fact) => {
                  const res = await fetch('/api/prime/memories', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({category, fact}),
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onDeleteMemory={async (id) => {
                  const res = await fetch(`/api/prime/memories/${encodeURIComponent(id)}`, {
                    method: 'DELETE',
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onClearMemories={async () => {
                  const res = await fetch('/api/prime/memories', {method: 'DELETE'});
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    showNotice('Cleared Memory Vault.');
                  }
                }}
                onRetryTask={handleRetryTask}
                onRetryAllFailed={handleRetryAllFailedTasks}
                onRefresh={refreshState}
                onNotify={showNotice}
              />
            )}

            {activeView === 'studio' && (
              <VoiceStudioView
                settings={snapshot.settings}
                voiceProfiles={snapshot.voiceProfiles}
                creatorModalOpen={voiceCreatorModalOpen}
                onOpenCreatorModal={() => setVoiceCreatorModalOpen(true)}
                onCloseCreatorModal={() => setVoiceCreatorModalOpen(false)}
                onUpdateSettings={handleUpdateSettings}
                onCreateVoice={async (payload: Omit<VoiceProfile, 'id' | 'createdAtMs'>) => {
                  const res = await fetch('/api/prime/voices', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({...payload, activate: true}),
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onUpdateVoice={async (
                  id: string,
                  payload: Omit<VoiceProfile, 'id' | 'createdAtMs'>,
                ) => {
                  const res = await fetch(`/api/prime/voices/${encodeURIComponent(id)}`, {
                    method: 'PUT',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(payload),
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onActivateVoice={async (id: string) => {
                  const res = await fetch(`/api/prime/voices/${encodeURIComponent(id)}/activate`, {
                    method: 'POST',
                  });
                  if (res.ok) {
                    const updated = (await res.json()) as PrimeVaultSnapshot;
                    setSnapshot(updated);
                    showNotice(
                      `Activated voice "${updated.settings.activeCustomVoiceName ?? 'Custom'}".`,
                    );
                  }
                }}
                onDeleteVoice={async (id: string) => {
                  const res = await fetch(`/api/prime/voices/${encodeURIComponent(id)}`, {
                    method: 'DELETE',
                  });
                  if (res.ok) setSnapshot((await res.json()) as PrimeVaultSnapshot);
                }}
                onSpeakGreeting={handleSpeakGreeting}
                onResetChat={async () => {
                  const res = await fetch('/api/prime/chat/reset', {method: 'POST'});
                  if (res.ok) {
                    setSnapshot((await res.json()) as PrimeVaultSnapshot);
                    showNotice('Started a fresh conversation.');
                  }
                }}
                onNotify={showNotice}
              />
            )}

            {activeView === 'youtube' && (
              <YouTubePipelineView
                settings={snapshot.settings}
                batchVideos={snapshot.batchVideos}
                youtubeAgents={snapshot.youtubeAgents}
                youtubePostQueue={snapshot.youtubePostQueue}
                youtubeAgentSettings={snapshot.youtubeAgentSettings}
                onSnapshotUpdated={(updated) => setSnapshot(updated)}
                initialTopic={youtubePrefillTopic}
                onConsumeInitialTopic={() => setYoutubePrefillTopic('')}
                onNotify={showNotice}
              />
            )}

            {activeView === 'admin' && isAdmin && (
              <AdminConsoleView
                onSnapshotUpdated={(updated) => setSnapshot(updated)}
                onNotify={showNotice}
              />
            )}
          </div>
        </main>

        {/* Mobile Bottom Navigation */}
        <nav
          aria-label="Mobile Navigation"
          className="flex shrink-0 items-center justify-around border-t border-[#24324A] bg-[#101724] px-2 py-2 md:hidden"
        >
          {visibleNavItems.map((item) => {
            const Icon = item.icon;
            const active = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveView(item.id)}
                className={`flex flex-col items-center gap-0.5 rounded-lg px-2.5 py-1 text-[11px] font-medium ${
                  active ? 'text-[#E5C07B]' : 'text-[#94A3B8]'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </nav>
        <AccountModal
          open={accountModalOpen}
          user={authUser}
          localUser={localUser}
          isAdmin={isAdmin}
          isSigningIn={isSigningIn}
          onSignInGoogle={handleGlobalSignIn}
          onLocalLogin={handleLocalLogin}
          onLocalRegister={handleLocalRegister}
          onSignOut={handleGlobalSignOut}
          onOpenAdminConsole={() => setActiveView('admin')}
          onClose={() => setAccountModalOpen(false)}
        />
        <InstallAppModal
          open={installModalOpen}
          installPromptEvent={installPromptEvent}
          onConsumeInstallPrompt={() => setInstallPromptEvent(null)}
          onClose={() => setInstallModalOpen(false)}
          onNotify={showNotice}
        />
        {!isOnline && (
          <div className="fixed bottom-16 left-4 z-50 flex items-center gap-2 rounded-lg border border-[#F59E0B]/50 bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#F59E0B] md:bottom-4">
            <span className="h-2 w-2 rounded-full bg-[#F59E0B] animate-pulse" />
            <span>Offline Mode — Cached shell active</span>
          </div>
        )}
        <BackgroundBossHud
          visible={Boolean(snapshot.settings.backgroundListenMode)}
          voiceState={voiceState}
          wakeWordEnabled={snapshot.settings.wakeWordEnabled}
          wakeResponsePhrase={snapshot.settings.wakeResponsePhrase || 'What happened, boss?'}
          lastBossTriggerAtMs={lastBossTriggerAtMs}
          onMicToggle={handleMicToggle}
          onAnalyzeMobile={() =>
            void handleAnalyzeMobileDevice({
              customQuery:
                'Analyze my mobile hardware and create Free Fire sensitivity settings.',
            })
          }
          onAnalyzeScreen={() =>
            void handleAnalyzeMobileDevice({
              captureScreen: true,
              customQuery: 'Analyze this screen and provide recommended actions.',
            })
          }
          onQuickHowTo={() =>
            void handleBuildHowToGuide(
              draftInput.trim() ||
                'How to get maximum headshot accuracy and smooth FPS on mobile',
            )
          }
          onDisableHud={() => void handleUpdateSettings({backgroundListenMode: false})}
          onNotify={showNotice}
        />
      </div>
    </div>
  );
}
