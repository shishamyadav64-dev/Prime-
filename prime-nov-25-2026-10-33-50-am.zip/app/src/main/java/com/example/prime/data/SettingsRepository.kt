package com.example.prime.data

import android.content.Context
import com.example.prime.model.BrainDepth
import com.example.prime.model.GeminiVoicePersona
import com.example.prime.model.MannerProfile
import com.example.prime.model.PrimeSettings
import com.example.prime.model.VocalStylePreset
import com.example.prime.model.VoiceEngineMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("prime_settings", Context.MODE_PRIVATE)

  private val _settings = MutableStateFlow(load())
  val settings: StateFlow<PrimeSettings> = _settings.asStateFlow()

  private fun load(): PrimeSettings {
    val mannerName = prefs.getString(KEY_MANNER, MannerProfile.REFINED_GENTLEMAN.name)
    val voiceEngineName = prefs.getString(KEY_VOICE_ENGINE, VoiceEngineMode.DEVICE_TTS.name)
    val personaName = prefs.getString(KEY_PERSONA, GeminiVoicePersona.CHARON.name)
    val vocalStyleName = prefs.getString(KEY_VOCAL_STYLE, VocalStylePreset.REFINED_BUTLER.name)
    val depthName = prefs.getString(KEY_DEPTH, BrainDepth.HYDROGEN_FAST.name)
    val customVoiceId = prefs.getLong(KEY_CUSTOM_VOICE_ID, -1L).takeIf { it > 0L }

    return PrimeSettings(
      preferredTitle = prefs.getString(KEY_TITLE, "Sir") ?: "Sir",
      mannerProfile = MannerProfile.entries.firstOrNull { it.name == mannerName }
        ?: MannerProfile.REFINED_GENTLEMAN,
      autoSpeakGreeting = prefs.getBoolean(KEY_AUTO_GREET, true),
      autoSpeakReplies = prefs.getBoolean(KEY_AUTO_REPLY, false),
      voiceEngine = VoiceEngineMode.entries.firstOrNull { it.name == voiceEngineName }
        ?: VoiceEngineMode.DEVICE_TTS,
      geminiVoicePersona = GeminiVoicePersona.entries.firstOrNull { it.name == personaName }
        ?: GeminiVoicePersona.CHARON,
      vocalStyle = VocalStylePreset.entries.firstOrNull { it.name == vocalStyleName }
        ?: VocalStylePreset.REFINED_BUTLER,
      deviceLocaleTag = prefs.getString(KEY_DEVICE_LOCALE, "en-GB") ?: "en-GB",
      deviceVoiceName = prefs.getString(KEY_DEVICE_VOICE, "") ?: "",
      devicePitch = prefs.getFloat(KEY_PITCH, 0.96f),
      deviceSpeechRate = prefs.getFloat(KEY_RATE, 1.0f),
      activeCustomVoiceId = customVoiceId,
      activeCustomVoiceName = prefs.getString(KEY_CUSTOM_VOICE_NAME, null),
      brainDepth = BrainDepth.entries.firstOrNull { it.name == depthName }
        ?: BrainDepth.HYDROGEN_FAST,
      webSearchEnabled = prefs.getBoolean(KEY_WEB_SEARCH, true),
      showReasoningTrace = prefs.getBoolean(KEY_REASONING_TRACE, true),
    )
  }

  fun update(transform: (PrimeSettings) -> PrimeSettings) {
    val updated = transform(_settings.value)
    _settings.value = updated
    prefs.edit()
      .putString(KEY_TITLE, updated.preferredTitle)
      .putString(KEY_MANNER, updated.mannerProfile.name)
      .putBoolean(KEY_AUTO_GREET, updated.autoSpeakGreeting)
      .putBoolean(KEY_AUTO_REPLY, updated.autoSpeakReplies)
      .putString(KEY_VOICE_ENGINE, updated.voiceEngine.name)
      .putString(KEY_PERSONA, updated.geminiVoicePersona.name)
      .putString(KEY_VOCAL_STYLE, updated.vocalStyle.name)
      .putString(KEY_DEVICE_LOCALE, updated.deviceLocaleTag)
      .putString(KEY_DEVICE_VOICE, updated.deviceVoiceName)
      .putFloat(KEY_PITCH, updated.devicePitch)
      .putFloat(KEY_RATE, updated.deviceSpeechRate)
      .putLong(KEY_CUSTOM_VOICE_ID, updated.activeCustomVoiceId ?: -1L)
      .putString(KEY_CUSTOM_VOICE_NAME, updated.activeCustomVoiceName)
      .putString(KEY_DEPTH, updated.brainDepth.name)
      .putBoolean(KEY_WEB_SEARCH, updated.webSearchEnabled)
      .putBoolean(KEY_REASONING_TRACE, updated.showReasoningTrace)
      .apply()
  }

  private companion object {
    const val KEY_TITLE = "preferred_title"
    const val KEY_MANNER = "manner_profile"
    const val KEY_AUTO_GREET = "auto_speak_greeting"
    const val KEY_AUTO_REPLY = "auto_speak_replies"
    const val KEY_VOICE_ENGINE = "voice_engine"
    const val KEY_PERSONA = "gemini_persona"
    const val KEY_VOCAL_STYLE = "vocal_style"
    const val KEY_DEVICE_LOCALE = "device_locale"
    const val KEY_DEVICE_VOICE = "device_voice_name"
    const val KEY_PITCH = "device_pitch"
    const val KEY_RATE = "device_rate"
    const val KEY_CUSTOM_VOICE_ID = "active_custom_voice_id"
    const val KEY_CUSTOM_VOICE_NAME = "active_custom_voice_name"
    const val KEY_DEPTH = "brain_depth"
    const val KEY_WEB_SEARCH = "web_search"
    const val KEY_REASONING_TRACE = "reasoning_trace"
  }
}
