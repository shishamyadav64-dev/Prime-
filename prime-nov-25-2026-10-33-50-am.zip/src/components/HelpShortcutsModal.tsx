import {useEffect, useMemo, useState} from 'react';
import {Mic, Play, Search, X} from 'lucide-react';
import {VOICE_SHORTCUTS, type VoiceShortcutDefinition} from '../types/prime.ts';

interface HelpShortcutsModalProps {
  open: boolean;
  wakeWordEnabled: boolean;
  onClose: () => void;
  onRunExample?: (shortcut: VoiceShortcutDefinition) => void;
}

const CATEGORIES: Array<'All' | VoiceShortcutDefinition['category']> = [
  'All',
  'Agenda',
  'Memory',
  'Navigation',
  'Cognition',
];

export function HelpShortcutsModal({
  open,
  wakeWordEnabled,
  onClose,
  onRunExample,
}: HelpShortcutsModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<
    'All' | VoiceShortcutDefinition['category']
  >('All');

  useEffect(() => {
    if (!open) return;
    const handleKey = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  const filteredShortcuts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return VOICE_SHORTCUTS.filter((item) => {
      const catOk = selectedCategory === 'All' || item.category === selectedCategory;
      if (!catOk) return false;
      if (!q) return true;
      return (
        item.phrase.toLowerCase().includes(q) ||
        item.example.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, selectedCategory]);

  if (!open) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Shortcut Help and Voice Commands"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
    >
      <div className="w-full max-w-2xl rounded-xl border border-[#24324A] bg-[#101724] p-6">
        <div className="flex items-start justify-between gap-4 border-b border-[#24324A] pb-4">
          <div>
            <h2 className="flex items-center gap-2 font-display text-lg font-semibold text-[#F1F5F9]">
              <Mic className="h-4 w-4 text-[#E5C07B]" />
              <span>Shortcut Help &amp; Voice Commands</span>
            </h2>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Speak any phrase below using the microphone or{' '}
              {wakeWordEnabled
                ? 'hands-free wake word ("Hey PRIME" is active).'
                : 'turn on Wake "Prime" in Companion controls for hands-free activation.'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shortcuts guide"
            className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Search & Category Filter */}
        <div className="mt-4 flex flex-col gap-2.5 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#64748B]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(ev) => setSearchQuery(ev.target.value)}
              placeholder="Search commands (Add a task, Clear memory, Refresh data...)"
              aria-label="Filter voice shortcuts"
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] py-1.5 pl-8 pr-3 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1">
            {CATEGORIES.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setSelectedCategory(category)}
                className={`rounded-md border px-2 py-1 text-[11px] font-medium transition-colors ${
                  selectedCategory === category
                    ? 'border-[#E5C07B]/60 bg-[#161F30] text-[#E5C07B]'
                    : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-3 grid max-h-[54vh] grid-cols-1 gap-2.5 overflow-y-auto pr-1 sm:grid-cols-2">
          {filteredShortcuts.length === 0 ? (
            <div className="col-span-full rounded-xl border border-dashed border-[#24324A] bg-[#080C14] p-6 text-center text-xs text-[#94A3B8]">
              No voice shortcuts match &ldquo;{searchQuery}&rdquo;.
            </div>
          ) : (
            filteredShortcuts.map((item) => (
              <div
                key={item.id}
                className="flex flex-col justify-between gap-2 rounded-xl border border-[#24324A] bg-[#080C14] p-3.5"
              >
                <div>
                  <p className="text-[11px] font-medium text-[#E5C07B] font-mono-tabular">
                    {item.category}
                  </p>
                  <p className="mt-0.5 text-sm font-semibold text-[#F1F5F9]">{item.phrase}</p>
                  <p className="mt-1 text-xs leading-relaxed text-[#94A3B8]">{item.description}</p>
                </div>
                <div className="flex items-center justify-between gap-2 border-t border-[#24324A]/60 pt-2">
                  <span className="truncate text-[11px] text-[#38BDF8] font-mono-tabular">
                    {item.example}
                  </span>
                  {onRunExample && item.id !== 'wake_word' && (
                    <button
                      type="button"
                      onClick={() => {
                        onRunExample(item);
                        onClose();
                      }}
                      className="inline-flex shrink-0 items-center gap-1 rounded-md border border-[#24324A] bg-[#161F30] px-2 py-1 text-[11px] font-medium text-[#E5C07B] hover:border-[#E5C07B]"
                    >
                      <Play className="h-2.5 w-2.5" />
                      <span>Try</span>
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="mt-5 flex items-center justify-between gap-3 border-t border-[#24324A] pt-4">
          <span className="text-[11px] text-[#64748B] font-mono-tabular">
            Showing {filteredShortcuts.length} of {VOICE_SHORTCUTS.length} voice commands · Press Esc to close
          </span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
