package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimeObsidian = Color(0xFF080C14)
val PrimeSurface = Color(0xFF101724)
val PrimeCard = Color(0xFF161F30)
val PrimeCardElevated = Color(0xFF1C283E)
val PrimeBorder = Color(0xFF27354F)

val PrimeGold = Color(0xFFE5C07B)
val PrimeGoldSoft = Color(0x33E5C07B)
val PrimeCyan = Color(0xFF38BDF8)
val PrimeCyanSoft = Color(0x2B38BDF8)
val PrimeMint = Color(0xFF34D399)
val PrimeAmber = Color(0xFFFBBF24)
val PrimeRose = Color(0xFFFB7185)

val PrimeTextPrimary = Color(0xFFF1F5F9)
val PrimeTextSecondary = Color(0xFF94A3B8)
val PrimeTextTertiary = Color(0xFF64748B)
