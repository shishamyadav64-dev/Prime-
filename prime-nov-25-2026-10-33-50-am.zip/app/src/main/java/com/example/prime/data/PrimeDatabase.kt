package com.example.prime.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "prime_voices")
data class VoiceProfileEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0L,
  val name: String,
  val engineMode: String,
  val geminiPersona: String,
  val vocalStyle: String,
  val deviceLocaleTag: String,
  val deviceVoiceName: String,
  val pitch: Float,
  val speechRate: Float,
  val samplePhrase: String,
  val createdAtMs: Long = System.currentTimeMillis(),
)

@Entity(tableName = "prime_memories")
data class MemoryEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0L,
  val category: String,
  val fact: String,
  val createdAtMs: Long = System.currentTimeMillis(),
)

@Entity(tableName = "prime_tasks")
data class TaskEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0L,
  val title: String,
  val priority: String = "Normal",
  val dueNote: String = "",
  val isCompleted: Boolean = false,
  val createdAtMs: Long = System.currentTimeMillis(),
)

@Entity(tableName = "prime_messages")
data class ChatMessageEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0L,
  val isUser: Boolean,
  val text: String,
  val reasoningTrace: String? = null,
  val sourcesSerialized: String = "",
  val toolActionsSerialized: String = "",
  val deviceActionSerialized: String = "",
  val imageUriString: String? = null,
  val isError: Boolean = false,
  val timestampMs: Long = System.currentTimeMillis(),
)

@Dao
interface PrimeDao {
  @Query("SELECT * FROM prime_memories ORDER BY createdAtMs DESC")
  fun observeMemories(): Flow<List<MemoryEntity>>

  @Query("SELECT * FROM prime_memories ORDER BY createdAtMs DESC")
  suspend fun getMemoriesOnce(): List<MemoryEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMemory(memory: MemoryEntity): Long

  @Delete
  suspend fun deleteMemory(memory: MemoryEntity)

  @Query("DELETE FROM prime_memories")
  suspend fun clearMemories()

  @Query("SELECT * FROM prime_tasks ORDER BY isCompleted ASC, createdAtMs DESC")
  fun observeTasks(): Flow<List<TaskEntity>>

  @Query("SELECT * FROM prime_tasks WHERE isCompleted = 0 ORDER BY createdAtMs DESC")
  suspend fun getPendingTasksOnce(): List<TaskEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: TaskEntity): Long

  @Update
  suspend fun updateTask(task: TaskEntity)

  @Delete
  suspend fun deleteTask(task: TaskEntity)

  @Query("SELECT * FROM prime_messages ORDER BY timestampMs ASC, id ASC")
  fun observeMessages(): Flow<List<ChatMessageEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: ChatMessageEntity): Long

  @Query("DELETE FROM prime_messages")
  suspend fun clearMessages()

  @Query("SELECT * FROM prime_voices ORDER BY createdAtMs DESC")
  fun observeVoiceProfiles(): Flow<List<VoiceProfileEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertVoiceProfile(profile: VoiceProfileEntity): Long

  @Update
  suspend fun updateVoiceProfile(profile: VoiceProfileEntity)

  @Delete
  suspend fun deleteVoiceProfile(profile: VoiceProfileEntity)
}

@Database(
  entities =
    [
      MemoryEntity::class,
      TaskEntity::class,
      ChatMessageEntity::class,
      VoiceProfileEntity::class,
    ],
  version = 2,
  exportSchema = false,
)
abstract class PrimeDatabase : RoomDatabase() {
  abstract fun primeDao(): PrimeDao

  companion object {
    @Volatile private var INSTANCE: PrimeDatabase? = null

    private val MIGRATION_1_2 =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `prime_voices` (
              `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
              `name` TEXT NOT NULL,
              `engineMode` TEXT NOT NULL,
              `geminiPersona` TEXT NOT NULL,
              `vocalStyle` TEXT NOT NULL,
              `deviceLocaleTag` TEXT NOT NULL,
              `deviceVoiceName` TEXT NOT NULL,
              `pitch` REAL NOT NULL,
              `speechRate` REAL NOT NULL,
              `samplePhrase` TEXT NOT NULL,
              `createdAtMs` INTEGER NOT NULL
            )
            """.trimIndent()
          )
        }
      }

    fun getInstance(context: Context): PrimeDatabase {
      return INSTANCE
        ?: synchronized(this) {
          INSTANCE
            ?: Room.databaseBuilder(
                context.applicationContext,
                PrimeDatabase::class.java,
                "prime_brain.db",
              )
              .addMigrations(MIGRATION_1_2)
              .fallbackToDestructiveMigration()
              .build()
              .also { INSTANCE = it }
        }
    }
  }
}
