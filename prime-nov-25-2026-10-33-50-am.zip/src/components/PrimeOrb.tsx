import {Mic, Brain, Square, AudioLines} from 'lucide-react';
import type {VoiceState} from '../types/prime.ts';

interface PrimeOrbProps {
  voiceState: VoiceState;
  partialTranscript: string;
  preferredTitle: string;
  onOrbClick: () => void;
}

export function PrimeOrb({
  voiceState,
  partialTranscript,
  preferredTitle,
  onOrbClick,
}: PrimeOrbProps) {
  const headline =
    voiceState === 'listening'
      ? 'Listening attentively...'
      : voiceState === 'thinking'
        ? 'Reasoning through your request...'
        : voiceState === 'speaking'
          ? 'Speaking — click core to stop'
          : `At your service, ${preferredTitle || 'friend'}`;

  const subtext =
    voiceState === 'listening' && partialTranscript
      ? `"${partialTranscript}"`
      : voiceState === 'listening'
        ? 'Speak naturally; your words will appear here.'
        : voiceState === 'thinking'
          ? 'Checking memory vault, tools, and grounded sources.'
          : voiceState === 'speaking'
            ? 'Delivering spoken response.'
            : 'Click the core to speak by microphone, or compose below.';

  const accentColor =
    voiceState === 'listening'
      ? '#38BDF8'
      : voiceState === 'speaking'
        ? '#34D399'
        : '#E5C07B';

  return (
    <section
      aria-label="PRIME Core Status"
      className="flex items-center gap-4 rounded-xl border border-[#24324A] bg-[#101724] px-5 py-4"
    >
      <button
        type="button"
        onClick={onOrbClick}
        aria-label={
          voiceState === 'speaking'
            ? 'Stop speaking'
            : voiceState === 'listening'
              ? 'Stop listening'
              : 'Start voice input'
        }
        className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-[#24324A] bg-[#080C14] transition-transform duration-150 hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5C07B]"
      >
        <svg
          viewBox="0 0 64 64"
          className={`absolute inset-0 h-full w-full ${
            voiceState === 'thinking' ? 'animate-spin' : ''
          }`}
          style={{animationDuration: '4.5s'}}
          aria-hidden="true"
        >
          <circle
            cx="32"
            cy="32"
            r="28"
            fill="none"
            stroke={accentColor}
            strokeOpacity="0.22"
            strokeWidth="1.5"
          />
          <path
            d="M 32 4 A 28 28 0 0 1 58 24"
            fill="none"
            stroke={accentColor}
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <path
            d="M 32 60 A 28 28 0 0 1 6 40"
            fill="none"
            stroke="#38BDF8"
            strokeOpacity="0.7"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>

        {voiceState === 'listening' ? (
          <AudioLines className="h-5 w-5 text-[#38BDF8]" />
        ) : voiceState === 'thinking' ? (
          <Brain className="h-5 w-5 text-[#E5C07B]" />
        ) : voiceState === 'speaking' ? (
          <Square className="h-4 w-4 text-[#34D399]" />
        ) : (
          <Mic className="h-5 w-5 text-[#E5C07B]" />
        )}
      </button>

      <div className="min-w-0 flex-1">
        <h2 className="font-display text-base font-semibold text-[#F1F5F9] truncate">
          {headline}
        </h2>
        <p
          className={`mt-0.5 text-sm truncate ${
            voiceState === 'listening' ? 'text-[#38BDF8]' : 'text-[#94A3B8]'
          }`}
        >
          {subtext}
        </p>
      </div>
    </section>
  );
}
