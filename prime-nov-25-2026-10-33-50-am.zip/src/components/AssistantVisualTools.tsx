import {useState} from 'react';
import {
  CheckCircle2,
  ChevronRight,
  Copy,
  Crosshair,
  ListChecks,
  MonitorSmartphone,
  RotateCcw,
  Save,
  Smartphone,
  Volume2,
  X,
} from 'lucide-react';
import type {DeviceAnalysisResult, HowToGuideResult} from '../types/prime.ts';

interface HowToGuidePanelProps {
  guide: HowToGuideResult;
  onSpeakText: (text: string) => void;
  onSaveAsTask: (title: string) => void;
  onClose: () => void;
}

export function HowToGuidePanel({
  guide,
  onSpeakText,
  onSaveAsTask,
  onClose,
}: HowToGuidePanelProps) {
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});
  const [activeStepNum, setActiveStepNum] = useState<number>(
    guide.steps[0]?.stepNumber ?? 1,
  );

  const toggleStep = (stepNumber: number) => {
    setCompletedSteps((prev) => {
      const next = {...prev, [stepNumber]: !prev[stepNumber]};
      if (!prev[stepNumber]) {
        const nextStep = guide.steps.find((s) => s.stepNumber > stepNumber);
        if (nextStep) setActiveStepNum(nextStep.stepNumber);
      }
      return next;
    });
  };

  const completedCount = guide.steps.filter((s) => completedSteps[s.stepNumber]).length;
  const pct =
    guide.steps.length > 0 ? Math.round((completedCount / guide.steps.length) * 100) : 0;

  return (
    <section
      aria-label="Visual Step-by-Step Guide"
      className="rounded-xl border border-[#38BDF8]/50 bg-[#101724] p-4 shadow-lg"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#38BDF8]">
            <ListChecks className="h-4 w-4 shrink-0" />
            <span>PRIME Visual Walkthrough · {pct}% Complete</span>
          </div>
          <h3 className="mt-1 font-display text-base font-bold text-[#F1F5F9]">{guide.title}</h3>
          <p className="mt-0.5 text-xs text-[#94A3B8]">{guide.summary}</p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() =>
              onSpeakText(
                `${guide.title}. ${guide.steps
                  .map((s) => `Step ${s.stepNumber}: ${s.actionTitle}. ${s.instruction}`)
                  .join(' ')}`,
              )
            }
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
          >
            <Volume2 className="h-3.5 w-3.5" />
            <span>Read Steps</span>
          </button>
          <button
            type="button"
            onClick={() => onSaveAsTask(`Follow guide: ${guide.title}`)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#34D399] hover:border-[#34D399]"
          >
            <Save className="h-3.5 w-3.5" />
            <span>Save to Vault</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close visual guide"
            className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-[#080C14]">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#38BDF8] to-[#34D399] transition-all"
          style={{width: `${Math.max(4, pct)}%`}}
        />
      </div>

      {/* Visual Step Cards */}
      <div className="mt-3 grid grid-cols-1 gap-2.5 md:grid-cols-2">
        {guide.steps.map((step) => {
          const isDone = !!completedSteps[step.stepNumber];
          const isActive = activeStepNum === step.stepNumber && !isDone;
          return (
            <div
              key={step.stepNumber}
              onClick={() => setActiveStepNum(step.stepNumber)}
              className={`cursor-pointer rounded-lg border p-3 transition-colors ${
                isDone
                  ? 'border-[#34D399]/40 bg-[#080C14]/70 opacity-80'
                  : isActive
                    ? 'border-[#E5C07B]/70 bg-[#161F30]'
                    : 'border-[#24324A] bg-[#080C14] hover:border-[#38BDF8]/40'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(ev) => {
                      ev.stopPropagation();
                      toggleStep(step.stepNumber);
                    }}
                    aria-label={`Toggle step ${step.stepNumber}`}
                    className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md border text-xs font-mono-tabular font-bold ${
                      isDone
                        ? 'border-[#34D399] bg-[#34D399]/20 text-[#34D399]'
                        : isActive
                          ? 'border-[#E5C07B] bg-[#E5C07B]/15 text-[#E5C07B]'
                          : 'border-[#24324A] bg-[#101724] text-[#94A3B8]'
                    }`}
                  >
                    {isDone ? <CheckCircle2 className="h-3.5 w-3.5" /> : step.stepNumber}
                  </button>
                  <span className="text-xs font-semibold text-[#F1F5F9]">{step.actionTitle}</span>
                </div>

                <span className="rounded bg-[#101724] px-1.5 py-0.5 text-[10px] font-mono-tabular font-semibold text-[#38BDF8]">
                  {step.visualBadge}
                </span>
              </div>

              <p className="mt-2 text-xs leading-relaxed text-[#CBD5E1]">{step.instruction}</p>
              {step.tip && (
                <p className="mt-1.5 flex items-center gap-1 text-[11px] text-[#E5C07B]">
                  <ChevronRight className="h-3 w-3 shrink-0" />
                  <span>{step.tip}</span>
                </p>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

interface DeviceAnalysisPanelProps {
  analysis: DeviceAnalysisResult;
  playstyle: string;
  fingerGrip: string;
  isRecalculating: boolean;
  onChangePlaystyle: (style: string) => void;
  onChangeFingerGrip: (grip: string) => void;
  onRecalculate: () => void;
  onSpeakText: (text: string) => void;
  onSaveToVault: (summaryFact: string) => void;
  onNotify: (msg: string) => void;
  onClose: () => void;
}

const SENSITIVITY_SLIDERS: Array<{
  key: 'general' | 'redDot' | 'scope2x' | 'scope4x' | 'sniperScope' | 'freeLook';
  label: string;
  accent: string;
}> = [
  {key: 'general', label: 'General', accent: 'bg-[#E5C07B]'},
  {key: 'redDot', label: 'Red Dot', accent: 'bg-[#FB7185]'},
  {key: 'scope2x', label: '2x Scope', accent: 'bg-[#38BDF8]'},
  {key: 'scope4x', label: '4x Scope', accent: 'bg-[#34D399]'},
  {key: 'sniperScope', label: 'Sniper Scope', accent: 'bg-[#C084FC]'},
  {key: 'freeLook', label: 'Free Look', accent: 'bg-[#FBBF24]'},
];

export function DeviceAnalysisPanel({
  analysis,
  playstyle,
  fingerGrip,
  isRecalculating,
  onChangePlaystyle,
  onChangeFingerGrip,
  onRecalculate,
  onSpeakText,
  onSaveToVault,
  onNotify,
  onClose,
}: DeviceAnalysisPanelProps) {
  const ff = analysis.freeFireSensitivity;

  const formatCopyText = () => {
    if (!ff) return analysis.deviceSummary;
    return [
      `PRIME Free Fire Sensitivity (${analysis.telemetry.deviceModelHint} · ${analysis.telemetry.estimatedRefreshHz}Hz)`,
      `Playstyle: ${ff.playstyle} (${fingerGrip})`,
      `General: ${ff.general} | Red Dot: ${ff.redDot}`,
      `2x Scope: ${ff.scope2x} | 4x Scope: ${ff.scope4x}`,
      `Sniper Scope: ${ff.sniperScope} | Free Look: ${ff.freeLook}`,
      `Recommended Android DPI: ${ff.recommendedDpi} | Fire Button: ${ff.fireButtonSizePct}%`,
      `Graphics: ${ff.graphicsPreset}`,
    ].join('\n');
  };

  return (
    <section
      aria-label="Mobile Hardware & Free Fire Sensitivity Analyzer"
      className="rounded-xl border border-[#E5C07B]/50 bg-[#101724] p-4 shadow-lg"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-[#E5C07B]">
            <Smartphone className="h-4 w-4 shrink-0" />
            <span>Mobile &amp; Screen Analyzer</span>
            <span className="rounded border border-[#34D399]/50 bg-[#080C14] px-2 py-0.5 text-[11px] text-[#34D399]">
              {analysis.performanceTier}
            </span>
            {analysis.screenshotAttached && (
              <span className="rounded border border-[#38BDF8]/50 bg-[#080C14] px-2 py-0.5 text-[11px] text-[#38BDF8]">
                Screen Analyzed
              </span>
            )}
          </div>
          <p className="mt-1.5 text-sm font-medium text-[#F1F5F9]">{analysis.deviceSummary}</p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              const spoken = ff
                ? `Your ${analysis.telemetry.deviceModelHint} is tuned for ${ff.playstyle}. Set General to ${ff.general}, Red Dot ${ff.redDot}, 2x Scope ${ff.scope2x}, 4x Scope ${ff.scope4x}, Sniper Scope ${ff.sniperScope}, DPI ${ff.recommendedDpi}, and Fire Button ${ff.fireButtonSizePct} percent.`
                : analysis.deviceSummary;
              onSpeakText(spoken);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
          >
            <Volume2 className="h-3.5 w-3.5" />
            <span>Speak</span>
          </button>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard?.writeText(formatCopyText());
              onNotify('Copied Free Fire sensitivity settings.');
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B]"
          >
            <Copy className="h-3.5 w-3.5" />
            <span>Copy</span>
          </button>
          <button
            type="button"
            onClick={() => onSaveToVault(formatCopyText())}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#34D399] hover:border-[#34D399]"
          >
            <Save className="h-3.5 w-3.5" />
            <span>Save</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close device analysis"
            className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Measured Device Specs Strip */}
      <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] font-mono-tabular sm:grid-cols-5">
        <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
          <p className="text-[#64748B]">Device</p>
          <p className="truncate font-semibold text-[#F1F5F9]">
            {analysis.telemetry.deviceModelHint}
          </p>
        </div>
        <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
          <p className="text-[#64748B]">Display</p>
          <p className="font-semibold text-[#38BDF8]">
            {analysis.telemetry.screenWidth}x{analysis.telemetry.screenHeight} ·{' '}
            {analysis.telemetry.estimatedRefreshHz}Hz
          </p>
        </div>
        <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
          <p className="text-[#64748B]">Memory / CPU</p>
          <p className="font-semibold text-[#F1F5F9]">
            {analysis.telemetry.ramGb ?? '?'}GB · {analysis.telemetry.cpuCores ?? '?'} cores
          </p>
        </div>
        <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
          <p className="text-[#64748B]">GPU</p>
          <p className="truncate font-semibold text-[#94A3B8]">{analysis.telemetry.gpuRenderer}</p>
        </div>
        <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
          <p className="text-[#64748B]">Touch / DPR</p>
          <p className="font-semibold text-[#34D399]">
            {analysis.telemetry.maxTouchPoints}pt · {analysis.telemetry.devicePixelRatio}x
          </p>
        </div>
      </div>

      <p className="mt-2.5 text-xs leading-relaxed text-[#CBD5E1]">
        <strong className="text-[#38BDF8]">Findings:</strong> {analysis.screenFindings}{' '}
        <span className="text-[#94A3B8]">{analysis.touchResponseNote}</span>
      </p>

      {/* Free Fire Sensitivity Tuner */}
      {ff && (
        <div className="mt-3 rounded-lg border border-[#24324A] bg-[#080C14] p-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#E5C07B]">
              <Crosshair className="h-4 w-4" />
              <span>Free Fire / MAX Sensitivity Calibration (0–200 Scale)</span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={playstyle}
                onChange={(ev) => onChangePlaystyle(ev.target.value)}
                aria-label="Free Fire Playstyle"
                className="rounded-md border border-[#24324A] bg-[#101724] px-2 py-1 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              >
                <option value="One-Tap Headshot">One-Tap Headshot</option>
                <option value="Close-Range Rusher">Close-Range Rusher</option>
                <option value="Balanced Ranked">Balanced Ranked</option>
                <option value="AWM / Sniper">AWM / Sniper</option>
              </select>

              <select
                value={fingerGrip}
                onChange={(ev) => onChangeFingerGrip(ev.target.value)}
                aria-label="Finger Grip"
                className="rounded-md border border-[#24324A] bg-[#101724] px-2 py-1 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              >
                <option value="2-Finger / Thumb">2-Finger Thumb</option>
                <option value="3-Finger Claw">3-Finger Claw</option>
                <option value="4-Finger Claw">4-Finger Claw</option>
              </select>

              <button
                type="button"
                disabled={isRecalculating}
                onClick={onRecalculate}
                className="inline-flex items-center gap-1 rounded-md bg-[#E5C07B] px-2.5 py-1 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-50"
              >
                <RotateCcw className={`h-3 w-3 ${isRecalculating ? 'animate-spin' : ''}`} />
                <span>{isRecalculating ? 'Tuning...' : 'Recalibrate'}</span>
              </button>
            </div>
          </div>

          <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {SENSITIVITY_SLIDERS.map((slider) => {
              const value = ff[slider.key];
              const pct = Math.min(100, Math.round((value / 200) * 100));
              return (
                <div
                  key={slider.key}
                  className="rounded-md border border-[#24324A] bg-[#101724] px-3 py-2"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#94A3B8]">{slider.label}</span>
                    <span className="font-mono-tabular text-sm font-bold text-[#F1F5F9]">
                      {value}
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-[#080C14]">
                    <div className={`h-full rounded-full ${slider.accent}`} style={{width: `${pct}%`}} />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-[#24324A] pt-2.5 text-xs font-mono-tabular">
            <span className="inline-flex items-center gap-1.5 text-[#38BDF8]">
              <MonitorSmartphone className="h-3.5 w-3.5" />
              Android DPI: <strong>{ff.recommendedDpi}</strong>
            </span>
            <span className="text-[#94A3B8]">·</span>
            <span className="text-[#34D399]">
              Fire Button: <strong>{ff.fireButtonSizePct}%</strong>
            </span>
            <span className="text-[#94A3B8]">·</span>
            <span className="text-[#E5C07B]">
              Graphics: <strong>{ff.graphicsPreset}</strong>
            </span>
          </div>

          {ff.headshotTips.length > 0 && (
            <ul className="mt-2.5 grid grid-cols-1 gap-1 text-[11px] text-[#CBD5E1] sm:grid-cols-2">
              {ff.headshotTips.map((tip, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <span className="text-[#E5C07B]">•</span>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </section>
  );
}
