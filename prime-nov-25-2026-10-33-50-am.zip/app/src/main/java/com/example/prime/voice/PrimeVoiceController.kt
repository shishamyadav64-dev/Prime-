package com.example.prime.voice

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.prime.brain.PrimeGeminiClient
import com.example.prime.brain.PrimePersonality
import com.example.prime.model.DeviceVoiceOption
import com.example.prime.model.MannerProfile
import com.example.prime.model.PrimeSettings
import com.example.prime.model.VoiceEngineMode
import com.example.prime.model.VoiceState
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PrimeVoiceController(
  private val context: Context,
  private val geminiClient: PrimeGeminiClient,
  private val scope: CoroutineScope,
) {
  private val appContext = context.applicationContext
  private val mainHandler = Handler(Looper.getMainLooper())

  private val _voiceState = MutableStateFlow(VoiceState.IDLE)
  val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

  private val _partialTranscript = MutableStateFlow("")
  val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

  private val _audioLevel = MutableStateFlow(0f)
  val audioLevel: StateFlow<Float> = _audioLevel.asStateFlow()

  private val _availableDeviceVoices = MutableStateFlow<List<DeviceVoiceOption>>(emptyList())
  val availableDeviceVoices: StateFlow<List<DeviceVoiceOption>> = _availableDeviceVoices.asStateFlow()

  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var pendingDeviceUtterance: Pair<String, PrimeSettings>? = null

  private var speechRecognizer: SpeechRecognizer? = null
  private var neuralPlaybackJob: Job? = null
  private var activeAudioTrack: AudioTrack? = null

  init {
    initDeviceTts()
  }

  private fun initDeviceTts() {
    tts =
      TextToSpeech(appContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          ttsReady = true
          refreshAvailableDeviceVoices()
          tts?.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
              override fun onStart(utteranceId: String?) {
                _voiceState.value = VoiceState.SPEAKING
                _audioLevel.value = 0.65f
              }

              override fun onDone(utteranceId: String?) {
                if (_voiceState.value == VoiceState.SPEAKING) {
                  _voiceState.value = VoiceState.IDLE
                  _audioLevel.value = 0f
                }
              }

              @Deprecated("Deprecated in Java")
              override fun onError(utteranceId: String?) {
                if (_voiceState.value == VoiceState.SPEAKING) {
                  _voiceState.value = VoiceState.IDLE
                  _audioLevel.value = 0f
                }
              }
            }
          )
          pendingDeviceUtterance?.let { (text, settings) ->
            pendingDeviceUtterance = null
            speakViaDeviceTts(text, settings)
          }
        }
      }
  }

  private fun refreshAvailableDeviceVoices() {
    val voices = runCatching { tts?.voices }.getOrNull().orEmpty()
    val mapped =
      voices
        .filter { !it.isNetworkConnectionRequired && it.locale.language == "en" }
        .ifEmpty { voices.filter { it.locale.language == "en" } }
        .sortedWith(compareBy({ it.locale.toLanguageTag() }, { it.name }))
        .take(18)
        .mapIndexed { idx, voice ->
          val tag = voice.locale.toLanguageTag()
          val region =
            when {
              tag.startsWith("en-GB", ignoreCase = true) -> "UK"
              tag.startsWith("en-US", ignoreCase = true) -> "US"
              tag.startsWith("en-AU", ignoreCase = true) -> "AU"
              tag.startsWith("en-IN", ignoreCase = true) -> "IN"
              else -> tag.uppercase()
            }
          val shortCode = voice.name.substringAfterLast("-").take(8).uppercase()
          DeviceVoiceOption(
            name = voice.name,
            label = "$region Voice ${idx + 1} ($shortCode)",
            localeTag = tag,
          )
        }
    _availableDeviceVoices.value = mapped
  }

  fun speak(rawText: String, settings: PrimeSettings) {
    val clean = PrimePersonality.sanitizeForSpeech(rawText)
    if (clean.isBlank()) return

    stopSpeaking()

    if (
      settings.voiceEngine == VoiceEngineMode.GEMINI_NEURAL_TTS &&
        geminiClient.hasValidApiKey()
    ) {
      neuralPlaybackJob =
        scope.launch {
          _voiceState.value = VoiceState.SPEAKING
          val pcmResult =
            geminiClient.synthesizeSpeechPcm(
              text = clean,
              voiceName = settings.geminiVoicePersona.voiceId,
              vocalDirection = settings.vocalStyle.direction,
            )
          pcmResult
            .onSuccess { pcmBytes ->
              playPcmAudio(pcmBytes)
            }
            .onFailure {
              // Seamless fallback to offline Android TTS
              withContext(Dispatchers.Main) { speakViaDeviceTts(clean, settings) }
            }
        }
    } else {
      speakViaDeviceTts(clean, settings)
    }
  }

  private fun speakViaDeviceTts(cleanText: String, settings: PrimeSettings) {
    if (!ttsReady) {
      pendingDeviceUtterance = cleanText to settings
      return
    }
    val engine = tts ?: return
    val matchedVoice =
      if (settings.deviceVoiceName.isNotBlank()) {
        runCatching { engine.voices?.firstOrNull { it.name == settings.deviceVoiceName } }.getOrNull()
      } else {
        null
      }

    if (matchedVoice != null) {
      engine.voice = matchedVoice
    } else {
      val preferredLocale =
        when {
          settings.deviceLocaleTag.isNotBlank() && settings.deviceLocaleTag != "auto" ->
            Locale.forLanguageTag(settings.deviceLocaleTag)
          settings.mannerProfile == MannerProfile.REFINED_GENTLEMAN -> Locale.UK
          else -> Locale.US
        }
      val langResult = engine.setLanguage(preferredLocale)
      if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
        engine.setLanguage(Locale.getDefault())
      }
    }
    engine.setPitch(settings.devicePitch.coerceIn(0.6f, 1.4f))
    engine.setSpeechRate(settings.deviceSpeechRate.coerceIn(0.6f, 1.5f))

    val params = Bundle()
    val utteranceId = UUID.randomUUID().toString()
    _voiceState.value = VoiceState.SPEAKING
    engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
  }

  private suspend fun playPcmAudio(pcmBytes: ByteArray) =
    withContext(Dispatchers.IO) {
      val sampleRate = 24000
      val minBuffer =
        AudioTrack.getMinBufferSize(
          sampleRate,
          AudioFormat.CHANNEL_OUT_MONO,
          AudioFormat.ENCODING_PCM_16BIT,
        )
      val track =
        AudioTrack.Builder()
          .setAudioAttributes(
            AudioAttributes.Builder()
              .setUsage(AudioAttributes.USAGE_ASSISTANT)
              .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
              .build()
          )
          .setAudioFormat(
            AudioFormat.Builder()
              .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
              .setSampleRate(sampleRate)
              .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
              .build()
          )
          .setBufferSizeInBytes(maxOf(minBuffer, 8192))
          .setTransferMode(AudioTrack.MODE_STREAM)
          .build()

      activeAudioTrack = track
      try {
        track.play()
        var offset = 0
        val chunkSize = 4096
        while (offset < pcmBytes.size && isActive) {
          val len = minOf(chunkSize, pcmBytes.size - offset)
          val written = track.write(pcmBytes, offset, len)
          if (written <= 0) break

          // Estimate RMS amplitude for orb animation
          var sum = 0.0
          var idx = offset
          while (idx + 1 < offset + len) {
            val sample = ((pcmBytes[idx + 1].toInt() shl 8) or (pcmBytes[idx].toInt() and 0xFF)).toShort()
            sum += sample * sample
            idx += 2
          }
          val count = maxOf(1, len / 2)
          val rms = kotlin.math.sqrt(sum / count).toFloat() / 12000f
          _audioLevel.value = rms.coerceIn(0.15f, 1f)

          offset += written
        }
        track.stop()
      } finally {
        runCatching { track.release() }
        if (activeAudioTrack === track) activeAudioTrack = null
        if (_voiceState.value == VoiceState.SPEAKING) {
          _voiceState.value = VoiceState.IDLE
          _audioLevel.value = 0f
        }
      }
    }

  fun stopSpeaking() {
    neuralPlaybackJob?.cancel()
    neuralPlaybackJob = null
    runCatching {
      activeAudioTrack?.pause()
      activeAudioTrack?.flush()
      activeAudioTrack?.release()
    }
    activeAudioTrack = null
    runCatching { tts?.stop() }
    if (_voiceState.value == VoiceState.SPEAKING) {
      _voiceState.value = VoiceState.IDLE
      _audioLevel.value = 0f
    }
  }

  fun startListening(
    onFinalResult: (String) -> Unit,
    onErrorMessage: (String) -> Unit,
  ) {
    stopSpeaking()
    mainHandler.post {
      if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
        onErrorMessage("On-device speech recognition is unavailable on this device.")
        _voiceState.value = VoiceState.IDLE
        return@post
      }

      runCatching { speechRecognizer?.destroy() }
      val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
      speechRecognizer = recognizer
      _partialTranscript.value = ""
      _voiceState.value = VoiceState.LISTENING

      recognizer.setRecognitionListener(
        object : RecognitionListener {
          override fun onReadyForSpeech(params: Bundle?) {
            _voiceState.value = VoiceState.LISTENING
          }

          override fun onBeginningOfSpeech() {}

          override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            _audioLevel.value = normalized
          }

          override fun onBufferReceived(buffer: ByteArray?) {}

          override fun onEndOfSpeech() {
            _audioLevel.value = 0f
          }

          override fun onError(error: Int) {
            _voiceState.value = VoiceState.IDLE
            _audioLevel.value = 0f
            _partialTranscript.value = ""
            if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
              onErrorMessage("Voice input paused (code $error). You can also type anytime.")
            }
          }

          override fun onResults(results: Bundle?) {
            _voiceState.value = VoiceState.IDLE
            _audioLevel.value = 0f
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()?.trim().orEmpty()
            _partialTranscript.value = ""
            if (text.isNotEmpty()) {
              onFinalResult(text)
            }
          }

          override fun onPartialResults(partialResults: Bundle?) {
            val partial =
              partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            _partialTranscript.value = partial
          }

          override fun onEvent(eventType: Int, params: Bundle?) {}
        }
      )

      val intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
          putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
          )
          putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
          putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
      recognizer.startListening(intent)
    }
  }

  fun stopListening() {
    mainHandler.post {
      runCatching { speechRecognizer?.stopListening() }
      if (_voiceState.value == VoiceState.LISTENING) {
        _voiceState.value = VoiceState.IDLE
        _audioLevel.value = 0f
      }
      _partialTranscript.value = ""
    }
  }

  fun setThinking(thinking: Boolean) {
    if (thinking) {
      stopSpeaking()
      _voiceState.value = VoiceState.THINKING
    } else if (_voiceState.value == VoiceState.THINKING) {
      _voiceState.value = VoiceState.IDLE
    }
  }

  fun release() {
    stopSpeaking()
    mainHandler.post {
      runCatching { speechRecognizer?.destroy() }
      speechRecognizer = null
    }
    runCatching {
      tts?.stop()
      tts?.shutdown()
    }
    tts = null
  }
}
