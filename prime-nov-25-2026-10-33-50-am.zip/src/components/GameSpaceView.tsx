import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {
  Activity,
  BatteryCharging,
  BellOff,
  Crosshair,
  Download,
  Eye,
  Fan,
  Flame,
  Gamepad2,
  Gauge,
  Layers,
  Mic,
  PhoneOff,
  Play,
  Plus,
  RotateCcw,
  Shield,
  Sliders,
  Sparkles,
  Square,
  Timer,
  Trash2,
  Vibrate,
  Video,
  Zap,
} from 'lucide-react';
import type {
  CrosshairStyle,
  DeviceTelemetry,
  GameMacro,
  GameProfileItem,
  GameSpaceMode,
  GameSpaceState,
  HuntFilterMode,
  TouchResponsePreset,
  VibrationIntensity,
} from '../types/prime.ts';
import {collectDeviceTelemetry} from '../utils/deviceAnalyzer.ts';

interface GameSpaceViewProps {
  gameSpace: GameSpaceState;
  onUpdateGameSpace: (patch: Partial<GameSpaceState>) => Promise<void>;
  onSpeakStatus?: (text: string) => void;
  onNotify: (msg: string) => void;
}

type GameSpaceTab = 'library' | 'cooling' | 'triggers' | 'plugins';

interface ArenaTarget {
  id: number;
  xPct: number;
  yPct: number;
  radiusPx: number;
  spawnedAtMs: number;
}

const MODE_CONFIGS: Array<{
  id: GameSpaceMode;
  label: string;
  sublabel: string;
  clockLabel: string;
  accentClass: string;
}> = [
  {
    id: 'eco',
    label: 'Eco',
    sublabel: 'Battery Saver · 60Hz Lock',
    clockLabel: '75% Clock',
    accentClass: 'border-[#34D399] bg-[#34D399]/10 text-[#34D399]',
  },
  {
    id: 'balance',
    label: 'Balance',
    sublabel: 'Steady Thermals · Adaptive',
    clockLabel: '90% Clock',
    accentClass: 'border-[#38BDF8] bg-[#38BDF8]/10 text-[#38BDF8]',
  },
  {
    id: 'rise',
    label: 'Rise',
    sublabel: 'High FPS Performance Boost',
    clockLabel: '100% Clock',
    accentClass: 'border-[#E5C07B] bg-[#E5C07B]/10 text-[#E5C07B]',
  },
  {
    id: 'diablo',
    label: 'Diablo',
    sublabel: 'Max CPU/GPU · Max Cooling',
    clockLabel: '115% Turbo',
    accentClass: 'border-[#FB7185] bg-[#FB7185]/15 text-[#FB7185]',
  },
];

const HUNT_FILTERS: Array<{id: HuntFilterMode; label: string; cssFilter: string}> = [
  {id: 'none', label: 'Standard', cssFilter: 'none'},
  {
    id: 'night_vision',
    label: 'Night Vision',
    cssFilter: 'brightness(1.25) contrast(1.3) sepia(1) hue-rotate(80deg) saturate(2.1)',
  },
  {
    id: 'edge_clarity',
    label: 'Edge Clarity',
    cssFilter: 'contrast(1.45) brightness(1.1) saturate(1.25)',
  },
  {
    id: 'high_contrast',
    label: 'High Contrast',
    cssFilter: 'contrast(1.65) grayscale(0.25)',
  },
  {
    id: 'anti_flash',
    label: 'Anti-Flash',
    cssFilter: 'invert(0.92) hue-rotate(180deg) contrast(1.1)',
  },
];

const CROSSHAIR_COLORS = ['#E5C07B', '#34D399', '#FB7185', '#38BDF8', '#F1F5F9'];
const TRIGGER_ACTIONS = [
  'Scope / ADS',
  'Primary Fire',
  'Crouch / Drop Shot',
  'Jump / Vault',
  'Reload',
  'Gloo Wall',
  'Peek Left',
  'Peek Right',
];

function renderCrosshairSvg(style: CrosshairStyle, color: string, size: number) {
  if (style === 'off') return null;
  const half = size / 2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="pointer-events-none">
      {style === 'dot' && <circle cx={half} cy={half} r={Math.max(2, size * 0.14)} fill={color} />}
      {style === 'cross' && (
        <g stroke={color} strokeWidth={2} strokeLinecap="round">
          <line x1={half} y1={2} x2={half} y2={half - 3} />
          <line x1={half} y1={half + 3} x2={half} y2={size - 2} />
          <line x1={2} y1={half} x2={half - 3} y2={half} />
          <line x1={half + 3} y1={half} x2={size - 2} y2={half} />
        </g>
      )}
      {style === 'circle_dot' && (
        <g>
          <circle
            cx={half}
            cy={half}
            r={Math.max(5, half - 3)}
            fill="none"
            stroke={color}
            strokeWidth={1.75}
          />
          <circle cx={half} cy={half} r={2} fill={color} />
        </g>
      )}
      {style === 'chevron' && (
        <g fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <polyline points={`${half - 6},${half + 5} ${half},${half - 3} ${half + 6},${half + 5}`} />
          <circle cx={half} cy={half + 1} r={1.5} fill={color} stroke="none" />
        </g>
      )}
    </svg>
  );
}

export function GameSpaceView({
  gameSpace,
  onUpdateGameSpace,
  onSpeakStatus,
  onNotify,
}: GameSpaceViewProps) {
  const [activeTab, setActiveTab] = useState<GameSpaceTab>('library');
  const [hudOpen, setHudOpen] = useState(false);

  // Real device telemetry + real FPS counter
  const [telemetry, setTelemetry] = useState<DeviceTelemetry | null>(null);
  const [liveFps, setLiveFps] = useState<number>(60);
  const [frameTimeMs, setFrameTimeMs] = useState<number>(16.7);
  const [isAiTuning, setIsAiTuning] = useState(false);
  const [aiRationale, setAiRationale] = useState<string | null>(null);
  const [playstyleInput, setPlaystyleInput] = useState('One-Tap Headshot');

  // Add custom game modal/form state
  const [addingGame, setAddingGame] = useState(false);
  const [newGameName, setNewGameName] = useState('');
  const [newGameGenre, setNewGameGenre] = useState('Competitive Shooter');

  // Add custom macro state
  const [newMacroName, setNewMacroName] = useState('');
  const [newMacroHotkey, setNewMacroHotkey] = useState('F3');
  const [newMacroSteps, setNewMacroSteps] = useState('ADS:0, Fire:40, Crouch:90');
  const [runningMacroStatus, setRunningMacroStatus] = useState<string | null>(null);

  // Live trigger & gyro testing state
  const [pressedKeys, setPressedKeys] = useState<{left: boolean; right: boolean}>({
    left: false,
    right: false,
  });
  const [gyroAngles, setGyroAngles] = useState<{beta: number; gamma: number}>({
    beta: 0,
    gamma: 0,
  });

  // Web Audio cooling fan synthesizer
  const [fanSoundOn, setFanSoundOn] = useState(false);
  const fanAudioRef = useRef<{ctx: AudioContext; osc: OscillatorNode; gain: GainNode} | null>(null);

  // Wake Lock API handle
  const wakeLockRef = useRef<{release: () => Promise<void>} | null>(null);
  const [wakeLockActive, setWakeLockActive] = useState(false);

  // Screen Recorder (MediaRecorder + getDisplayMedia)
  const [isRecordingClip, setIsRecordingClip] = useState(false);
  const [recordedClipUrl, setRecordedClipUrl] = useState<string | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);

  // Match stopwatch
  const [stopwatchRunning, setStopwatchRunning] = useState(false);
  const [stopwatchSec, setStopwatchSec] = useState(0);

  // Interactive Target Practice & Aim Lab
  const [target, setTarget] = useState<ArenaTarget>({
    id: 1,
    xPct: 50,
    yPct: 50,
    radiusPx: 26,
    spawnedAtMs: Date.now(),
  });
  const [aimStats, setAimStats] = useState({
    shots: 0,
    hits: 0,
    headshots: 0,
    lastReactionMs: 0,
  });
  const [arenaCursor, setArenaCursor] = useState<{x: number; y: number; inside: boolean}>({
    x: 50,
    y: 50,
    inside: false,
  });

  const activeGame = useMemo(
    () => gameSpace.games.find((g) => g.id === gameSpace.activeGameId) ?? gameSpace.games[0],
    [gameSpace.activeGameId, gameSpace.games],
  );

  // Collect real browser telemetry
  const scanTelemetry = useCallback(async () => {
    const info = await collectDeviceTelemetry();
    setTelemetry(info);
  }, []);

  useEffect(() => {
    void scanTelemetry();
  }, [scanTelemetry]);

  // Real requestAnimationFrame FPS monitor
  useEffect(() => {
    let rafId = 0;
    let frames = 0;
    let lastSample = performance.now();

    const tick = (now: number) => {
      frames += 1;
      const elapsed = now - lastSample;
      if (elapsed >= 800) {
        const measured = Math.max(1, Math.round((frames * 1000) / elapsed));
        setLiveFps(measured);
        setFrameTimeMs(Number((elapsed / frames).toFixed(1)));
        frames = 0;
        lastSample = now;
      }
      rafId = window.requestAnimationFrame(tick);
    };

    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, []);

  // Real Screen Wake Lock management
  useEffect(() => {
    let active = true;
    const syncWakeLock = async () => {
      const nav = navigator as unknown as {
        wakeLock?: {request: (t: 'screen') => Promise<{release: () => Promise<void>}>};
      };
      if (!nav.wakeLock) return;
      if (gameSpace.keepScreenAwake) {
        try {
          const lock = await nav.wakeLock.request('screen');
          if (active) {
            wakeLockRef.current = lock;
            setWakeLockActive(true);
          } else {
            await lock.release();
          }
        } catch {
          setWakeLockActive(false);
        }
      } else if (wakeLockRef.current) {
        try {
          await wakeLockRef.current.release();
        } catch {
          // ignore
        }
        wakeLockRef.current = null;
        setWakeLockActive(false);
      }
    };
    void syncWakeLock();
    return () => {
      active = false;
      if (wakeLockRef.current) {
        void wakeLockRef.current.release().catch(() => {});
        wakeLockRef.current = null;
      }
    };
  }, [gameSpace.keepScreenAwake]);

  // Keyboard listener for Shoulder Trigger testing (Q = Left Trigger, E = Right Trigger)
  useEffect(() => {
    const onDown = (ev: KeyboardEvent) => {
      const key = ev.key.toLowerCase();
      if (key === 'q' && gameSpace.leftTrigger.enabled) {
        setPressedKeys((p) => ({...p, left: true}));
      }
      if (key === 'e' && gameSpace.rightTrigger.enabled) {
        setPressedKeys((p) => ({...p, right: true}));
      }
    };
    const onUp = (ev: KeyboardEvent) => {
      const key = ev.key.toLowerCase();
      if (key === 'q') setPressedKeys((p) => ({...p, left: false}));
      if (key === 'e') setPressedKeys((p) => ({...p, right: false}));
    };
    window.addEventListener('keydown', onDown);
    window.addEventListener('keyup', onUp);
    return () => {
      window.removeEventListener('keydown', onDown);
      window.removeEventListener('keyup', onUp);
    };
  }, [gameSpace.leftTrigger.enabled, gameSpace.rightTrigger.enabled]);

  // Gyroscope DeviceOrientation listener when enabled
  useEffect(() => {
    if (!gameSpace.gyroscopeEnabled) return;
    const onOrient = (ev: DeviceOrientationEvent) => {
      if (typeof ev.beta === 'number' && typeof ev.gamma === 'number') {
        setGyroAngles({
          beta: Number(ev.beta.toFixed(1)),
          gamma: Number(ev.gamma.toFixed(1)),
        });
      }
    };
    window.addEventListener('deviceorientation', onOrient);
    return () => window.removeEventListener('deviceorientation', onOrient);
  }, [gameSpace.gyroscopeEnabled]);

  // Match stopwatch interval
  useEffect(() => {
    if (!stopwatchRunning) return;
    const id = window.setInterval(() => setStopwatchSec((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [stopwatchRunning]);

  // Web Audio Cooling Fan hum toggle
  useEffect(() => {
    if (!fanSoundOn || !gameSpace.fanEnabled) {
      if (fanAudioRef.current) {
        try {
          fanAudioRef.current.osc.stop();
          void fanAudioRef.current.ctx.close();
        } catch {
          // ignore
        }
        fanAudioRef.current = null;
      }
      return;
    }

    try {
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const freq = 95 + (gameSpace.fanRpm / 24000) * 140;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.025, ctx.currentTime);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      fanAudioRef.current = {ctx, osc, gain};
    } catch {
      setFanSoundOn(false);
    }

    return () => {
      if (fanAudioRef.current) {
        try {
          fanAudioRef.current.osc.stop();
          void fanAudioRef.current.ctx.close();
        } catch {
          // ignore
        }
        fanAudioRef.current = null;
      }
    };
  }, [fanSoundOn, gameSpace.fanEnabled, gameSpace.fanRpm]);

  const triggerHaptic = (pattern: number | number[] = 25) => {
    if (gameSpace.vibration4d === 'off') return;
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      const scale =
        gameSpace.vibration4d === 'strong' ? 2 : gameSpace.vibration4d === 'light' ? 0.6 : 1;
      if (Array.isArray(pattern)) {
        navigator.vibrate(pattern.map((v) => Math.round(v * scale)));
      } else {
        navigator.vibrate(Math.round(pattern * scale));
      }
    }
  };

  const handleModeChange = async (mode: GameSpaceMode) => {
    const nextFps: GameSpaceState['targetFps'] =
      mode === 'diablo' ? 144 : mode === 'rise' ? 120 : mode === 'balance' ? 90 : 60;
    const nextFanMode = mode === 'diablo' ? 'max' : 'smart';
    const nextRpm = mode === 'diablo' ? 23500 : mode === 'rise' ? 20500 : mode === 'balance' ? 17500 : 14000;
    triggerHaptic(mode === 'diablo' ? [30, 20, 45] : 20);
    await onUpdateGameSpace({
      performanceMode: mode,
      targetFps: nextFps,
      fanEnabled: mode !== 'eco',
      fanMode: nextFanMode,
      fanRpm: nextRpm,
    });
    onNotify(`Switched Game Space to ${mode.toUpperCase()} Mode (${nextFps} FPS cap).`);
  };

  const handleSelectGame = async (game: GameProfileItem) => {
    triggerHaptic(20);
    const updatedGames = gameSpace.games.map((g) =>
      g.id === game.id ? {...g, lastPlayedAtMs: Date.now()} : g,
    );
    await onUpdateGameSpace({
      activeGameId: game.id,
      performanceMode: game.preferredMode,
      targetFps: game.targetFps,
      crosshairStyle: game.crosshairStyle,
      crosshairEnabled: game.crosshairStyle !== 'off',
      huntFilter: game.huntFilter,
      games: updatedGames,
    });
    onNotify(`Loaded "${game.name}" Game Space profile.`);
  };

  const handleUpdateActiveGameSensitivity = async (
    patch: Partial<
      Pick<
        GameProfileItem,
        'sensitivityGeneral' | 'sensitivityRedDot' | 'sensitivity2x' | 'sensitivity4x'
      >
    >,
  ) => {
    if (!activeGame) return;
    const updatedGames = gameSpace.games.map((g) =>
      g.id === activeGame.id ? {...g, ...patch} : g,
    );
    await onUpdateGameSpace({games: updatedGames});
  };

  const handleAiOptimizeGame = async () => {
    if (!activeGame || isAiTuning) return;
    setIsAiTuning(true);
    setAiRationale(null);
    try {
      const liveTel = telemetry ?? (await collectDeviceTelemetry());
      setTelemetry(liveTel);
      const res = await fetch('/api/prime/gamespace/optimize', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          gameName: activeGame.name,
          playstyle: playstyleInput,
          telemetry: liveTel,
        }),
      });
      const data = (await res.json()) as {
        recommendation?: {
          performanceMode: GameSpaceMode;
          targetFps: GameSpaceState['targetFps'];
          fanMode: 'smart' | 'max';
          fanRpm: number;
          touchResponse: TouchResponsePreset;
          crosshairStyle: CrosshairStyle;
          huntFilter: HuntFilterMode;
          sensitivityGeneral: number;
          sensitivityRedDot: number;
          sensitivity2x: number;
          sensitivity4x: number;
          rationale: string;
        };
        error?: string;
      };
      if (!res.ok || !data.recommendation) {
        throw new Error(data.error || 'AI Game Space optimization failed.');
      }
      const rec = data.recommendation;
      const updatedGames = gameSpace.games.map((g) =>
        g.id === activeGame.id
          ? {
              ...g,
              preferredMode: rec.performanceMode,
              targetFps: rec.targetFps,
              crosshairStyle: rec.crosshairStyle,
              huntFilter: rec.huntFilter,
              sensitivityGeneral: rec.sensitivityGeneral,
              sensitivityRedDot: rec.sensitivityRedDot,
              sensitivity2x: rec.sensitivity2x,
              sensitivity4x: rec.sensitivity4x,
            }
          : g,
      );
      await onUpdateGameSpace({
        performanceMode: rec.performanceMode,
        targetFps: rec.targetFps,
        fanMode: rec.fanMode,
        fanRpm: rec.fanRpm,
        touchResponse: rec.touchResponse,
        crosshairStyle: rec.crosshairStyle,
        crosshairEnabled: rec.crosshairStyle !== 'off',
        huntFilter: rec.huntFilter,
        games: updatedGames,
      });
      setAiRationale(rec.rationale);
      triggerHaptic([25, 30, 35]);
      onNotify(`PRIME Auto-Tuned "${activeGame.name}" for ${liveTel.deviceModelHint}.`);
      onSpeakStatus?.(
        `Game Space tuned for ${activeGame.name}. ${rec.performanceMode} mode enabled at ${rec.targetFps} FPS.`,
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Unable to optimize profile.');
    } finally {
      setIsAiTuning(false);
    }
  };

  const handleAddCustomGame = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const clean = newGameName.trim();
    if (!clean) return;
    const item: GameProfileItem = {
      id: `game_${Date.now()}`,
      name: clean,
      genre: newGameGenre.trim() || 'Action',
      preferredMode: gameSpace.performanceMode,
      targetFps: gameSpace.targetFps,
      sensitivityGeneral: 165,
      sensitivityRedDot: 155,
      sensitivity2x: 130,
      sensitivity4x: 110,
      crosshairStyle: gameSpace.crosshairStyle,
      huntFilter: gameSpace.huntFilter,
      lastPlayedAtMs: Date.now(),
    };
    await onUpdateGameSpace({
      activeGameId: item.id,
      games: [...gameSpace.games, item],
    });
    setNewGameName('');
    setAddingGame(false);
    onNotify(`Added "${clean}" to Game Space library.`);
  };

  const handleRunMacro = async (macro: GameMacro) => {
    setRunningMacroStatus(`Running "${macro.name}"...`);
    triggerHaptic(20);
    for (const step of macro.steps) {
      setRunningMacroStatus(`${macro.name}: ${step.action} (${step.delayMs}ms)`);
      await new Promise((r) => window.setTimeout(r, Math.max(80, step.delayMs + 120)));
      triggerHaptic(15);
    }
    setRunningMacroStatus(`Completed "${macro.name}"`);
    window.setTimeout(() => setRunningMacroStatus(null), 1800);
  };

  const handleAddMacro = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const name = newMacroName.trim();
    if (!name) return;
    const parsedSteps = newMacroSteps
      .split(',')
      .map((chunk) => {
        const [act, delayStr] = chunk.split(':');
        return {
          action: (act || '').trim() || 'Tap',
          delayMs: Math.max(0, Math.min(2000, Number(delayStr) || 40)),
        };
      })
      .filter((s) => s.action.length > 0);
    if (parsedSteps.length === 0) return;

    const item: GameMacro = {
      id: `macro_${Date.now()}`,
      name,
      hotkey: newMacroHotkey.trim() || 'F3',
      steps: parsedSteps,
    };
    await onUpdateGameSpace({macros: [...gameSpace.macros, item]});
    setNewMacroName('');
    onNotify(`Saved tactical macro "${name}".`);
  };

  const handleToggleScreenRecord = async () => {
    if (isRecordingClip && recorderRef.current) {
      recorderRef.current.stop();
      setIsRecordingClip(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true,
      });
      const chunks: Blob[] = [];
      const rec = new MediaRecorder(stream);
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, {type: 'video/webm'});
        if (recordedClipUrl) URL.revokeObjectURL(recordedClipUrl);
        setRecordedClipUrl(URL.createObjectURL(blob));
        onNotify('Gameplay clip captured and ready to download.');
      };
      recorderRef.current = rec;
      rec.start();
      setIsRecordingClip(true);
      onNotify('Recording gameplay clip... Click Stop Record when finished.');
    } catch {
      onNotify('Screen recording permission was canceled or is unsupported here.');
    }
  };

  const handleArenaClick = (ev: React.MouseEvent<HTMLDivElement>) => {
    const rect = ev.currentTarget.getBoundingClientRect();
    const clickX = ev.clientX - rect.left;
    const clickY = ev.clientY - rect.top;
    const targetX = (target.xPct / 100) * rect.width;
    const targetY = (target.yPct / 100) * rect.height;
    const dist = Math.hypot(clickX - targetX, clickY - targetY);

    const hit = dist <= target.radiusPx;
    const headshot = dist <= target.radiusPx * 0.42;
    const reaction = Date.now() - target.spawnedAtMs;

    setAimStats((prev) => ({
      shots: prev.shots + 1,
      hits: prev.hits + (hit ? 1 : 0),
      headshots: prev.headshots + (headshot ? 1 : 0),
      lastReactionMs: hit ? reaction : prev.lastReactionMs,
    }));

    if (hit) {
      triggerHaptic(headshot ? [30, 15, 40] : 22);
      setTarget({
        id: target.id + 1,
        xPct: 16 + Math.random() * 68,
        yPct: 20 + Math.random() * 60,
        radiusPx: Math.max(18, 28 - Math.floor(aimStats.hits / 6)),
        spawnedAtMs: Date.now(),
      });
    }
  };

  const currentModeInfo =
    MODE_CONFIGS.find((m) => m.id === gameSpace.performanceMode) ?? MODE_CONFIGS[2];
  const activeHuntCss =
    HUNT_FILTERS.find((f) => f.id === gameSpace.huntFilter)?.cssFilter ?? 'none';

  const accuracyPct =
    aimStats.shots === 0 ? 0 : Math.round((aimStats.hits / aimStats.shots) * 100);
  const thermalEstimateC =
    gameSpace.performanceMode === 'diablo'
      ? gameSpace.fanEnabled
        ? 39
        : 45
      : gameSpace.performanceMode === 'rise'
        ? gameSpace.fanEnabled
          ? 36
          : 41
        : 33;

  const formatStopwatch = (sec: number) => {
    const m = Math.floor(sec / 60)
      .toString()
      .padStart(2, '0');
    const s = (sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="relative flex h-full flex-col gap-5 overflow-y-auto pr-1">
      {/* RedMagic Tactical Header & Mode Strip */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#24324A] pb-4">
        <div>
          <h1 className="flex items-center gap-2.5 font-display text-2xl font-semibold text-[#F1F5F9]">
            <Gamepad2 className="h-6 w-6 text-[#FB7185]" />
            <span>PRIME Game Space</span>
          </h1>
          <p className="mt-1 text-xs text-[#94A3B8] font-mono-tabular">
            <span>{activeGame?.name ?? 'Free Fire MAX'}</span>
            <span aria-hidden="true"> · </span>
            <span className="text-[#E5C07B]">{currentModeInfo.label} Mode</span>
            <span aria-hidden="true"> · </span>
            <span className="text-[#34D399]">{liveFps} FPS ({frameTimeMs}ms)</span>
            <span aria-hidden="true"> · </span>
            <span>{telemetry?.estimatedRefreshHz ?? 60}Hz Panel</span>
            <span aria-hidden="true"> · </span>
            <span>{thermalEstimateC}°C</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void scanTelemetry()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#94A3B8] hover:border-[#38BDF8]/60 hover:text-[#F1F5F9] whitespace-nowrap shrink-0"
          >
            <Activity className="h-3.5 w-3.5 text-[#38BDF8]" />
            <span>Scan Hardware</span>
          </button>

          <button
            type="button"
            onClick={() => setHudOpen((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-lg border px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              hudOpen
                ? 'border-[#FB7185] bg-[#FB7185]/15 text-[#FB7185]'
                : 'border-[#E5C07B] bg-[#E5C07B] text-[#080C14] hover:bg-[#ECCE93]'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>{hudOpen ? 'Close Tactical HUD' : 'Open Tactical HUD'}</span>
          </button>
        </div>
      </div>

      {/* Mode Switcher Bar: Eco / Balance / Rise / Diablo */}
      <section
        aria-label="Performance Mode Selector"
        className="grid grid-cols-2 gap-3 lg:grid-cols-4"
      >
        {MODE_CONFIGS.map((mode) => {
          const active = gameSpace.performanceMode === mode.id;
          return (
            <button
              key={mode.id}
              type="button"
              aria-pressed={active}
              onClick={() => void handleModeChange(mode.id)}
              className={`flex flex-col justify-between rounded-xl border p-3.5 text-left transition-colors ${
                active
                  ? mode.accentClass
                  : 'border-[#24324A] bg-[#101724] text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-display text-sm font-semibold">{mode.label}</span>
                <span className="text-[11px] font-mono-tabular opacity-85">
                  {mode.clockLabel}
                </span>
              </div>
              <p className="mt-1 text-xs opacity-80">{mode.sublabel}</p>
            </button>
          );
        })}
      </section>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#24324A] pb-2">
        <div className="flex flex-wrap items-center gap-1">
          {(
            [
              {id: 'library', label: 'Library & Sensitivity'},
              {id: 'cooling', label: 'Cooling, GPU & Refresh'},
              {id: 'triggers', label: 'Triggers, 4D & Macros'},
              {id: 'plugins', label: 'Plugins, Crosshair & Aim Lab'},
            ] as Array<{id: GameSpaceTab; label: string}>
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`rounded-lg px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                activeTab === tab.id
                  ? 'bg-[#161F30] text-[#E5C07B]'
                  : 'text-[#94A3B8] hover:text-[#F1F5F9]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3 text-xs font-mono-tabular text-[#94A3B8]">
          <span>Fan: {gameSpace.fanEnabled ? `${gameSpace.fanRpm.toLocaleString()} RPM` : 'Off'}</span>
          <span aria-hidden="true">·</span>
          <span>Bypass: {gameSpace.chargingSeparation ? 'On' : 'Off'}</span>
          <span aria-hidden="true">·</span>
          <span>Wake Lock: {wakeLockActive ? 'On' : 'Off'}</span>
        </div>
      </div>

      {/* TAB 1: Game Library & Per-Game Sensitivity + AI Tuner */}
      {activeTab === 'library' && (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* Left: Game Library */}
          <section className="flex flex-col gap-3 lg:col-span-7">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                Game Profiles ({gameSpace.games.length})
              </h2>
              <button
                type="button"
                onClick={() => setAddingGame((v) => !v)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add Game</span>
              </button>
            </div>

            {addingGame && (
              <form
                onSubmit={handleAddCustomGame}
                className="grid grid-cols-1 gap-2 rounded-xl border border-[#24324A] bg-[#101724] p-4 sm:grid-cols-12"
              >
                <input
                  type="text"
                  required
                  value={newGameName}
                  onChange={(ev) => setNewGameName(ev.target.value)}
                  placeholder="Game title (e.g. Valorant Mobile)"
                  className="sm:col-span-5 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                />
                <input
                  type="text"
                  value={newGameGenre}
                  onChange={(ev) => setNewGameGenre(ev.target.value)}
                  placeholder="Genre"
                  className="sm:col-span-4 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                />
                <button
                  type="submit"
                  className="sm:col-span-3 rounded-lg bg-[#E5C07B] px-3 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
                >
                  Save Profile
                </button>
              </form>
            )}

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {gameSpace.games.map((game) => {
                const isSelected = game.id === activeGame?.id;
                return (
                  <div
                    key={game.id}
                    className={`flex flex-col justify-between gap-3 rounded-xl border p-4 transition-colors ${
                      isSelected
                        ? 'border-[#E5C07B] bg-[#161F30]'
                        : 'border-[#24324A] bg-[#101724] hover:bg-[#161F30]'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h3 className="font-display text-base font-semibold text-[#F1F5F9]">
                            {game.name}
                          </h3>
                          <p className="mt-0.5 text-xs text-[#94A3B8]">{game.genre}</p>
                        </div>
                        {gameSpace.games.length > 1 && (
                          <button
                            type="button"
                            onClick={() =>
                              void onUpdateGameSpace({
                                games: gameSpace.games.filter((g) => g.id !== game.id),
                                activeGameId:
                                  gameSpace.activeGameId === game.id
                                    ? gameSpace.games.find((g) => g.id !== game.id)?.id ?? ''
                                    : gameSpace.activeGameId,
                              })
                            }
                            aria-label={`Remove ${game.name}`}
                            className="rounded p-1 text-[#64748B] hover:text-[#FB7185]"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>

                      <p className="mt-2.5 text-xs font-mono-tabular text-[#94A3B8]">
                        Mode: <span className="text-[#E5C07B]">{game.preferredMode.toUpperCase()}</span>
                        {' · '}
                        Cap: <span className="text-[#34D399]">{game.targetFps} FPS</span>
                        {' · '}
                        Sens: {game.sensitivityGeneral}
                      </p>
                    </div>

                    <div className="flex items-center justify-between gap-2 border-t border-[#24324A] pt-3">
                      <button
                        type="button"
                        onClick={() => void handleSelectGame(game)}
                        className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
                          isSelected
                            ? 'bg-[#E5C07B] text-[#080C14]'
                            : 'border border-[#24324A] bg-[#080C14] text-[#F1F5F9] hover:border-[#E5C07B]'
                        }`}
                      >
                        <Play className="h-3 w-3" />
                        <span>{isSelected ? 'Loaded Profile' : 'Activate'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          void handleSelectGame(game);
                          setActiveTab('plugins');
                        }}
                        className="text-xs font-medium text-[#38BDF8] hover:underline"
                      >
                        Practice in Aim Lab
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Right: Per-Game Sensitivity & AI Auto-Tuner */}
          <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5 lg:col-span-5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#24324A] pb-3">
              <div>
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  {activeGame?.name ?? 'Game'} Calibration
                </h2>
                <p className="text-xs text-[#94A3B8]">
                  0–200 sensitivity tuning &amp; hardware-aware AI auto-optimize.
                </p>
              </div>
              <button
                type="button"
                disabled={isAiTuning}
                onClick={() => void handleAiOptimizeGame()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3.5 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-50 whitespace-nowrap"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>{isAiTuning ? 'Tuning...' : 'AI Auto-Tune'}</span>
              </button>
            </div>

            <div>
              <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                Target Playstyle for AI Tuner
              </label>
              <select
                value={playstyleInput}
                onChange={(ev) => setPlaystyleInput(ev.target.value)}
                className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              >
                <option value="One-Tap Headshot">One-Tap Headshot</option>
                <option value="Fast Rush / SMG Spray">Fast Rush / SMG Spray</option>
                <option value="Sniper & Long-Range Scope">Sniper &amp; Long-Range Scope</option>
                <option value="Battery Balanced Casual">Battery Balanced Casual</option>
              </select>
            </div>

            {aiRationale && (
              <div className="rounded-lg border border-[#34D399]/40 bg-[#34D399]/10 p-3 text-xs leading-relaxed text-[#F1F5F9]">
                {aiRationale}
              </div>
            )}

            {activeGame && (
              <div className="flex flex-col gap-3">
                {(
                  [
                    {key: 'sensitivityGeneral', label: 'General Sensitivity', val: activeGame.sensitivityGeneral},
                    {key: 'sensitivityRedDot', label: 'Red Dot Sight', val: activeGame.sensitivityRedDot},
                    {key: 'sensitivity2x', label: '2x Scope', val: activeGame.sensitivity2x},
                    {key: 'sensitivity4x', label: '4x Scope', val: activeGame.sensitivity4x},
                  ] as const
                ).map((slider) => (
                  <div key={slider.key}>
                    <div className="mb-1 flex justify-between text-xs font-mono-tabular">
                      <span className="text-[#94A3B8]">{slider.label}</span>
                      <span className="font-semibold text-[#E5C07B]">{slider.val}</span>
                    </div>
                    <input
                      type="range"
                      min={20}
                      max={200}
                      value={slider.val}
                      onChange={(ev) =>
                        void handleUpdateActiveGameSensitivity({
                          [slider.key]: Number(ev.target.value),
                        })
                      }
                      className="w-full accent-[#E5C07B]"
                    />
                  </div>
                ))}
              </div>
            )}

            {telemetry && (
              <div className="mt-auto border-t border-[#24324A] pt-3 text-xs font-mono-tabular text-[#94A3B8]">
                <p className="text-[#F1F5F9]">{telemetry.deviceModelHint}</p>
                <p className="mt-0.5">
                  {telemetry.ramGb ?? 8}GB RAM · {telemetry.cpuCores ?? 8} Cores ·{' '}
                  {telemetry.screenWidth}×{telemetry.screenHeight} @ {telemetry.estimatedRefreshHz}Hz
                </p>
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB 2: Cooling Fan, Bypass Charging, GPU & Refresh Rate */}
      {activeTab === 'cooling' && (
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Fan
                  className={`h-5 w-5 text-[#38BDF8] ${gameSpace.fanEnabled ? 'animate-spin' : ''}`}
                />
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  Turbo Cooling Fan
                </h2>
              </div>
              <button
                type="button"
                aria-pressed={gameSpace.fanEnabled}
                onClick={() => void onUpdateGameSpace({fanEnabled: !gameSpace.fanEnabled})}
                className={`rounded-lg border px-3 py-1 text-xs font-semibold ${
                  gameSpace.fanEnabled
                    ? 'border-[#38BDF8] bg-[#38BDF8]/15 text-[#38BDF8]'
                    : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                }`}
              >
                {gameSpace.fanEnabled ? 'Fan On' : 'Fan Off'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              {(['smart', 'max'] as const).map((fm) => (
                <button
                  key={fm}
                  type="button"
                  onClick={() =>
                    void onUpdateGameSpace({
                      fanEnabled: true,
                      fanMode: fm,
                      fanRpm: fm === 'max' ? 23500 : 19500,
                    })
                  }
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium ${
                    gameSpace.fanMode === fm
                      ? 'border-[#E5C07B] bg-[#161F30] text-[#E5C07B]'
                      : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                  }`}
                >
                  {fm === 'max' ? 'Max Cooling (23.5k RPM)' : 'Smart Auto Curve'}
                </button>
              ))}
            </div>

            <div>
              <div className="mb-1 flex justify-between text-xs font-mono-tabular">
                <span className="text-[#94A3B8]">Fan Speed RPM</span>
                <span className="text-[#38BDF8]">{gameSpace.fanRpm.toLocaleString()} RPM</span>
              </div>
              <input
                type="range"
                min={12000}
                max={24000}
                step={500}
                value={gameSpace.fanRpm}
                onChange={(ev) => void onUpdateGameSpace({fanRpm: Number(ev.target.value)})}
                className="w-full accent-[#38BDF8]"
              />
            </div>

            <div className="flex items-center justify-between gap-3 border-t border-[#24324A] pt-3">
              <div>
                <p className="text-xs font-medium text-[#F1F5F9]">Acoustic Turbine Preview</p>
                <p className="text-[11px] text-[#94A3B8]">
                  Synthesize subtle fan hum proportional to RPM
                </p>
              </div>
              <button
                type="button"
                aria-pressed={fanSoundOn}
                onClick={() => setFanSoundOn((v) => !v)}
                className={`rounded-lg border px-3 py-1.5 text-xs font-medium ${
                  fanSoundOn
                    ? 'border-[#34D399] bg-[#34D399]/15 text-[#34D399]'
                    : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                }`}
              >
                {fanSoundOn ? 'Stop Audio' : 'Test Acoustic'}
              </button>
            </div>
          </section>

          <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5">
            <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
              <BatteryCharging className="h-5 w-5 text-[#34D399]" />
              <span>Charging Separation, Display Hz &amp; Touch</span>
            </h2>

            <label className="flex cursor-pointer items-center justify-between gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2.5">
              <div>
                <p className="text-xs font-medium text-[#F1F5F9]">Charging Separation (Bypass)</p>
                <p className="text-[11px] text-[#94A3B8]">
                  Power SoC directly without heating battery while plugged in
                </p>
              </div>
              <input
                type="checkbox"
                checked={gameSpace.chargingSeparation}
                onChange={(ev) =>
                  void onUpdateGameSpace({chargingSeparation: ev.target.checked})
                }
                className="h-4 w-4 accent-[#34D399]"
              />
            </label>

            <div>
              <p className="mb-1.5 text-xs font-medium text-[#94A3B8]">Display Refresh Cap</p>
              <div className="grid grid-cols-4 gap-2">
                {([60, 90, 120, 144] as const).map((hz) => (
                  <button
                    key={hz}
                    type="button"
                    onClick={() => void onUpdateGameSpace({targetFps: hz})}
                    className={`rounded-lg border py-2 text-xs font-mono-tabular font-semibold ${
                      gameSpace.targetFps === hz
                        ? 'border-[#E5C07B] bg-[#161F30] text-[#E5C07B]'
                        : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                    }`}
                  >
                    {hz} Hz
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="mb-1.5 text-xs font-medium text-[#94A3B8]">
                Touch Sampling &amp; Sweep Response
              </p>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    {id: 'standard', label: 'Standard 120Hz'},
                    {id: 'fast', label: 'Fast 480Hz'},
                    {id: 'ultra_960hz', label: 'Ultra 960Hz'},
                  ] as Array<{id: TouchResponsePreset; label: string}>
                ).map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => void onUpdateGameSpace({touchResponse: preset.id})}
                    className={`rounded-lg border px-2 py-2 text-xs font-medium ${
                      gameSpace.touchResponse === preset.id
                        ? 'border-[#38BDF8] bg-[#161F30] text-[#38BDF8]'
                        : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between border-t border-[#24324A] pt-3">
              <div className="text-xs font-mono-tabular text-[#94A3B8]">
                Live Viewport FPS: <span className="font-semibold text-[#34D399]">{liveFps}</span> ({frameTimeMs}ms)
              </div>
              <button
                type="button"
                onClick={() => {
                  triggerHaptic(18);
                  onNotify('Cleared unused browser audio/preview caches for clean frame pacing.');
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
              >
                <Zap className="h-3.5 w-3.5" />
                <span>Boost Memory</span>
              </button>
            </div>
          </section>
        </div>
      )}

      {/* TAB 3: Shoulder Triggers, 4D Vibration, Gyro & Macros */}
      {activeTab === 'triggers' && (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* Shoulder Triggers & 4D Vibration + Gyro */}
          <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5 lg:col-span-6">
            <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
              <Sliders className="h-4 w-4 text-[#E5C07B]" />
              <span>Dual Shoulder Triggers (Press Q / E to Test)</span>
            </h2>

            {(
              [
                {key: 'leftTrigger', label: 'Left Trigger (L1 · Key Q)', pressed: pressedKeys.left},
                {key: 'rightTrigger', label: 'Right Trigger (R1 · Key E)', pressed: pressedKeys.right},
              ] as const
            ).map((side) => {
              const cfg = gameSpace[side.key];
              return (
                <div
                  key={side.key}
                  className={`flex flex-col gap-2.5 rounded-lg border p-3.5 transition-colors ${
                    side.pressed
                      ? 'border-[#34D399] bg-[#34D399]/10'
                      : 'border-[#24324A] bg-[#080C14]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-[#F1F5F9]">{side.label}</span>
                    <div className="flex items-center gap-2">
                      {side.pressed && (
                        <span className="text-[11px] font-mono-tabular font-semibold text-[#34D399]">
                          ACTIVE
                        </span>
                      )}
                      <input
                        type="checkbox"
                        checked={cfg.enabled}
                        onChange={(ev) =>
                          void onUpdateGameSpace({
                            [side.key]: {...cfg, enabled: ev.target.checked},
                          })
                        }
                        className="h-4 w-4 accent-[#E5C07B]"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={cfg.action}
                      onChange={(ev) =>
                        void onUpdateGameSpace({
                          [side.key]: {...cfg, action: ev.target.value},
                        })
                      }
                      className="rounded-md border border-[#24324A] bg-[#101724] px-2.5 py-1.5 text-xs text-[#F1F5F9]"
                    >
                      {TRIGGER_ACTIONS.map((act) => (
                        <option key={act} value={act}>
                          {act}
                        </option>
                      ))}
                    </select>
                    <label className="flex items-center justify-between gap-2 rounded-md border border-[#24324A] bg-[#101724] px-2.5 py-1.5 text-xs text-[#94A3B8]">
                      <span>Rapid Fire</span>
                      <input
                        type="checkbox"
                        checked={cfg.rapidFire}
                        onChange={(ev) =>
                          void onUpdateGameSpace({
                            [side.key]: {...cfg, rapidFire: ev.target.checked},
                          })
                        }
                        className="h-3.5 w-3.5 accent-[#FB7185]"
                      />
                    </label>
                  </div>
                  <div>
                    <div className="mb-1 flex justify-between text-[11px] font-mono-tabular text-[#94A3B8]">
                      <span>Trigger Sensitivity</span>
                      <span className="text-[#E5C07B]">{cfg.sensitivity}%</span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={100}
                      value={cfg.sensitivity}
                      onChange={(ev) =>
                        void onUpdateGameSpace({
                          [side.key]: {...cfg, sensitivity: Number(ev.target.value)},
                        })
                      }
                      className="w-full accent-[#E5C07B]"
                    />
                  </div>
                </div>
              );
            })}

            <div className="grid grid-cols-1 gap-3 border-t border-[#24324A] pt-3 sm:grid-cols-2">
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-[#F1F5F9]">
                    <Vibrate className="h-3.5 w-3.5 text-[#FB7185]" />
                    <span>4D Vibration</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => triggerHaptic([35, 30, 50])}
                    className="text-[11px] font-medium text-[#E5C07B] hover:underline"
                  >
                    Test Haptic
                  </button>
                </div>
                <select
                  value={gameSpace.vibration4d}
                  onChange={(ev) =>
                    void onUpdateGameSpace({vibration4d: ev.target.value as VibrationIntensity})
                  }
                  className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9]"
                >
                  <option value="off">Off</option>
                  <option value="light">Light</option>
                  <option value="medium">Medium</option>
                  <option value="strong">Strong</option>
                </select>
              </div>

              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-[#F1F5F9]">
                    <Gauge className="h-3.5 w-3.5 text-[#38BDF8]" />
                    <span>Gyroscope Aim</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={gameSpace.gyroscopeEnabled}
                    onChange={(ev) =>
                      void onUpdateGameSpace({gyroscopeEnabled: ev.target.checked})
                    }
                    className="h-4 w-4 accent-[#38BDF8]"
                  />
                </div>
                <p className="text-[11px] font-mono-tabular text-[#94A3B8]">
                  Sens {gameSpace.gyroSensitivity}% · Pitch {gyroAngles.beta}° / Roll{' '}
                  {gyroAngles.gamma}°
                </p>
              </div>
            </div>
          </section>

          {/* Tactical Macros */}
          <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5 lg:col-span-6">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
                <Flame className="h-4 w-4 text-[#FB7185]" />
                <span>Tactical Macro Sequences ({gameSpace.macros.length})</span>
              </h2>
              {runningMacroStatus && (
                <span className="text-xs font-mono-tabular text-[#34D399]">
                  {runningMacroStatus}
                </span>
              )}
            </div>

            <div className="flex flex-col gap-2.5">
              {gameSpace.macros.map((macro) => (
                <div
                  key={macro.id}
                  className="flex flex-col gap-2 rounded-lg border border-[#24324A] bg-[#080C14] p-3.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-[#F1F5F9]">{macro.name}</p>
                      <p className="text-[11px] font-mono-tabular text-[#94A3B8]">
                        Hotkey: <span className="text-[#E5C07B]">{macro.hotkey}</span> ·{' '}
                        {macro.steps.map((s) => `${s.action} (${s.delayMs}ms)`).join(' → ')}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => void handleRunMacro(macro)}
                        className="inline-flex items-center gap-1 rounded-md border border-[#E5C07B]/50 bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
                      >
                        <Play className="h-3 w-3" />
                        <span>Test</span>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          void onUpdateGameSpace({
                            macros: gameSpace.macros.filter((m) => m.id !== macro.id),
                          })
                        }
                        aria-label={`Delete macro ${macro.name}`}
                        className="rounded p-1.5 text-[#64748B] hover:text-[#FB7185]"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <form
              onSubmit={handleAddMacro}
              className="mt-auto flex flex-col gap-2.5 border-t border-[#24324A] pt-4"
            >
              <p className="text-xs font-semibold text-[#F1F5F9]">Create Custom Macro</p>
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  required
                  value={newMacroName}
                  onChange={(ev) => setNewMacroName(ev.target.value)}
                  placeholder="Macro name"
                  className="col-span-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9]"
                />
                <input
                  type="text"
                  value={newMacroHotkey}
                  onChange={(ev) => setNewMacroHotkey(ev.target.value)}
                  placeholder="Key (F3)"
                  className="rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-mono-tabular text-[#E5C07B]"
                />
              </div>
              <input
                type="text"
                value={newMacroSteps}
                onChange={(ev) => setNewMacroSteps(ev.target.value)}
                placeholder="Steps (Action:ms, e.g. ADS:0, Fire:40, Crouch:90)"
                className="rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-mono-tabular text-[#F1F5F9]"
              />
              <button
                type="submit"
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add Macro</span>
              </button>
            </form>
          </section>
        </div>
      )}

      {/* TAB 4: Tactical Plugins (Crosshair, Hunt Filters, DND, Recorder) & Aim Lab */}
      {activeTab === 'plugins' && (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* Left: Interactive Target Practice & Hunt Mode Range */}
          <section className="flex flex-col gap-3 rounded-xl border border-[#24324A] bg-[#101724] p-5 lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  Aim Lab &amp; Hunt Mode Preview
                </h2>
                <p className="text-xs font-mono-tabular text-[#94A3B8]">
                  Accuracy <span className="text-[#34D399]">{accuracyPct}%</span> · Headshots{' '}
                  <span className="text-[#E5C07B]">{aimStats.headshots}</span>/{aimStats.hits} ·{' '}
                  Reaction {aimStats.lastReactionMs}ms
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  setAimStats({shots: 0, hits: 0, headshots: 0, lastReactionMs: 0})
                }
                className="inline-flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs text-[#94A3B8] hover:text-[#F1F5F9]"
              >
                <RotateCcw className="h-3 w-3" />
                <span>Reset Score</span>
              </button>
            </div>

            <div
              onClick={handleArenaClick}
              onMouseMove={(ev) => {
                const rect = ev.currentTarget.getBoundingClientRect();
                setArenaCursor({
                  x: ev.clientX - rect.left,
                  y: ev.clientY - rect.top,
                  inside: true,
                });
              }}
              onMouseLeave={() => setArenaCursor((p) => ({...p, inside: false}))}
              style={{filter: activeHuntCss}}
              className="relative h-[300px] w-full cursor-crosshair select-none overflow-hidden rounded-xl border border-[#24324A] bg-[#080C14]"
            >
              {/* Subtle Range Grid */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 opacity-20"
                style={{
                  backgroundImage:
                    'linear-gradient(to right, #24324A 1px, transparent 1px), linear-gradient(to bottom, #24324A 1px, transparent 1px)',
                  backgroundSize: '40px 40px',
                }}
              />

              {/* Moving Tactical Target */}
              <div
                aria-label="Practice target"
                style={{
                  left: `${target.xPct}%`,
                  top: `${target.yPct}%`,
                  width: `${target.radiusPx * 2}px`,
                  height: `${target.radiusPx * 2}px`,
                  transform: 'translate(-50%, -50%)',
                }}
                className="pointer-events-none absolute flex items-center justify-center rounded-full border-2 border-[#FB7185] bg-[#FB7185]/20"
              >
                <div className="h-3 w-3 rounded-full bg-[#E5C07B]" />
              </div>

              {/* Center Crosshair Overlay */}
              {gameSpace.crosshairEnabled && gameSpace.crosshairStyle !== 'off' && (
                <div
                  style={{
                    left: arenaCursor.inside ? `${arenaCursor.x}px` : '50%',
                    top: arenaCursor.inside ? `${arenaCursor.y}px` : '50%',
                    opacity: gameSpace.crosshairOpacity / 100,
                    transform: 'translate(-50%, -50%)',
                  }}
                  className="pointer-events-none absolute"
                >
                  {renderCrosshairSvg(
                    gameSpace.crosshairStyle,
                    gameSpace.crosshairColor,
                    gameSpace.crosshairSize,
                  )}
                </div>
              )}

              {/* Scout Magnifier Lens Badge */}
              {gameSpace.scoutMagnifier && arenaCursor.inside && (
                <div
                  style={{
                    left: `${Math.min(Math.max(arenaCursor.x, 44), 90)}%`,
                    top: '14px',
                  }}
                  className="pointer-events-none absolute rounded border border-[#38BDF8]/60 bg-[#101724]/90 px-2 py-0.5 text-[10px] font-mono-tabular text-[#38BDF8]"
                >
                  Scout Zoom {gameSpace.scoutZoom}x Active
                </div>
              )}
            </div>

            {/* Match Stopwatch + Screen Recording Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#24324A] pt-3">
              <div className="flex items-center gap-2">
                <Timer className="h-4 w-4 text-[#E5C07B]" />
                <span className="font-mono-tabular text-sm font-semibold text-[#F1F5F9]">
                  {formatStopwatch(stopwatchSec)}
                </span>
                <button
                  type="button"
                  onClick={() => setStopwatchRunning((v) => !v)}
                  className="rounded-md border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs text-[#E5C07B]"
                >
                  {stopwatchRunning ? 'Pause' : 'Start Timer'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStopwatchRunning(false);
                    setStopwatchSec(0);
                  }}
                  className="rounded-md border border-[#24324A] bg-[#080C14] px-2 py-1 text-xs text-[#94A3B8]"
                >
                  Reset
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleToggleScreenRecord()}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium ${
                    isRecordingClip
                      ? 'border-[#FB7185] bg-[#FB7185]/15 text-[#FB7185]'
                      : 'border-[#24324A] bg-[#080C14] text-[#F1F5F9] hover:border-[#E5C07B]'
                  }`}
                >
                  {isRecordingClip ? (
                    <Square className="h-3.5 w-3.5" />
                  ) : (
                    <Video className="h-3.5 w-3.5 text-[#FB7185]" />
                  )}
                  <span>{isRecordingClip ? 'Stop Clip' : 'Record Gameplay'}</span>
                </button>

                {recordedClipUrl && (
                  <a
                    href={recordedClipUrl}
                    download={`PRIME-GameSpace-${Date.now()}.webm`}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#34D399]/60 bg-[#34D399]/10 px-2.5 py-1.5 text-xs font-medium text-[#34D399]"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Save Clip</span>
                  </a>
                )}
              </div>
            </div>
          </section>

          {/* Right: Crosshair Designer, Hunt Filters & DND / Blockers */}
          <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5 lg:col-span-5">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <h3 className="flex items-center gap-1.5 font-display text-sm font-semibold text-[#F1F5F9]">
                  <Crosshair className="h-4 w-4 text-[#E5C07B]" />
                  <span>Custom Crosshair Assist</span>
                </h3>
                <input
                  type="checkbox"
                  checked={gameSpace.crosshairEnabled}
                  onChange={(ev) =>
                    void onUpdateGameSpace({crosshairEnabled: ev.target.checked})
                  }
                  className="h-4 w-4 accent-[#E5C07B]"
                />
              </div>

              <div className="grid grid-cols-5 gap-1.5">
                {(['off', 'dot', 'cross', 'circle_dot', 'chevron'] as CrosshairStyle[]).map(
                  (st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() =>
                        void onUpdateGameSpace({
                          crosshairStyle: st,
                          crosshairEnabled: st !== 'off',
                        })
                      }
                      className={`rounded-md border py-1.5 text-[11px] font-medium ${
                        gameSpace.crosshairStyle === st
                          ? 'border-[#E5C07B] bg-[#161F30] text-[#E5C07B]'
                          : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                      }`}
                    >
                      {st === 'circle_dot' ? 'Ring' : st.charAt(0).toUpperCase() + st.slice(1)}
                    </button>
                  ),
                )}
              </div>

              <div className="mt-2.5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {CROSSHAIR_COLORS.map((hex) => (
                    <button
                      key={hex}
                      type="button"
                      onClick={() => void onUpdateGameSpace({crosshairColor: hex})}
                      aria-label={`Crosshair color ${hex}`}
                      style={{backgroundColor: hex}}
                      className={`h-5 w-5 rounded-full border-2 ${
                        gameSpace.crosshairColor === hex
                          ? 'border-white scale-110'
                          : 'border-transparent'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs font-mono-tabular text-[#94A3B8]">
                  Size {gameSpace.crosshairSize}px
                </span>
              </div>

              <input
                type="range"
                min={12}
                max={48}
                value={gameSpace.crosshairSize}
                onChange={(ev) =>
                  void onUpdateGameSpace({crosshairSize: Number(ev.target.value)})
                }
                className="mt-2 w-full accent-[#E5C07B]"
              />
            </div>

            <div className="border-t border-[#24324A] pt-3">
              <h3 className="mb-2 flex items-center gap-1.5 font-display text-sm font-semibold text-[#F1F5F9]">
                <Eye className="h-4 w-4 text-[#38BDF8]" />
                <span>Hunt Mode Visual Filters &amp; Scout Zoom</span>
              </h3>
              <div className="grid grid-cols-2 gap-1.5">
                {HUNT_FILTERS.map((hf) => (
                  <button
                    key={hf.id}
                    type="button"
                    onClick={() => void onUpdateGameSpace({huntFilter: hf.id})}
                    className={`rounded-md border px-2.5 py-1.5 text-xs font-medium ${
                      gameSpace.huntFilter === hf.id
                        ? 'border-[#38BDF8] bg-[#161F30] text-[#38BDF8]'
                        : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                    }`}
                  >
                    {hf.label}
                  </button>
                ))}
              </div>
              <div className="mt-2.5 flex items-center justify-between gap-2 text-xs">
                <label className="inline-flex cursor-pointer items-center gap-2 text-[#F1F5F9]">
                  <input
                    type="checkbox"
                    checked={gameSpace.scoutMagnifier}
                    onChange={(ev) =>
                      void onUpdateGameSpace({scoutMagnifier: ev.target.checked})
                    }
                    className="h-3.5 w-3.5 accent-[#38BDF8]"
                  />
                  <span>Scout Magnifier</span>
                </label>
                <div className="flex items-center gap-1">
                  {([2, 3, 4] as const).map((z) => (
                    <button
                      key={z}
                      type="button"
                      onClick={() =>
                        void onUpdateGameSpace({scoutMagnifier: true, scoutZoom: z})
                      }
                      className={`rounded border px-2 py-0.5 text-[11px] font-mono-tabular ${
                        gameSpace.scoutMagnifier && gameSpace.scoutZoom === z
                          ? 'border-[#38BDF8] text-[#38BDF8]'
                          : 'border-[#24324A] text-[#94A3B8]'
                      }`}
                    >
                      {z}x
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2 border-t border-[#24324A] pt-3 text-xs">
              <h3 className="font-display text-sm font-semibold text-[#F1F5F9]">
                DND, Guards &amp; Display Lock
              </h3>
              {(
                [
                  {
                    key: 'dndBlockCalls',
                    icon: PhoneOff,
                    label: 'Block Incoming Calls',
                  },
                  {
                    key: 'dndSilenceNotifications',
                    icon: BellOff,
                    label: 'Silence Pop-up Notifications',
                  },
                  {
                    key: 'edgeTouchGuard',
                    icon: Shield,
                    label: 'Accidental Edge Swipe Guard',
                  },
                  {
                    key: 'keepScreenAwake',
                    icon: Zap,
                    label: 'Keep Display Awake (Wake Lock)',
                  },
                ] as const
              ).map((item) => {
                const Icon = item.icon;
                const checked = gameSpace[item.key];
                return (
                  <label
                    key={item.key}
                    className="flex cursor-pointer items-center justify-between rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2"
                  >
                    <span className="flex items-center gap-2 text-[#F1F5F9]">
                      <Icon className="h-3.5 w-3.5 text-[#E5C07B]" />
                      <span>{item.label}</span>
                    </span>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(ev) =>
                        void onUpdateGameSpace({[item.key]: ev.target.checked})
                      }
                      className="h-3.5 w-3.5 accent-[#E5C07B]"
                    />
                  </label>
                );
              })}
            </div>
          </section>
        </div>
      )}

      {/* Floating RedMagic-style Tactical HUD Side Drawer */}
      {hudOpen && (
        <aside
          aria-label="Floating Game Space Tactical HUD"
          className="fixed bottom-4 right-4 z-50 w-80 rounded-xl border border-[#FB7185]/60 bg-[#080C14]/95 p-4 shadow-2xl backdrop-blur"
        >
          <div className="flex items-center justify-between border-b border-[#24324A] pb-2.5">
            <div className="flex items-center gap-2">
              <Gamepad2 className="h-4 w-4 text-[#FB7185]" />
              <span className="font-display text-xs font-semibold text-[#F1F5F9]">
                TACTICAL HUD · {liveFps} FPS
              </span>
            </div>
            <button
              type="button"
              onClick={() => setHudOpen(false)}
              className="text-xs text-[#94A3B8] hover:text-[#F1F5F9]"
            >
              Hide
            </button>
          </div>

          <div className="mt-3 grid grid-cols-4 gap-1.5">
            {MODE_CONFIGS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => void handleModeChange(m.id)}
                className={`rounded-md border py-1.5 text-[11px] font-semibold ${
                  gameSpace.performanceMode === m.id
                    ? 'border-[#FB7185] bg-[#FB7185]/20 text-[#FB7185]'
                    : 'border-[#24324A] bg-[#101724] text-[#94A3B8]'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => void onUpdateGameSpace({fanEnabled: !gameSpace.fanEnabled})}
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg border py-2 ${
                gameSpace.fanEnabled
                  ? 'border-[#38BDF8] bg-[#38BDF8]/15 text-[#38BDF8]'
                  : 'border-[#24324A] bg-[#101724] text-[#94A3B8]'
              }`}
            >
              <Fan className="h-3.5 w-3.5" />
              <span>Fan {gameSpace.fanEnabled ? 'On' : 'Off'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                void onUpdateGameSpace({crosshairEnabled: !gameSpace.crosshairEnabled})
              }
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg border py-2 ${
                gameSpace.crosshairEnabled
                  ? 'border-[#E5C07B] bg-[#E5C07B]/15 text-[#E5C07B]'
                  : 'border-[#24324A] bg-[#101724] text-[#94A3B8]'
              }`}
            >
              <Crosshair className="h-3.5 w-3.5" />
              <span>Crosshair</span>
            </button>

            <button
              type="button"
              onClick={() =>
                void onUpdateGameSpace({
                  chargingSeparation: !gameSpace.chargingSeparation,
                })
              }
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg border py-2 ${
                gameSpace.chargingSeparation
                  ? 'border-[#34D399] bg-[#34D399]/15 text-[#34D399]'
                  : 'border-[#24324A] bg-[#101724] text-[#94A3B8]'
              }`}
            >
              <BatteryCharging className="h-3.5 w-3.5" />
              <span>Bypass Chg</span>
            </button>

            <button
              type="button"
              onClick={() =>
                void onUpdateGameSpace({dndBlockCalls: !gameSpace.dndBlockCalls})
              }
              className={`inline-flex items-center justify-center gap-1.5 rounded-lg border py-2 ${
                gameSpace.dndBlockCalls
                  ? 'border-[#E5C07B] bg-[#E5C07B]/15 text-[#E5C07B]'
                  : 'border-[#24324A] bg-[#101724] text-[#94A3B8]'
              }`}
            >
              <BellOff className="h-3.5 w-3.5" />
              <span>DND Block</span>
            </button>
          </div>

          <div className="mt-3 flex items-center justify-between gap-2 border-t border-[#24324A] pt-2.5 text-[11px] font-mono-tabular text-[#94A3B8]">
            <span>{thermalEstimateC}°C · {gameSpace.targetFps}Hz</span>
            <button
              type="button"
              onClick={() =>
                onSpeakStatus?.(
                  `Game Space active in ${gameSpace.performanceMode} mode. Live frame rate ${liveFps} FPS.`,
                )
              }
              className="inline-flex items-center gap-1 text-[#E5C07B] hover:underline"
            >
              <Mic className="h-3 w-3" />
              <span>Voice Readout</span>
            </button>
          </div>
        </aside>
      )}
    </div>
  );
}
