import {useState} from 'react';
import {
  Crosshair,
  ListChecks,
  Mic,
  PictureInPicture2,
  Radio,
  Scan,
  Square,
  X,
} from 'lucide-react';
import type {VoiceState} from '../types/prime.ts';

interface BackgroundBossHudProps {
  visible: boolean;
  voiceState: VoiceState;
  wakeWordEnabled: boolean;
  wakeResponsePhrase: string;
  lastBossTriggerAtMs: number | null;
  onMicToggle: () => void;
  onAnalyzeMobile: () => void;
  onAnalyzeScreen: () => void;
  onQuickHowTo: () => void;
  onDisableHud: () => void;
  onNotify: (msg: string) => void;
}

export function BackgroundBossHud({
  visible,
  voiceState,
  wakeWordEnabled,
  wakeResponsePhrase,
  lastBossTriggerAtMs,
  onMicToggle,
  onAnalyzeMobile,
  onAnalyzeScreen,
  onQuickHowTo,
  onDisableHud,
  onNotify,
}: BackgroundBossHudProps) {
  const [pipOpen, setPipOpen] = useState(false);

  if (!visible) return null;

  const isRecentlyTriggered =
    lastBossTriggerAtMs !== null && Date.now() - lastBossTriggerAtMs < 6000;

  const handleOpenFloatingPip = async () => {
    const win = window as unknown as {
      documentPictureInPicture?: {
        requestWindow: (opts: {width: number; height: number}) => Promise<Window>;
      };
    };
    if (!win.documentPictureInPicture?.requestWindow) {
      onNotify('Floating Mini-HUD stays pinned in-app across all tabs on this browser.');
      return;
    }
    try {
      const pipWin = await win.documentPictureInPicture.requestWindow({
        width: 340,
        height: 220,
      });
      pipWin.document.body.style.cssText =
        'margin:0;padding:16px;background:#080C14;color:#F1F5F9;font-family:system-ui,-apple-system,sans-serif;display:flex;flex-direction:column;gap:10px;';

      const title = pipWin.document.createElement('div');
      title.textContent = `PRIME · ${wakeWordEnabled ? 'Listening for "Prime"' : 'Standby'}`;
      title.style.cssText = 'font-size:13px;font-weight:700;color:#E5C07B;';

      const sub = pipWin.document.createElement('div');
      sub.textContent = `Say "Prime" -> "${wakeResponsePhrase}"`;
      sub.style.cssText = 'font-size:12px;color:#94A3B8;';

      const row = pipWin.document.createElement('div');
      row.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;margin-top:4px;';

      const mkBtn = (label: string, accent: string, handler: () => void) => {
        const b = pipWin.document.createElement('button');
        b.textContent = label;
        b.style.cssText = `cursor:pointer;border:1px solid ${accent};background:#101724;color:#F1F5F9;border-radius:8px;padding:7px 10px;font-size:12px;font-weight:600;`;
        b.onclick = handler;
        return b;
      };

      row.appendChild(mkBtn('Speak / Mic', '#38BDF8', onMicToggle));
      row.appendChild(mkBtn('Free Fire Sensi', '#E5C07B', onAnalyzeMobile));
      row.appendChild(mkBtn('Analyze Screen', '#34D399', onAnalyzeScreen));

      pipWin.document.body.append(title, sub, row);
      setPipOpen(true);
      pipWin.addEventListener('pagehide', () => setPipOpen(false));
    } catch {
      onNotify('Floating Picture-in-Picture permission was dismissed.');
    }
  };

  return (
    <aside
      aria-label="Background Boss Quick HUD"
      className={`fixed bottom-16 right-4 z-40 w-[300px] rounded-xl border bg-[#101724]/95 p-3 shadow-2xl backdrop-blur-md md:bottom-5 ${
        isRecentlyTriggered || voiceState === 'listening'
          ? 'border-[#34D399]'
          : 'border-[#E5C07B]/50'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs font-semibold">
          <Radio
            className={`h-3.5 w-3.5 ${
              wakeWordEnabled ? 'animate-pulse text-[#34D399]' : 'text-[#94A3B8]'
            }`}
          />
          <span className="text-[#E5C07B]">
            {isRecentlyTriggered
              ? wakeResponsePhrase
              : wakeWordEnabled
                ? 'Background Boss Ready'
                : 'Quick Floating HUD'}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => void handleOpenFloatingPip()}
            title="Pop out floating window above other apps"
            aria-label="Pop out floating window"
            className={`rounded p-1 transition-colors hover:bg-[#161F30] ${
              pipOpen ? 'text-[#34D399]' : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <PictureInPicture2 className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDisableHud}
            aria-label="Hide Background Boss HUD"
            className="rounded p-1 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <p className="mt-1 text-[11px] text-[#94A3B8]">
        {wakeWordEnabled
          ? `Say "Prime" anytime -> answers "${wakeResponsePhrase}"`
          : 'Instant access across all screens.'}
      </p>

      <div className="mt-2.5 grid grid-cols-2 gap-1.5">
        <button
          type="button"
          onClick={onMicToggle}
          className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-2 py-1.5 text-[11px] font-semibold transition-colors ${
            voiceState === 'listening'
              ? 'border-[#38BDF8] bg-[#38BDF8]/15 text-[#38BDF8]'
              : 'border-[#24324A] bg-[#080C14] text-[#F1F5F9] hover:border-[#E5C07B]'
          }`}
        >
          {voiceState === 'speaking' ? (
            <Square className="h-3 w-3 text-[#FB7185]" />
          ) : (
            <Mic className="h-3 w-3 text-[#E5C07B]" />
          )}
          <span>{voiceState === 'listening' ? 'Stop Mic' : 'Talk Now'}</span>
        </button>

        <button
          type="button"
          onClick={onAnalyzeMobile}
          className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2 py-1.5 text-[11px] font-semibold text-[#E5C07B] hover:border-[#E5C07B]"
        >
          <Crosshair className="h-3 w-3" />
          <span>FF Sensitivity</span>
        </button>

        <button
          type="button"
          onClick={onAnalyzeScreen}
          className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2 py-1.5 text-[11px] font-medium text-[#34D399] hover:border-[#34D399]"
        >
          <Scan className="h-3 w-3" />
          <span>Analyze Screen</span>
        </button>

        <button
          type="button"
          onClick={onQuickHowTo}
          className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2 py-1.5 text-[11px] font-medium text-[#38BDF8] hover:border-[#38BDF8]"
        >
          <ListChecks className="h-3 w-3" />
          <span>Show Me How</span>
        </button>
      </div>
    </aside>
  );
}
