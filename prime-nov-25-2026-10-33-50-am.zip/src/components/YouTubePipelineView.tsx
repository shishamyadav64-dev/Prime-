import {useEffect, useState} from 'react';
import type {User} from 'firebase/auth';
import {
  AlertTriangle,
  Bot,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  FileText,
  Film,
  Image as ImageIcon,
  Layers,
  LogOut,
  Play,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Subtitles,
  Upload,
  Wand2,
} from 'lucide-react';
import type {
  BatchVideoItem,
  PrimeSettings,
  PrimeVaultSnapshot,
  VideoFormat,
  VideoProject,
  VideoRecheckReport,
  YouTubeAgentConfig,
  YouTubeAgentPostJob,
  YouTubeAgentSettings,
  YouTubeVideoTheme,
} from '../types/prime.ts';
import {buildFreeLocalVideoProject, runFreeLocalRecheck} from '../utils/freeVideoBuilder.ts';
import {renderProjectThumbnail, renderProjectVideo} from '../utils/videoRenderer.ts';
import {
  getCachedYouTubeToken,
  initYouTubeAuth,
  signInWithYouTubeGoogle,
  signOutYouTubeGoogle,
} from '../utils/youtubeAuth.ts';
import {
  fetchMyYouTubeChannel,
  uploadVideoToYouTube,
  type YouTubeChannelInfo,
  type YouTubePrivacyStatus,
  type YouTubePublishResult,
} from '../utils/youtubeApi.ts';
import {YouTubeAgentsPanel} from './YouTubeAgentsPanel.tsx';

interface YouTubePipelineViewProps {
  settings: PrimeSettings;
  batchVideos?: BatchVideoItem[];
  youtubeAgents?: YouTubeAgentConfig[];
  youtubePostQueue?: YouTubeAgentPostJob[];
  youtubeAgentSettings?: YouTubeAgentSettings;
  onSnapshotUpdated?: (snapshot: PrimeVaultSnapshot) => void;
  initialTopic?: string;
  onConsumeInitialTopic?: () => void;
  onNotify: (msg: string) => void;
}

function formatCueTime(sec: number): string {
  const mins = Math.floor(sec / 60);
  const rem = Math.floor(sec % 60);
  return `${String(mins).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

export function YouTubePipelineView({
  settings,
  batchVideos = [],
  youtubeAgents,
  youtubePostQueue,
  youtubeAgentSettings,
  onSnapshotUpdated,
  initialTopic,
  onConsumeInitialTopic,
  onNotify,
}: YouTubePipelineViewProps) {
  const [studioMode, setStudioMode] = useState<'agents' | 'single' | 'batch'>('agents');
  const [topic, setTopic] = useState('');
  const [format, setFormat] = useState<VideoFormat>('16:9');
  const [engineMode, setEngineMode] = useState<'free_local' | 'ai_producer'>('free_local');
  const [videoTheme, setVideoTheme] = useState<YouTubeVideoTheme>('gold');
  const [ambientMusicEnabled, setAmbientMusicEnabled] = useState(true);
  const [autoPostOnComplete, setAutoPostOnComplete] = useState(true);
  const [batchNiche, setBatchNiche] = useState('');
  const [batchCount, setBatchCount] = useState(6);
  const [postsPerDay, setPostsPerDay] = useState(6);
  const [isPlanningBatch, setIsPlanningBatch] = useState(false);
  const [learnNote, setLearnNote] = useState('');
  const [isSavingLearn, setIsSavingLearn] = useState(false);
  const [project, setProject] = useState<VideoProject | null>(null);

  const [isWritingScript, setIsWritingScript] = useState(false);
  const [isRendering, setIsRendering] = useState(false);
  const [renderStage, setRenderStage] = useState('');
  const [renderProgress, setRenderProgress] = useState(0);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoDurationSec, setVideoDurationSec] = useState<number | null>(null);

  const [thumbnailBlob, setThumbnailBlob] = useState<Blob | null>(null);
  const [thumbnailDataUrl, setThumbnailDataUrl] = useState<string | null>(null);
  const [isGeneratingThumb, setIsGeneratingThumb] = useState(false);

  const [isRechecking, setIsRechecking] = useState(false);
  const [isRunningAll, setIsRunningAll] = useState(false);

  // YouTube OAuth & Publishing state
  const [needsAuth, setNeedsAuth] = useState(true);
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [channelInfo, setChannelInfo] = useState<YouTubeChannelInfo | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [privacyStatus, setPrivacyStatus] = useState<YouTubePrivacyStatus>('private');
  const [confirmPublishOpen, setConfirmPublishOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [publishResult, setPublishResult] = useState<YouTubePublishResult | null>(null);

  useEffect(() => {
    const unsubscribe = initYouTubeAuth(
      async (user, token) => {
        setGoogleUser(user);
        setNeedsAuth(false);
        try {
          const ch = await fetchMyYouTubeChannel(token);
          setChannelInfo(ch);
        } catch {
          setChannelInfo(null);
        }
      },
      () => {
        setGoogleUser(null);
        setChannelInfo(null);
        setNeedsAuth(true);
      },
    );
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (initialTopic && initialTopic.trim()) {
      setTopic(initialTopic.trim());
      setStudioMode('single');
      onConsumeInitialTopic?.();
    }
  }, [initialTopic, onConsumeInitialTopic]);

  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  const handleGoogleLogin = async (): Promise<boolean> => {
    setIsSigningIn(true);
    try {
      const {user, accessToken} = await signInWithYouTubeGoogle();
      setGoogleUser(user);
      setNeedsAuth(false);
      const ch = await fetchMyYouTubeChannel(accessToken).catch(() => null);
      setChannelInfo(ch);
      onNotify(
        ch
          ? `Connected YouTube channel "${ch.title}".`
          : `Signed in as ${user.email || user.displayName || 'Google user'}.`,
      );
      return true;
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Google sign-in could not be completed.');
      return false;
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleGoogleSignOut = async () => {
    await signOutYouTubeGoogle();
    setGoogleUser(null);
    setChannelInfo(null);
    setNeedsAuth(true);
    onNotify('Disconnected Google YouTube session.');
  };

  const buildThumbnailAsset = async (
    targetProject: VideoProject,
    themeOverride?: YouTubeVideoTheme,
  ) => {
    setIsGeneratingThumb(true);
    try {
      const thumb = await renderProjectThumbnail(targetProject, themeOverride ?? videoTheme);
      setThumbnailBlob(thumb.thumbnailBlob);
      setThumbnailDataUrl(thumb.thumbnailDataUrl);
      return thumb;
    } finally {
      setIsGeneratingThumb(false);
    }
  };

  const generateScriptPackage = async (inputTopic: string, targetFormat: VideoFormat) => {
    setIsWritingScript(true);
    try {
      let nextProject: VideoProject;
      if (engineMode === 'free_local') {
        nextProject = buildFreeLocalVideoProject({
          topic: inputTopic,
          format: targetFormat,
          theme: videoTheme,
        });
      } else {
        const res = await fetch('/api/prime/video/generate-package', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({topic: inputTopic, format: targetFormat}),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Failed to generate YouTube script package.');
        }
        nextProject = data as VideoProject;
      }
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      setVideoBlob(null);
      setVideoUrl(null);
      setVideoDurationSec(null);
      setPublishResult(null);
      setProject(nextProject);
      await buildThumbnailAsset(nextProject, videoTheme);
      onNotify(
        engineMode === 'free_local'
          ? 'Generated free unlimited script, HD thumbnail, synced captions & SEO package.'
          : 'Auto-generated script, HD thumbnail, synced captions, and SEO description.',
      );
      return nextProject;
    } finally {
      setIsWritingScript(false);
    }
  };

  const renderVideoAsset = async (targetProject: VideoProject) => {
    setIsRendering(true);
    setRenderProgress(5);
    setRenderStage('Initializing studio render...');
    try {
      const rendered = await renderProjectVideo(
        targetProject,
        settings,
        (stage, pct) => {
          setRenderStage(stage);
          setRenderProgress(pct);
        },
        {
          useFreeSynthAudio: engineMode === 'free_local',
          ambientMusicEnabled,
          theme: videoTheme,
        },
      );
      if (videoUrl) URL.revokeObjectURL(videoUrl);
      setVideoBlob(rendered.videoBlob);
      setVideoUrl(rendered.videoUrl);
      setVideoDurationSec(rendered.durationSec);
      const updated: VideoProject = {
        ...targetProject,
        captions: rendered.syncedCaptions,
        srtText: rendered.syncedSrt,
      };
      setProject(updated);
      onNotify('HD video rendered with audio, visual theme, and synced captions.');
      return updated;
    } finally {
      setIsRendering(false);
    }
  };

  const runRecheck = async (targetProject: VideoProject, autoApply = false) => {
    setIsRechecking(true);
    try {
      let report: VideoRecheckReport;
      if (engineMode === 'free_local') {
        report = runFreeLocalRecheck(targetProject);
      } else {
        const res = await fetch('/api/prime/video/recheck', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(targetProject),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Auto-recheck failed.');
        }
        report = data as VideoRecheckReport;
      }
      const updated: VideoProject = {
        ...targetProject,
        title:
          autoApply && report.improvedTitle ? report.improvedTitle : targetProject.title,
        description:
          autoApply && report.improvedDescription
            ? report.improvedDescription
            : targetProject.description,
        recheckReport: report,
      };
      setProject(updated);
      onNotify(
        report.overallReady
          ? 'Auto-recheck passed. Video, thumbnail, and SEO are ready for YouTube.'
          : autoApply
            ? 'Auto-recheck applied title and description improvements automatically.'
            : 'Auto-recheck completed with suggested improvements.',
      );
      return updated;
    } finally {
      setIsRechecking(false);
    }
  };

  const handleRunFullPipeline = async () => {
    const trimmed = topic.trim();
    if (!trimmed) {
      onNotify('Please enter a video topic first.');
      return;
    }
    setIsRunningAll(true);
    try {
      const generated = await generateScriptPackage(trimmed, format);
      const renderedProject = await renderVideoAsset(generated);
      const auditedProject = await runRecheck(renderedProject, true);
      const token = getCachedYouTubeToken();
      if (autoPostOnComplete && token) {
        onNotify('Auto-posting created video, thumbnail, and captions to YouTube...');
        const thumbRes = await renderProjectThumbnail(auditedProject).catch(() => null);
        // Note: trigger upload using freshly rendered video via state or confirmation fallback
        setConfirmPublishOpen(true);
        if (thumbRes) {
          setThumbnailBlob(thumbRes.thumbnailBlob);
          setThumbnailDataUrl(thumbRes.thumbnailDataUrl);
        }
      } else if (token) {
        setConfirmPublishOpen(true);
      } else {
        onNotify(
          'Video & thumbnail created! Click "Sign in with Google" to publish directly to YouTube.',
        );
      }
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Automated pipeline interrupted.');
    } finally {
      setIsRunningAll(false);
    }
  };

  // Smart "Auto What To Do To Post" runner — completes all remaining pre-post steps sequentially
  const handleAutoNextPostStep = async () => {
    setIsRunningAll(true);
    try {
      let currentProject = project;
      let hasThumb = Boolean(thumbnailBlob);
      let hasVideo = Boolean(videoBlob);

      if (!currentProject) {
        if (!topic.trim()) {
          onNotify('Enter a video topic above first, then click Auto Do All Needed to Post.');
          return;
        }
        currentProject = await generateScriptPackage(topic.trim(), format);
        hasThumb = true;
      }

      if (!hasThumb) {
        await buildThumbnailAsset(currentProject);
        hasThumb = true;
      }

      if (!hasVideo) {
        currentProject = await renderVideoAsset(currentProject);
        hasVideo = true;
      }

      if (!currentProject.recheckReport) {
        currentProject = await runRecheck(currentProject, true);
      }

      if (needsAuth || !getCachedYouTubeToken()) {
        const ok = await handleGoogleLogin();
        if (ok) {
          setConfirmPublishOpen(true);
        }
        return;
      }

      setConfirmPublishOpen(true);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Automated post preparation interrupted.');
    } finally {
      setIsRunningAll(false);
    }
  };

  const handleConfirmPublish = async () => {
    if (!project || !videoBlob) return;
    const token = getCachedYouTubeToken();
    if (!token) {
      setConfirmPublishOpen(false);
      setNeedsAuth(true);
      onNotify('Please sign in with Google to publish to YouTube.');
      return;
    }

    setIsUploading(true);
    try {
      const result = await uploadVideoToYouTube({
        accessToken: token,
        videoBlob,
        title: project.title,
        description: project.description,
        tags: project.tags,
        privacyStatus,
        srtText: project.srtText,
        thumbnailBlob,
      });
      setPublishResult(result);
      setConfirmPublishOpen(false);
      const extras = [
        result.thumbnailAttached ? 'thumbnail' : null,
        result.captionsAttached ? 'captions' : null,
      ]
        .filter(Boolean)
        .join(' & ');
      onNotify(
        extras
          ? `Published video with ${extras} to YouTube.`
          : 'Published video to YouTube.',
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'YouTube upload failed.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDownloadSrt = () => {
    if (!project) return;
    const blob = new Blob([project.srtText], {type: 'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'prime-captions'}.srt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadVideo = () => {
    if (!videoUrl || !project) return;
    const a = document.createElement('a');
    a.href = videoUrl;
    a.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'prime-video'}.webm`;
    a.click();
  };

  const handleDownloadThumbnail = () => {
    if (!thumbnailDataUrl || !project) return;
    const a = document.createElement('a');
    a.href = thumbnailDataUrl;
    a.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'prime-thumbnail'}.jpg`;
    a.click();
  };

  const applyRecheckImprovements = () => {
    if (!project?.recheckReport) return;
    setProject({
      ...project,
      title: project.recheckReport.improvedTitle || project.title,
      description: project.recheckReport.improvedDescription || project.description,
    });
    onNotify('Applied auto-recheck title and description refinements.');
  };

  const busy =
    isWritingScript || isRendering || isRechecking || isRunningAll || isUploading || isGeneratingThumb;

  const postChecklist = [
    {label: 'Auto-write script & SEO metadata', done: Boolean(project)},
    {label: 'Auto-generate HD cover thumbnail', done: Boolean(thumbnailBlob)},
    {label: 'Render HD video & burned-in captions', done: Boolean(videoBlob)},
    {label: 'Auto-recheck quality & SEO audit', done: Boolean(project?.recheckReport)},
    {label: 'Connect Google YouTube channel', done: !needsAuth},
    {label: 'Confirm & publish to YouTube', done: Boolean(publishResult)},
  ];

  const remainingBeforeAuth =
    Number(!project) +
    Number(!thumbnailBlob) +
    Number(!videoBlob) +
    Number(!project?.recheckReport);

  const nextActionLabel =
    remainingBeforeAuth > 1
      ? `Auto Complete ${remainingBeforeAuth} Remaining Steps`
      : !project
        ? 'Run Full Auto-Pipeline'
        : !thumbnailBlob
          ? 'Auto-Generate Thumbnail & Audit'
          : !videoBlob
            ? 'Auto-Render Video & Audit'
            : !project.recheckReport
              ? 'Run Auto Recheck'
              : needsAuth
                ? 'Sign in with Google to Post'
                : publishResult
                  ? 'Publish Another / Re-upload'
                  : 'Review & Post to YouTube';

  return (
    <div className="flex h-full flex-col gap-5 overflow-y-auto pr-1">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#24324A] pb-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            YouTube Agents &amp; Free Video Studio
          </h1>
          <p className="mt-1 text-sm text-[#94A3B8]">
            100% Free Unlimited — autonomous YouTube Agents, HD/Shorts video creator, thumbnails,
            captions, SEO audit, and posting manager with zero paid plans.
          </p>
          <div className="mt-3 inline-flex flex-wrap items-center gap-1 rounded-lg border border-[#24324A] bg-[#101724] p-1">
            <button
              type="button"
              onClick={() => setStudioMode('agents')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap font-mono-tabular ${
                studioMode === 'agents' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
              }`}
            >
              <Bot className="h-3.5 w-3.5" />
              <span>YouTube Agents ({youtubePostQueue?.length ?? 0})</span>
            </button>
            <button
              type="button"
              onClick={() => setStudioMode('single')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                studioMode === 'single' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
              }`}
            >
              <Film className="h-3.5 w-3.5" />
              <span>Single Auto-Video</span>
            </button>
            <button
              type="button"
              onClick={() => setStudioMode('batch')}
              className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap font-mono-tabular ${
                studioMode === 'batch' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>Batch Reels ({batchVideos.length})</span>
            </button>
          </div>
        </div>

        {/* Connected YouTube Account Status */}
        <div className="shrink-0">
          {needsAuth ? (
            <button
              type="button"
              disabled={isSigningIn}
              onClick={handleGoogleLogin}
              className="inline-flex h-10 items-center gap-2.5 rounded-lg border border-[#DADCE0] bg-white px-4 text-sm font-medium text-[#1F1F1F] transition-colors hover:bg-[#F8FAFC] disabled:opacity-50"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                className="h-4 w-4 shrink-0"
              >
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                />
                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                />
                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                />
                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                />
              </svg>
              <span>{isSigningIn ? 'Signing in...' : 'Sign in with Google'}</span>
            </button>
          ) : (
            <div className="flex items-center gap-3 rounded-lg border border-[#24324A] bg-[#101724] px-3.5 py-2">
              <div className="min-w-0 text-right">
                <p className="truncate text-xs font-semibold text-[#F1F5F9]">
                  {channelInfo?.title || googleUser?.displayName || 'YouTube Connected'}
                </p>
                <p className="truncate text-[11px] text-[#34D399]">
                  {googleUser?.email || 'Ready to upload'}
                </p>
              </div>
              <button
                type="button"
                onClick={handleGoogleSignOut}
                aria-label="Sign out of Google"
                className="rounded-md p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#FB7185]"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {studioMode === 'agents' && (
        <YouTubeAgentsPanel
          settings={settings}
          agents={youtubeAgents}
          queue={youtubePostQueue}
          agentSettings={youtubeAgentSettings}
          needsAuth={needsAuth}
          googleUser={googleUser}
          channelInfo={channelInfo}
          onGoogleLogin={handleGoogleLogin}
          onSnapshotUpdated={onSnapshotUpdated}
          onOpenProjectInEditor={(loadedProject, media, loadedTheme) => {
            setProject(loadedProject);
            setTopic(loadedProject.topic);
            setFormat(loadedProject.format);
            if (loadedTheme) setVideoTheme(loadedTheme);
            if (media?.videoBlob) setVideoBlob(media.videoBlob);
            if (media?.videoUrl) setVideoUrl(media.videoUrl);
            if (media?.durationSec) setVideoDurationSec(media.durationSec);
            if (media?.thumbnailBlob) setThumbnailBlob(media.thumbnailBlob);
            if (media?.thumbnailDataUrl) setThumbnailDataUrl(media.thumbnailDataUrl);
            setStudioMode('single');
            onNotify(`Loaded "${loadedProject.title}" into Single Video Editor.`);
          }}
          onNotify={onNotify}
        />
      )}

      {studioMode === 'batch' && (
        <section className="flex flex-col gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                Batch Reels &amp; Shorts Auto-Scheduler
              </h2>
              <p className="text-xs text-[#94A3B8]">
                Plan multiple Reels/Shorts at a daily cadence, produce any slot in 1 click, retry
                failed items, and feed performance insights back into PRIME Memory.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
            <input
              type="text"
              value={batchNiche}
              onChange={(ev) => setBatchNiche(ev.target.value)}
              placeholder="Niche theme (e.g., AI productivity hacks for founders)..."
              className="md:col-span-6 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <select
              aria-label="Videos in batch"
              value={batchCount}
              onChange={(ev) => setBatchCount(Number(ev.target.value))}
              className="md:col-span-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9]"
            >
              <option value={3}>3 Videos</option>
              <option value={6}>6 Videos</option>
              <option value={9}>9 Videos</option>
              <option value={12}>12 Videos</option>
            </select>
            <select
              aria-label="Cadence posts per day"
              value={postsPerDay}
              onChange={(ev) => setPostsPerDay(Number(ev.target.value))}
              className="md:col-span-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9]"
            >
              <option value={2}>2 / day</option>
              <option value={4}>4 / day</option>
              <option value={6}>6 / day</option>
            </select>
            <button
              type="button"
              disabled={!batchNiche.trim() || isPlanningBatch}
              onClick={async () => {
                setIsPlanningBatch(true);
                try {
                  const res = await fetch('/api/prime/youtube/batch-plan', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                      topic: batchNiche.trim(),
                      count: batchCount,
                      postsPerDay,
                      format: '9:16',
                    }),
                  });
                  const data = await res.json();
                  if (!res.ok) throw new Error(data.error || 'Batch planning failed.');
                  onSnapshotUpdated?.(data as PrimeVaultSnapshot);
                  onNotify(`Scheduled ${batchCount} Reels at ${postsPerDay}/day cadence.`);
                } catch (err) {
                  onNotify(err instanceof Error ? err.message : 'Unable to schedule batch.');
                } finally {
                  setIsPlanningBatch(false);
                }
              }}
              className="md:col-span-2 inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#E5C07B] px-3 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap"
            >
              <Wand2 className="h-3.5 w-3.5" />
              <span>{isPlanningBatch ? 'Planning...' : 'Plan Batch'}</span>
            </button>
          </div>

          {batchVideos.length > 0 && (
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {batchVideos.map((item, idx) => (
                <div
                  key={item.id}
                  className={`flex flex-col justify-between rounded-xl border bg-[#080C14] p-3.5 ${
                    item.status === 'failed' ? 'border-[#FB7185]/60' : 'border-[#24324A]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-[11px] font-mono-tabular">
                      <span className="font-semibold text-[#E5C07B]">
                        Slot #{idx + 1} · {item.format} ·{' '}
                        {new Date(item.scheduledForMs).toLocaleString([], {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      <span
                        className={
                          item.status === 'failed'
                            ? 'font-semibold text-[#FB7185]'
                            : item.status === 'published'
                              ? 'text-[#34D399]'
                              : 'text-[#38BDF8]'
                        }
                      >
                        {item.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="mt-1.5 text-sm font-semibold text-[#F1F5F9]">{item.topic}</p>
                    <p className="mt-0.5 text-xs text-[#94A3B8]">Hook: {item.hook}</p>
                    {item.error && <p className="mt-1 text-xs text-[#FB7185]">{item.error}</p>}
                  </div>

                  <div className="mt-3 flex flex-wrap items-center justify-end gap-2 border-t border-[#24324A] pt-2.5">
                    {item.status === 'failed' && (
                      <button
                        type="button"
                        onClick={async () => {
                          const res = await fetch(
                            `/api/prime/youtube/batch/${encodeURIComponent(item.id)}/retry`,
                            {method: 'POST'},
                          );
                          if (res.ok) {
                            onSnapshotUpdated?.((await res.json()) as PrimeVaultSnapshot);
                            onNotify(`Re-queued batch slot "${item.topic}".`);
                          }
                        }}
                        className="inline-flex items-center gap-1 rounded-md border border-[#FB7185]/50 bg-[#161F30] px-2.5 py-1 text-xs font-semibold text-[#FB7185]"
                      >
                        <RotateCcw className="h-3 w-3" />
                        <span>Do Again</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setTopic(item.topic);
                        setFormat(item.format);
                        setStudioMode('single');
                        onNotify(`Loaded "${item.topic}" into Auto Create & Post Video.`);
                      }}
                      className="inline-flex items-center gap-1 rounded-md bg-[#E5C07B] px-2.5 py-1 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
                    >
                      <Play className="h-3 w-3" />
                      <span>Open &amp; Produce</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Learn From What Worked */}
          <div className="flex flex-wrap items-center gap-2 border-t border-[#24324A] pt-3">
            <input
              type="text"
              value={learnNote}
              onChange={(ev) => setLearnNote(ev.target.value)}
              placeholder="Record what performed well (e.g., 3-second question hooks doubled retention)..."
              className="min-w-[240px] flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <button
              type="button"
              disabled={!learnNote.trim() || isSavingLearn}
              onClick={async () => {
                setIsSavingLearn(true);
                try {
                  const res = await fetch('/api/prime/youtube/learn-performance', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                      title: project?.title || batchNiche || 'YouTube Batch',
                      resultNote: learnNote.trim(),
                    }),
                  });
                  if (res.ok) {
                    onSnapshotUpdated?.((await res.json()) as PrimeVaultSnapshot);
                    setLearnNote('');
                    onNotify('Saved post performance insight into Memory Vault for future batches.');
                  }
                } finally {
                  setIsSavingLearn(false);
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#34D399]/50 bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#34D399] disabled:opacity-40"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Save Performance Insight</span>
            </button>
          </div>
        </section>
      )}

      {/* Single Video Studio */}
      {studioMode === 'single' && (
      <>
      <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#24324A] pb-3">
            <div className="inline-flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#080C14] p-1">
              <button
                type="button"
                onClick={() => setEngineMode('free_local')}
                className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap ${
                  engineMode === 'free_local' ? 'bg-[#161F30] text-[#34D399]' : 'text-[#94A3B8]'
                }`}
              >
                Free Instant Engine (Unlimited)
              </button>
              <button
                type="button"
                onClick={() => setEngineMode('ai_producer')}
                className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap ${
                  engineMode === 'ai_producer' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
                }`}
              >
                Gemini AI Producer
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <label className="inline-flex cursor-pointer items-center gap-1.5 text-[#94A3B8]">
                <input
                  type="checkbox"
                  checked={ambientMusicEnabled}
                  onChange={(ev) => setAmbientMusicEnabled(ev.target.checked)}
                  className="h-3.5 w-3.5 rounded accent-[#E5C07B]"
                />
                <span>Royalty-Free Audio Bed</span>
              </label>
              <select
                aria-label="Single video theme"
                value={videoTheme}
                onChange={(ev) => setVideoTheme(ev.target.value as YouTubeVideoTheme)}
                className="rounded-md border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs text-[#F1F5F9]"
              >
                <option value="gold">Theme: Gold</option>
                <option value="cyan">Theme: Cyan</option>
                <option value="emerald">Theme: Emerald</option>
                <option value="crimson">Theme: Crimson</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-12">
            <input
              type="text"
              value={topic}
              onChange={(ev) => setTopic(ev.target.value)}
              placeholder="Enter video topic (e.g., 5 Morning Habits That Double Deep Focus)..."
              className="lg:col-span-7 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2.5 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />

            <div className="lg:col-span-2 grid grid-cols-2 gap-1 rounded-lg border border-[#24324A] bg-[#080C14] p-1">
              <button
                type="button"
                onClick={() => setFormat('16:9')}
                className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  format === '16:9' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
                }`}
              >
                16:9 HD
              </button>
              <button
                type="button"
                onClick={() => setFormat('9:16')}
                className={`rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors ${
                  format === '9:16' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
                }`}
              >
                9:16 Short
              </button>
            </div>

            <button
              type="button"
              disabled={busy || !topic.trim()}
              onClick={handleRunFullPipeline}
              className="lg:col-span-3 inline-flex items-center justify-center gap-2 rounded-lg bg-[#E5C07B] px-4 py-2.5 text-sm font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap"
            >
              <Wand2 className="h-4 w-4" />
              <span>
                {isRunningAll ? 'Creating & Preparing...' : 'Auto Create & Post Video'}
              </span>
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-[#94A3B8]">
            <label className="inline-flex cursor-pointer items-center gap-2">
              <input
                type="checkbox"
                checked={autoPostOnComplete}
                onChange={(ev) => setAutoPostOnComplete(ev.target.checked)}
                className="h-3.5 w-3.5 rounded border-[#24324A] bg-[#080C14] accent-[#E5C07B]"
              />
              <span>Automatically prepare &amp; open YouTube upload confirmation after video creation</span>
            </label>
            <div className="flex items-center gap-2">
              <span>Visibility:</span>
              <select
                aria-label="Default YouTube upload visibility"
                value={privacyStatus}
                onChange={(ev) => setPrivacyStatus(ev.target.value as YouTubePrivacyStatus)}
                className="rounded-md border border-[#24324A] bg-[#080C14] px-2 py-1 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              >
                <option value="private">Private</option>
                <option value="unlisted">Unlisted</option>
                <option value="public">Public</option>
              </select>
            </div>
          </div>

          {/* Step-by-step action bar */}
          <div className="flex flex-wrap items-center gap-2.5 border-t border-[#24324A] pt-3">
            <button
              type="button"
              disabled={busy || !topic.trim()}
              onClick={() =>
                generateScriptPackage(topic.trim(), format).catch((err) =>
                  onNotify(err instanceof Error ? err.message : 'Script generation failed.'),
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap"
            >
              <Sparkles className="h-3.5 w-3.5 text-[#E5C07B]" />
              <span>{isWritingScript ? 'Writing...' : '1. Auto Write & Thumb'}</span>
            </button>

            <button
              type="button"
              disabled={busy || !project}
              onClick={() =>
                project &&
                renderVideoAsset(project).catch((err) =>
                  onNotify(err instanceof Error ? err.message : 'Video rendering failed.'),
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap"
            >
              <Film className="h-3.5 w-3.5 text-[#38BDF8]" />
              <span>{isRendering ? 'Rendering...' : '2. Auto Create Video'}</span>
            </button>

            <button
              type="button"
              disabled={busy || !project}
              onClick={() =>
                project &&
                runRecheck(project, true).catch((err) =>
                  onNotify(err instanceof Error ? err.message : 'Auto-recheck failed.'),
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap"
            >
              <ShieldCheck className="h-3.5 w-3.5 text-[#34D399]" />
              <span>{isRechecking ? 'Rechecking...' : '3. Auto Recheck'}</span>
            </button>

            <button
              type="button"
              disabled={busy || !project || !videoBlob}
              onClick={() => {
                if (needsAuth) {
                  handleGoogleLogin();
                } else {
                  setConfirmPublishOpen(true);
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-3 py-1.5 text-xs font-semibold text-[#E5C07B] hover:bg-[#1E293E] disabled:opacity-40 whitespace-nowrap"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>4. Auto Post to YouTube</span>
            </button>
          </div>

          {isRendering && (
            <div className="rounded-lg border border-[#24324A] bg-[#080C14] p-3">
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <span className="text-[#F1F5F9]">{renderStage}</span>
                <span className="font-mono-tabular text-[#E5C07B]">{renderProgress}%</span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#161F30]">
                <div
                  className="h-full bg-[#E5C07B] transition-all duration-150"
                  style={{width: `${renderProgress}%`}}
                />
              </div>
            </div>
          )}
        </div>
      </section>

      {!project ? (
        <div className="flex flex-1 flex-col items-center justify-center rounded-xl border border-dashed border-[#24324A] bg-[#101724] p-10 text-center">
          <Play className="h-8 w-8 text-[#E5C07B]" />
          <h2 className="mt-3 font-display text-base font-semibold text-[#F1F5F9]">
            Ready to produce &amp; publish your next YouTube video
          </h2>
          <p className="mt-1 max-w-md text-xs leading-relaxed text-[#94A3B8]">
            Enter a topic above and click Run Full Auto-Pipeline to automatically generate the
            script, cover thumbnail, voiceover HD video, synced captions, SEO description, audit,
            and guided YouTube upload.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* Left column: Auto Thumbnail + Video preview + Script scenes */}
          <div className="flex flex-col gap-5 lg:col-span-7">
            {/* Auto Thumbnail Generator & Preview */}
            <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
                  <ImageIcon className="h-4 w-4 text-[#E5C07B]" />
                  <span>Auto Thumbnail</span>
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={isGeneratingThumb}
                    onClick={() => buildThumbnailAsset(project)}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B]"
                  >
                    <RefreshCw className="h-3 w-3 text-[#E5C07B]" />
                    <span>Regenerate</span>
                  </button>
                  {thumbnailDataUrl && (
                    <button
                      type="button"
                      onClick={handleDownloadThumbnail}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
                    >
                      <Download className="h-3 w-3" />
                      <span>Download .jpg</span>
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-12">
                <div className="md:col-span-7">
                  {thumbnailDataUrl ? (
                    <img
                      src={thumbnailDataUrl}
                      alt="Auto-generated YouTube thumbnail"
                      className="max-h-64 w-full rounded-lg border border-[#24324A] bg-[#080C14] object-contain"
                    />
                  ) : (
                    <div className="flex h-36 items-center justify-center rounded-lg border border-dashed border-[#24324A] bg-[#080C14] text-xs text-[#94A3B8]">
                      Generating cover thumbnail...
                    </div>
                  )}
                </div>
                <div className="flex flex-col gap-2.5 md:col-span-5">
                  <div>
                    <label className="mb-1 block text-xs text-[#94A3B8]">Thumbnail Hook</label>
                    <input
                      type="text"
                      value={project.thumbnailHook}
                      onChange={(ev) =>
                        setProject({...project, thumbnailHook: ev.target.value.toUpperCase()})
                      }
                      className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-semibold text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-[#94A3B8]">Thumbnail Subhead</label>
                    <input
                      type="text"
                      value={project.thumbnailSubhead}
                      onChange={(ev) =>
                        setProject({...project, thumbnailSubhead: ev.target.value})
                      }
                      className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                    />
                  </div>
                  <p className="text-[11px] text-[#94A3B8]">
                    Edit hook text and click Regenerate; uploaded automatically with your video.
                  </p>
                </div>
              </div>
            </section>

            {/* Video preview */}
            <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                    Rendered Video Preview
                  </h2>
                  <p className="text-xs text-[#94A3B8] font-mono-tabular">
                    Format {project.format}
                    {videoDurationSec ? ` · ${videoDurationSec.toFixed(1)}s` : ''}
                    {videoBlob ? ` · ${(videoBlob.size / (1024 * 1024)).toFixed(2)} MB` : ''}
                  </p>
                </div>

                {videoUrl && (
                  <button
                    type="button"
                    onClick={handleDownloadVideo}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
                  >
                    <Download className="h-3.5 w-3.5" />
                    <span>Download .webm</span>
                  </button>
                )}
              </div>

              {videoUrl ? (
                <video
                  src={videoUrl}
                  controls
                  className="max-h-[420px] w-full rounded-lg border border-[#24324A] bg-[#080C14]"
                />
              ) : (
                <div className="flex h-48 flex-col items-center justify-center rounded-lg border border-dashed border-[#24324A] bg-[#080C14] p-6 text-center">
                  <Film className="h-6 w-6 text-[#38BDF8]" />
                  <p className="mt-2 text-xs text-[#94A3B8]">
                    Script &amp; thumbnail ready. Click{' '}
                    <strong className="text-[#F1F5F9]">2. Auto Create Video</strong> to render HD
                    frames, voiceover narration, and burned-in captions.
                  </p>
                </div>
              )}
            </section>

            {/* Script Scenes */}
            <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
                  <FileText className="h-4 w-4 text-[#E5C07B]" />
                  <span>Auto-Written Script ({project.scenes.length} Scenes)</span>
                </h2>
              </div>

              <div className="flex flex-col gap-3">
                {project.scenes.map((scene, idx) => (
                  <div
                    key={scene.sceneNumber}
                    className="rounded-lg border border-[#24324A] bg-[#080C14] p-3.5"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs text-[#94A3B8] font-mono-tabular">
                      <span className="font-semibold text-[#E5C07B]">
                        Scene {scene.sceneNumber} · {scene.visualHeadline}
                      </span>
                      <span>{scene.durationSec}s</span>
                    </div>
                    <textarea
                      rows={2}
                      value={scene.narration}
                      onChange={(ev) => {
                        const updatedScenes = project.scenes.map((s, sIdx) =>
                          sIdx === idx ? {...s, narration: ev.target.value} : s,
                        );
                        setProject({...project, scenes: updatedScenes});
                      }}
                      className="mt-2 w-full rounded border border-[#24324A] bg-[#101724] px-2.5 py-1.5 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                    />
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Right column: What To Do To Post, Description, Captions, Recheck */}
          <div className="flex flex-col gap-5 lg:col-span-5">
            {/* Auto What To Do To Post Guide & Direct Publish */}
            <section className="rounded-xl border border-[#E5C07B]/40 bg-[#101724] p-5">
              <div className="flex items-center justify-between gap-2">
                <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
                  <Upload className="h-4 w-4 text-[#E5C07B]" />
                  <span>Auto What To Do To Post</span>
                </h2>
              </div>

              <div className="mt-3 flex flex-col gap-1.5">
                {postChecklist.map((step, i) => (
                  <div
                    key={step.label}
                    className="flex items-center gap-2.5 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs"
                  >
                    <CheckCircle2
                      className={`h-3.5 w-3.5 shrink-0 ${
                        step.done ? 'text-[#34D399]' : 'text-[#475569]'
                      }`}
                    />
                    <span className={step.done ? 'text-[#F1F5F9]' : 'text-[#94A3B8]'}>
                      {i + 1}. {step.label}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-3.5 flex flex-col gap-3">
                <div>
                  <label className="mb-1 block text-xs text-[#94A3B8]">Upload Visibility</label>
                  <select
                    value={privacyStatus}
                    onChange={(ev) => setPrivacyStatus(ev.target.value as YouTubePrivacyStatus)}
                    className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                  >
                    <option value="private">Private (Review in YouTube Studio first)</option>
                    <option value="unlisted">Unlisted (Share via link)</option>
                    <option value="public">Public (Publish immediately)</option>
                  </select>
                </div>

                <button
                  type="button"
                  disabled={busy}
                  onClick={handleAutoNextPostStep}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#E5C07B] px-4 py-2.5 text-sm font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:opacity-40"
                >
                  <Wand2 className="h-4 w-4" />
                  <span>{isUploading ? 'Uploading to YouTube...' : nextActionLabel}</span>
                </button>

                {publishResult && (
                  <div className="rounded-lg border border-[#34D399]/40 bg-[#34D399]/10 p-3 text-xs">
                    <p className="font-semibold text-[#34D399]">
                      Uploaded to YouTube
                      {publishResult.thumbnailAttached ? ' · Thumbnail set' : ''}
                      {publishResult.captionsAttached ? ' · Captions attached' : ''}
                    </p>
                    <a
                      href={publishResult.watchUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-1 inline-flex items-center gap-1 text-[#E5C07B] underline-offset-4 hover:underline"
                    >
                      <span>Open video on YouTube</span>
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                )}
              </div>
            </section>

            {/* Auto Description & SEO Metadata */}
            <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
              <div className="mb-3 flex items-center justify-between gap-2">
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  Auto Description &amp; SEO
                </h2>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(`${project.title}\n\n${project.description}`);
                    onNotify('Copied YouTube title and description.');
                  }}
                  className="inline-flex items-center gap-1 text-xs text-[#E5C07B] hover:underline"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy</span>
                </button>
              </div>

              <div className="flex flex-col gap-3">
                <div>
                  <label className="mb-1 block text-xs text-[#94A3B8]">YouTube Title</label>
                  <input
                    type="text"
                    value={project.title}
                    onChange={(ev) => setProject({...project, title: ev.target.value})}
                    className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs text-[#94A3B8]">
                    Description, Chapters &amp; Hashtags
                  </label>
                  <textarea
                    rows={5}
                    value={project.description}
                    onChange={(ev) => setProject({...project, description: ev.target.value})}
                    className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs leading-relaxed text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs text-[#94A3B8]">SEO Tags</label>
                  <input
                    type="text"
                    value={project.tags.join(', ')}
                    onChange={(ev) =>
                      setProject({
                        ...project,
                        tags: ev.target.value
                          .split(',')
                          .map((t) => t.trim())
                          .filter(Boolean),
                      })
                    }
                    className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#94A3B8] focus:border-[#E5C07B] focus:outline-none"
                  />
                </div>
              </div>
            </section>

            {/* Auto Captions (.srt) */}
            <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
              <div className="mb-3 flex items-center justify-between gap-2">
                <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
                  <Subtitles className="h-4 w-4 text-[#38BDF8]" />
                  <span>Auto Captions ({project.captions.length})</span>
                </h2>
                <button
                  type="button"
                  onClick={handleDownloadSrt}
                  className="inline-flex items-center gap-1 text-xs text-[#E5C07B] hover:underline"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download .srt</span>
                </button>
              </div>

              <div className="flex max-h-40 flex-col gap-2 overflow-y-auto pr-1">
                {project.captions.map((cue) => (
                  <div
                    key={cue.index}
                    className="flex items-start gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs"
                  >
                    <span className="shrink-0 font-mono-tabular text-[#E5C07B]">
                      {formatCueTime(cue.startSec)}
                    </span>
                    <span className="text-[#F1F5F9]">{cue.text}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Auto Recheck Quality Audit */}
            <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
              <div className="flex items-center justify-between gap-2">
                <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
                  <ShieldCheck className="h-4 w-4 text-[#34D399]" />
                  <span>Auto Recheck &amp; Audit</span>
                </h2>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() =>
                    runRecheck(project, false).catch((err) =>
                      onNotify(err instanceof Error ? err.message : 'Recheck failed.'),
                    )
                  }
                  className="text-xs font-medium text-[#E5C07B] hover:underline disabled:opacity-40"
                >
                  {isRechecking ? 'Checking...' : 'Run Audit'}
                </button>
              </div>

              {!project.recheckReport ? (
                <p className="mt-2 text-xs text-[#94A3B8]">
                  Run Auto Recheck to validate script pacing, caption coverage, YouTube SEO, and
                  safety compliance before uploading.
                </p>
              ) : (
                <div className="mt-3 flex flex-col gap-2.5">
                  <p className="text-xs leading-relaxed text-[#F1F5F9]">
                    {project.recheckReport.summary}
                  </p>
                  <div className="flex flex-col gap-1.5">
                    {project.recheckReport.checks.map((chk) => (
                      <div
                        key={chk.checkName}
                        className="flex items-start gap-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs"
                      >
                        {chk.passed ? (
                          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#34D399]" />
                        ) : (
                          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#E5C07B]" />
                        )}
                        <div>
                          <p className="font-medium text-[#F1F5F9]">{chk.checkName}</p>
                          <p className="text-[#94A3B8]">{chk.note}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {(project.recheckReport.improvedTitle ||
                    project.recheckReport.improvedDescription) && (
                    <button
                      type="button"
                      onClick={applyRecheckImprovements}
                      className="mt-1 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-3 py-2 text-xs font-semibold text-[#E5C07B] hover:bg-[#1C273B]"
                    >
                      Apply Auto-Improvements
                    </button>
                  )}
                </div>
              )}
            </section>
          </div>
        </div>
      )}
      </>
      )}

      {/* Mandatory Explicit Confirmation Modal before YouTube Upload */}
      {confirmPublishOpen && project && videoBlob && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
        >
          <div className="w-full max-w-lg rounded-xl border border-[#24324A] bg-[#101724] p-6">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Confirm YouTube Upload
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
              Are you sure you want to publish this video, thumbnail, and captions to your YouTube
              channel?
            </p>

            <div className="mt-4 flex flex-col gap-2 rounded-lg border border-[#24324A] bg-[#080C14] p-4 text-xs">
              <div className="flex justify-between gap-3">
                <span className="text-[#94A3B8]">Channel</span>
                <span className="font-medium text-[#F1F5F9]">
                  {channelInfo?.title || googleUser?.email || 'Connected YouTube Channel'}
                </span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-[#94A3B8]">Title</span>
                <span className="truncate font-medium text-[#E5C07B]">{project.title}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-[#94A3B8]">Visibility</span>
                <span className="font-medium capitalize text-[#F1F5F9]">{privacyStatus}</span>
              </div>
              <div className="flex justify-between gap-3 font-mono-tabular">
                <span className="text-[#94A3B8]">Bundle</span>
                <span className="text-[#F1F5F9]">
                  {(videoBlob.size / (1024 * 1024)).toFixed(2)} MB ·{' '}
                  {thumbnailBlob ? 'Cover Thumbnail' : 'No Thumbnail'} · {project.captions.length}{' '}
                  captions
                </span>
              </div>
            </div>

            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                disabled={isUploading}
                onClick={() => setConfirmPublishOpen(false)}
                className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-sm font-medium text-[#F1F5F9] disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isUploading}
                onClick={handleConfirmPublish}
                className="rounded-lg bg-[#E5C07B] px-4 py-2 text-sm font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40"
              >
                {isUploading ? 'Publishing...' : 'Confirm & Publish'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
