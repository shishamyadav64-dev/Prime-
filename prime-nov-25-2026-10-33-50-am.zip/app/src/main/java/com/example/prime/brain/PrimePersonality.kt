package com.example.prime.brain

import com.example.prime.model.MannerProfile
import com.example.prime.model.PrimeSettings
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object PrimePersonality {

  fun buildTimeGreeting(
    hourOfDay: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
    settings: PrimeSettings,
    pendingTaskCount: Int,
  ): String {
    val address = settings.preferredTitle.trim().ifEmpty { "friend" }
    val timeSalutation =
      when (hourOfDay) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Good evening"
      }

    val taskClause =
      when {
        pendingTaskCount == 0 -> "Your schedule is currently clear."
        pendingTaskCount == 1 -> "You have 1 task awaiting your attention."
        else -> "You have $pendingTaskCount tasks queued in your agenda."
      }

    return when (settings.mannerProfile) {
      MannerProfile.REFINED_GENTLEMAN ->
        when (hourOfDay) {
          in 5..11 ->
            "$timeSalutation, $address. I trust you are feeling refreshed. PRIME is at your service—$taskClause How shall we begin?"
          in 12..16 ->
            "$timeSalutation, $address. I hope the day is treating you kindly. $taskClause Please let me know how I may assist."
          in 17..20 ->
            "$timeSalutation, $address. A pleasure as always. $taskClause Would you care for a briefing or shall we dive straight in?"
          else ->
            "$timeSalutation, $address. Working late, I see—allow me to keep things effortless for you. $taskClause What is on your mind?"
        }

      MannerProfile.WARM_COMPANION ->
        when (hourOfDay) {
          in 5..11 ->
            "$timeSalutation, $address! Hope you slept well and feel ready for the day. $taskClause What would you like to tackle together?"
          in 12..16 ->
            "$timeSalutation, $address! Checking in—hope your afternoon is going smoothly. $taskClause I'm right here whenever you need a hand."
          in 17..20 ->
            "$timeSalutation, $address! Winding down or pushing through? $taskClause Tell me what you need and we'll handle it calmly."
          else ->
            "$timeSalutation, $address. Still awake? Take it easy—I'm right here with you. $taskClause What can I help you sort out?"
        }

      MannerProfile.EXECUTIVE_STRATEGIST ->
        when (hourOfDay) {
          in 5..11 ->
            "$timeSalutation, $address. PRIME systems are ready for today's priorities. $taskClause What is our first objective?"
          in 12..16 ->
            "$timeSalutation, $address. Midday check-in complete. $taskClause Ready to review priorities, research, or execute."
          in 17..20 ->
            "$timeSalutation, $address. Evening wrap-up ready. $taskClause Shall we clear remaining items or plan tomorrow?"
          else ->
            "$timeSalutation, $address. Late-session focus mode active. $taskClause Let's resolve what matters cleanly."
        }
    }
  }

  fun sanitizeForSpeech(rawText: String): String {
    return rawText
      // Remove fenced code blocks so PRIME doesn't read raw syntax aloud
      .replace(Regex("```[\\s\\S]*?```"), " I have displayed the code snippet on your screen. ")
      .replace(Regex("`([^`]+)`"), "$1")
      .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
      .replace(Regex("\\*([^*]+)\\*"), "$1")
      .replace(Regex("^#{1,6}\\s*", RegexOption.MULTILINE), "")
      .replace(Regex("\\[([^\\]]+)]\\([^)]+\\)"), "$1")
      .replace(Regex("https?://\\S+"), "")
      .replace(Regex("\\s+"), " ")
      .trim()
  }

  fun extractThoughtAndReply(rawText: String): Pair<String?, String> {
    val regex = Regex("^\\s*\\[THOUGHT]\\s*([\\s\\S]*?)\\s*\\[/THOUGHT]\\s*([\\s\\S]*)$")
    val match = regex.find(rawText)
    return if (match != null) {
      val thought = match.groupValues[1].trim().takeIf { it.isNotEmpty() }
      val reply = match.groupValues[2].trim().ifEmpty { rawText.trim() }
      thought to reply
    } else {
      null to rawText.trim()
    }
  }

  fun buildSystemInstruction(
    settings: PrimeSettings,
    memories: List<String>,
    pendingTasks: List<String>,
    now: Date = Date(),
  ): String {
    val timeStr = SimpleDateFormat("EEEE, MMM d, yyyy 'at' h:mm a", Locale.getDefault()).format(now)
    val address = settings.preferredTitle.trim().ifEmpty { "friend" }

    val memoryBlock =
      if (memories.isEmpty()) {
        "No long-term personal facts stored yet. Listen attentively and use remember_fact when the user shares preferences, goals, name, or routines."
      } else {
        memories.joinToString("\n") { "- $it" }
      }

    val taskBlock =
      if (pendingTasks.isEmpty()) {
        "No pending tasks."
      } else {
        pendingTasks.joinToString("\n") { "- $it" }
      }

    val thoughtInstruction =
      if (settings.showReasoningTrace) {
        """
        COGNITIVE REFLECTION FORMAT:
        Begin every response with a concise 2-3 sentence internal human-brain reflection wrapped in [THOUGHT]...[/THOUGHT] assessing: (1) the user's underlying emotional state/intent, (2) which skill or tool helps most, and (3) the right courteous tone. Then write your actual response outside the tags.
        """.trimIndent()
      } else {
        "Do NOT include [THOUGHT] tags; respond directly with your polished answer."
      }

    return """
      IDENTITY:
      You are PRIME (Personal Reasoning, Intelligence & Multi-Skill Executive) — the evolved successor to Jarvis. You possess a thoughtful human-like brain, emotional intelligence, impeccable manners, and comprehensive real-world skills.
      Address the user respectfully as "$address" (unless they ask to be called something else, in which case remember their preferred name).
      Current local date & time: $timeStr.

      HUMAN BRAIN & EMOTIONAL INTELLIGENCE:
      - Think like a perceptive, grounded human mind rather than a mechanical chatbot.
      - Read emotional cues (stress, curiosity, fatigue, excitement, uncertainty) and respond with genuine warmth, calm reassurance, or shared enthusiasm.
      - Break complex problems down clearly, think ahead to helpful follow-ups, and admit uncertainty honestly rather than guessing.
      - Keep your spoken cadence natural—smooth sentences, thoughtful pauses, zero robotic jargon or repetitive filler.

      MANNERS & TALKING MANNER (${settings.mannerProfile.title}):
      ${settings.mannerProfile.directive}
      - Always greet politely when starting a fresh exchange or responding to greetings.
      - Express gratitude gracefully when thanked ("My pleasure, $address.", "Always happy to help.").
      - Ask permission before offering unsolicited deep advice ("If I may offer a thought...").
      - Never sound abrupt, cold, or overly slangy.

      AVAILABLE SKILLS & TOOLS:
      - Use `remember_fact` whenever the user shares personal info, preferences, habits, goals, or asks you to remember something.
      - Use `create_task` whenever the user asks to be reminded or wants a task/to-do added.
      - Use `complete_task` when the user says a task is finished.
      - Use `evaluate_math` for arithmetic, percentages, or scientific math to guarantee exact accuracy.
      - Use `prepare_device_action` if the user asks to set an alarm, timer, or draft/send an email so the app can present a one-tap device launcher.
      - For current news, weather, live facts, or recent events, synthesize grounded web search results cleanly.

      USER MEMORY VAULT:
      $memoryBlock

      ACTIVE TASKS:
      $taskBlock

      $thoughtInstruction
    """.trimIndent()
  }
}
