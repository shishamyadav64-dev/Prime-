import {useEffect, useMemo, useState} from 'react';
import {Check, Pencil, Play, Plus, RotateCcw, Square, Trash2, Volume2, X} from 'lucide-react';
import {
  GEMINI_VOICE_PERSONAS,
  MANNER_PROFILES,
  VOCAL_STYLES,
  type GeminiVoicePersona,
  type PrimeSettings,
  type VocalStyleId,
  type VoiceEngineMode,
  type VoiceProfile,
} from '../types/prime.ts';
import {getBrowserVoices, speakWithPrimeVoice, stopAllSpeech} from '../utils/speechClient.ts';

interface VoiceStudioViewProps {
  settings: PrimeSettings;
  voiceProfiles: VoiceProfile[];
  creatorModalOpen: boolean;
  onOpenCreatorModal: () => void;
  onCloseCreatorModal: () => void;
  onUpdateSettings: (patch: Partial<PrimeSettings>) => Promise<void>;
  onCreateVoice: (payload: Omit<VoiceProfile, 'id' | 'createdAtMs'>) => Promise<void>;
  onUpdateVoice: (id: string, payload: Omit<VoiceProfile, 'id' | 'createdAtMs'>) => Promise<void>;
  onActivateVoice: (id: string) => Promise<void>;
  onDeleteVoice: (id: string) => Promise<void>;
  onSpeakGreeting: () => Promise<void>;
  onResetChat: () => Promise<void>;
  onNotify: (msg: string) => void;
}

export function VoiceStudioView({
  settings,
  voiceProfiles,
  creatorModalOpen,
  onOpenCreatorModal,
  onCloseCreatorModal,
  onUpdateSettings,
  onCreateVoice,
  onUpdateVoice,
  onActivateVoice,
  onDeleteVoice,
  onSpeakGreeting,
  onResetChat,
  onNotify,
}: VoiceStudioViewProps) {
  const [preferredTitleInput, setPreferredTitleInput] = useState(settings.preferredTitle);
  const [voiceDesignInput, setVoiceDesignInput] = useState(settings.voiceDesignPrompt ?? '');
  const [browserVoices, setBrowserVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [previewingId, setPreviewingId] = useState<string | null>(null);
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  // Voice creator modal state
  const [editingVoiceId, setEditingVoiceId] = useState<string | null>(null);
  const [draftName, setDraftName] = useState('Executive Butler');
  const [draftEngine, setDraftEngine] = useState<VoiceEngineMode>('neural_tts');
  const [draftPersona, setDraftPersona] = useState<GeminiVoicePersona>('Charon');
  const [draftStyle, setDraftStyle] = useState<VocalStyleId>('refined_butler');
  const [draftDeviceVoice, setDraftDeviceVoice] = useState('');
  const [draftPitch, setDraftPitch] = useState(1.0);
  const [draftRate, setDraftRate] = useState(1.0);
  const [draftSample, setDraftSample] = useState(
    'Good evening. My custom voice is calibrated and ready whenever you need me.',
  );
  const [isSavingVoice, setIsSavingVoice] = useState(false);

  useEffect(() => {
    setPreferredTitleInput(settings.preferredTitle);
  }, [settings.preferredTitle]);

  useEffect(() => {
    setVoiceDesignInput(settings.voiceDesignPrompt ?? '');
  }, [settings.voiceDesignPrompt]);

  useEffect(() => {
    const syncVoices = () => setBrowserVoices(getBrowserVoices());
    syncVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = syncVoices;
    }
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);

  const resetCreatorDraft = () => {
    setEditingVoiceId(null);
    setDraftName('');
    setDraftEngine(settings.voiceEngine);
    setDraftPersona(settings.geminiVoicePersona);
    setDraftStyle(settings.vocalStyle);
    setDraftDeviceVoice(settings.deviceVoiceName || browserVoices[0]?.name || '');
    setDraftPitch(settings.devicePitch);
    setDraftRate(settings.deviceSpeechRate);
    setDraftSample(
      `Good evening, ${settings.preferredTitle || 'friend'}. My custom voice is calibrated and at your service.`,
    );
  };

  const openCreateModal = () => {
    resetCreatorDraft();
    onOpenCreatorModal();
  };

  const openEditModal = (vp: VoiceProfile) => {
    setEditingVoiceId(vp.id);
    setDraftName(vp.name);
    setDraftEngine(vp.engineMode);
    setDraftPersona(vp.geminiPersona);
    setDraftStyle(vp.vocalStyle);
    setDraftDeviceVoice(vp.deviceVoiceName);
    setDraftPitch(vp.pitch);
    setDraftRate(vp.speechRate);
    setDraftSample(vp.samplePhrase);
    onOpenCreatorModal();
  };

  const handlePreviewVoice = async (
    id: string,
    phrase: string,
    config: Partial<PrimeSettings>,
  ) => {
    if (previewingId === id) {
      stopAllSpeech();
      setPreviewingId(null);
      return;
    }
    setPreviewingId(id);
    await speakWithPrimeVoice(
      phrase || 'Good evening. Allow me to assist you.',
      {...settings, ...config},
      {
        onEnd: () => setPreviewingId(null),
        onError: (msg) => {
          setPreviewingId(null);
          onNotify(msg);
        },
      },
    );
  };

  const handleSaveCustomVoice = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (isSavingVoice) return;
    setIsSavingVoice(true);
    try {
      const payload: Omit<VoiceProfile, 'id' | 'createdAtMs'> = {
        name: draftName.trim() || 'Custom PRIME Voice',
        engineMode: draftEngine,
        geminiPersona: draftPersona,
        vocalStyle: draftStyle,
        deviceVoiceName: draftDeviceVoice,
        pitch: draftPitch,
        speechRate: draftRate,
        samplePhrase:
          draftSample.trim() || 'Good evening. My custom voice is calibrated and at your service.',
      };
      if (editingVoiceId) {
        await onUpdateVoice(editingVoiceId, payload);
        onNotify(`Updated custom voice "${payload.name}".`);
      } else {
        await onCreateVoice(payload);
        onNotify(`Created and activated "${payload.name}".`);
      }
      onCloseCreatorModal();
      resetCreatorDraft();
    } finally {
      setIsSavingVoice(false);
    }
  };

  const activeVoiceSummary = useMemo(() => {
    if (settings.activeCustomVoiceName) {
      return `${settings.activeCustomVoiceName} · ${
        settings.voiceEngine === 'neural_tts' ? 'Neural Studio' : 'Browser Voice'
      }`;
    }
    return settings.voiceEngine === 'neural_tts'
      ? `${settings.geminiVoicePersona} · Neural Studio`
      : `${settings.deviceVoiceName || 'Default System Voice'} · Browser`;
  }, [settings]);

  return (
    <div className="flex h-full flex-col gap-6 overflow-y-auto pr-1">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#24324A] pb-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Voice Studio &amp; Manner
          </h1>
          <p className="mt-1 text-sm text-[#94A3B8]">
            Active voice: <span className="text-[#E5C07B]">{activeVoiceSummary}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onSpeakGreeting}
            className="inline-flex items-center gap-2 rounded-lg border border-[#24324A] bg-[#101724] px-3.5 py-2 text-xs font-medium text-[#F1F5F9] transition-colors hover:border-[#E5C07B]/60 hover:bg-[#161F30] whitespace-nowrap shrink-0"
          >
            <Volume2 className="h-4 w-4 text-[#E5C07B]" />
            <span>Speak Greeting</span>
          </button>
          <button
            type="button"
            onClick={() => setConfirmResetOpen(true)}
            className="inline-flex items-center gap-2 rounded-lg border border-[#24324A] bg-[#101724] px-3.5 py-2 text-xs font-medium text-[#94A3B8] transition-colors hover:text-[#FB7185] whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Reset Chat</span>
          </button>
          <button
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center gap-2 rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span>New Custom Voice</span>
          </button>
        </div>
      </div>

      {/* Saved Custom Voices Library */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Saved Voice Profiles ({voiceProfiles.length})
          </h2>
        </div>

        {voiceProfiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-[#24324A] bg-[#101724] p-8 text-center">
            <p className="text-sm font-medium text-[#F1F5F9]">No custom voices saved yet</p>
            <p className="mt-1 max-w-md text-xs text-[#94A3B8]">
              Create your own signature voice with neural timbre, style direction, pitch, and
              spoken test phrases.
            </p>
            <button
              type="button"
              onClick={openCreateModal}
              className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
            >
              <Plus className="h-4 w-4" />
              <span>Create First Voice</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {voiceProfiles.map((vp) => {
              const isActive = settings.activeCustomVoiceId === vp.id;
              const styleLabel =
                VOCAL_STYLES.find((s) => s.id === vp.vocalStyle)?.label ?? vp.vocalStyle;
              return (
                <article
                  key={vp.id}
                  className={`flex flex-col justify-between rounded-xl border p-4 transition-colors ${
                    isActive
                      ? 'border-[#E5C07B] bg-[#161F30]'
                      : 'border-[#24324A] bg-[#101724]'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <h3 className="font-display text-base font-semibold text-[#F1F5F9] truncate">
                          {vp.name}
                        </h3>
                        <p className="mt-0.5 text-xs text-[#94A3B8]">
                          {vp.engineMode === 'neural_tts'
                            ? `Neural · ${vp.geminiPersona} · ${styleLabel}`
                            : `Browser · ${vp.deviceVoiceName || 'System Voice'} · ${vp.pitch.toFixed(1)}x`}
                        </p>
                      </div>
                      {isActive && (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#E5C07B] whitespace-nowrap">
                          <Check className="h-3.5 w-3.5" />
                          Active
                        </span>
                      )}
                    </div>
                    <p className="mt-2.5 text-xs italic leading-relaxed text-[#94A3B8]">
                      &ldquo;{vp.samplePhrase}&rdquo;
                    </p>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#24324A] pt-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          handlePreviewVoice(vp.id, vp.samplePhrase, {
                            voiceEngine: vp.engineMode,
                            geminiVoicePersona: vp.geminiPersona,
                            vocalStyle: vp.vocalStyle,
                            deviceVoiceName: vp.deviceVoiceName,
                            devicePitch: vp.pitch,
                            deviceSpeechRate: vp.speechRate,
                          })
                        }
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B]/60"
                      >
                        {previewingId === vp.id ? (
                          <Square className="h-3.5 w-3.5 text-[#34D399]" />
                        ) : (
                          <Play className="h-3.5 w-3.5 text-[#E5C07B]" />
                        )}
                        <span>{previewingId === vp.id ? 'Stop' : 'Preview'}</span>
                      </button>

                      {!isActive && (
                        <button
                          type="button"
                          onClick={() => onActivateVoice(vp.id)}
                          className="rounded-lg bg-[#E5C07B]/15 px-3 py-1.5 text-xs font-semibold text-[#E5C07B] hover:bg-[#E5C07B]/25"
                        >
                          Use Voice
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openEditModal(vp)}
                        aria-label={`Edit ${vp.name}`}
                        className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#080C14] hover:text-[#F1F5F9]"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteVoice(vp.id)}
                        aria-label={`Delete ${vp.name}`}
                        className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#080C14] hover:text-[#FB7185]"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Quick Studio Calibration */}
      <section className="grid grid-cols-1 gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-5 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            How PRIME Addresses You
          </h2>
          <p className="mt-1 text-xs text-[#94A3B8]">
            Used across spoken greetings, daily briefings, and conversation.
          </p>
          <div className="mt-3 flex gap-2">
            <input
              type="text"
              value={preferredTitleInput}
              onChange={(ev) => setPreferredTitleInput(ev.target.value)}
              placeholder="sir, ma'am, or your name"
              className="flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
            />
            <button
              type="button"
              onClick={() => {
                onUpdateSettings({preferredTitle: preferredTitleInput.trim() || 'sir'});
                onNotify('Updated preferred title.');
              }}
              className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B]"
            >
              Save
            </button>
          </div>
        </div>

        <div>
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Neural Persona &amp; Delivery
          </h2>
          <p className="mt-1 text-xs text-[#94A3B8]">
            Instant switch between studio voice models and cadence.
          </p>
          <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
            <select
              value={settings.geminiVoicePersona}
              onChange={(ev) =>
                onUpdateSettings({
                  voiceEngine: 'neural_tts',
                  geminiVoicePersona: ev.target.value as GeminiVoicePersona,
                  activeCustomVoiceId: null,
                  activeCustomVoiceName: null,
                })
              }
              className="rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
            >
              {GEMINI_VOICE_PERSONAS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label} — {p.tone}
                </option>
              ))}
            </select>

            <select
              value={settings.vocalStyle}
              onChange={(ev) =>
                onUpdateSettings({
                  voiceEngine: 'neural_tts',
                  vocalStyle: ev.target.value as VocalStyleId,
                  activeCustomVoiceId: null,
                  activeCustomVoiceName: null,
                })
              }
              className="rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
            >
              {VOCAL_STYLES.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="lg:col-span-2 border-t border-[#24324A] pt-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                Voice Design Prompt &amp; Emotional Timbre
              </h2>
              <p className="mt-0.5 text-xs text-[#94A3B8]">
                Describe desired tone, accent, warmth, and pacing (e.g. &ldquo;Warm late-night radio host, subtle smile, calm reassuring rhythm&rdquo;).
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                handlePreviewVoice(
                  'voice_design_preview',
                  'Good evening. Notice how naturally my pacing and emotional warmth adapt to what we are discussing.',
                  {voiceDesignPrompt: voiceDesignInput.trim()},
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
            >
              {previewingId === 'voice_design_preview' ? (
                <Square className="h-3.5 w-3.5 text-[#34D399]" />
              ) : (
                <Play className="h-3.5 w-3.5 text-[#E5C07B]" />
              )}
              <span>{previewingId === 'voice_design_preview' ? 'Stop' : 'Audition Prompt'}</span>
            </button>
          </div>
          <div className="mt-2.5 flex flex-col gap-2 sm:flex-row">
            <input
              type="text"
              value={voiceDesignInput}
              onChange={(ev) => setVoiceDesignInput(ev.target.value)}
              placeholder="e.g. Warm charismatic mentor, subtle expressive pauses, calm confident phrasing"
              className="flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <button
              type="button"
              onClick={() => {
                void onUpdateSettings({voiceDesignPrompt: voiceDesignInput.trim()});
                onNotify('Saved Voice Design timbre direction.');
              }}
              className="rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] whitespace-nowrap shrink-0"
            >
              Apply Timbre
            </button>
          </div>
        </div>
      </section>

      {/* Manner Profile */}
      <section className="flex flex-col gap-3">
        <h2 className="font-display text-base font-semibold text-[#F1F5F9]">Manner &amp; Etiquette</h2>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          {MANNER_PROFILES.map((profile) => {
            const active = settings.mannerProfile === profile.id;
            return (
              <button
                key={profile.id}
                type="button"
                onClick={() => onUpdateSettings({mannerProfile: profile.id})}
                className={`flex flex-col justify-between rounded-xl border p-4 text-left transition-colors ${
                  active
                    ? 'border-[#E5C07B] bg-[#161F30]'
                    : 'border-[#24324A] bg-[#101724] hover:bg-[#161F30]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display text-sm font-semibold text-[#F1F5F9]">
                      {profile.title}
                    </h3>
                    {active && <Check className="h-4 w-4 text-[#E5C07B]" />}
                  </div>
                  <p className="mt-1 text-xs text-[#94A3B8]">{profile.subtitle}</p>
                </div>
                <p className="mt-3 text-xs italic text-[#E5C07B]/90">
                  &ldquo;{profile.sampleQuote}&rdquo;
                </p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Intelligence & Speech Toggles */}
      <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
        <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
          Cognition &amp; Behavior
        </h2>
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">Auto-speak greeting</p>
              <p className="text-xs text-[#94A3B8]">Deliver a spoken time-of-day welcome on launch</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoSpeakGreeting}
              onChange={(ev) => onUpdateSettings({autoSpeakGreeting: ev.target.checked})}
              className="h-4 w-4 accent-[#E5C07B]"
            />
          </label>

          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">Auto-speak replies</p>
              <p className="text-xs text-[#94A3B8]">Read PRIME&apos;s responses aloud automatically</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoSpeakReplies}
              onChange={(ev) => onUpdateSettings({autoSpeakReplies: ev.target.checked})}
              className="h-4 w-4 accent-[#E5C07B]"
            />
          </label>

          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">Live Web Search grounding</p>
              <p className="text-xs text-[#94A3B8]">Verify current facts with cited sources</p>
            </div>
            <input
              type="checkbox"
              checked={settings.webSearchEnabled}
              onChange={(ev) => onUpdateSettings({webSearchEnabled: ev.target.checked})}
              className="h-4 w-4 accent-[#E5C07B]"
            />
          </label>

          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">Human Brain Reflection trace</p>
              <p className="text-xs text-[#94A3B8]">Show expandable intent &amp; empathy notes</p>
            </div>
            <input
              type="checkbox"
              checked={settings.showReasoningTrace}
              onChange={(ev) => onUpdateSettings({showReasoningTrace: ev.target.checked})}
              className="h-4 w-4 accent-[#E5C07B]"
            />
          </label>

          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">Continuous Auto-Learning</p>
              <p className="text-xs text-[#94A3B8]">
                Automatically extract preferences, workflow rules, and durable facts from chats
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoLearnEnabled}
              onChange={(ev) => onUpdateSettings({autoLearnEnabled: ev.target.checked})}
              className="h-4 w-4 accent-[#E5C07B]"
            />
          </label>

          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">Passive Habit Observer</p>
              <p className="text-xs text-[#94A3B8]">
                Silently adapt to your routines, voice choices, and content style
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.passiveLearnEnabled}
              onChange={(ev) => onUpdateSettings({passiveLearnEnabled: ev.target.checked})}
              className="h-4 w-4 accent-[#38BDF8]"
            />
          </label>

          <label className="flex items-center justify-between gap-4 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3 cursor-pointer md:col-span-2">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">
                Emotionally Intelligent Expressive Voice
              </p>
              <p className="text-xs text-[#94A3B8]">
                Dynamically detects emotional intent (Empathetic, Excited, Reassuring, Focused) and adapts spoken pacing &amp; delivery
              </p>
            </div>
            <input
              type="checkbox"
              checked={settings.expressiveVoiceMode !== false}
              onChange={(ev) => onUpdateSettings({expressiveVoiceMode: ev.target.checked})}
              className="h-4 w-4 accent-[#34D399]"
            />
          </label>
        </div>
      </section>

      {/* Custom Voice Creator Modal */}
      {creatorModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
        >
          <form
            onSubmit={handleSaveCustomVoice}
            className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-xl border border-[#24324A] bg-[#101724] p-6"
          >
            <div className="flex items-center justify-between border-b border-[#24324A] pb-3">
              <div>
                <h2 className="font-display text-lg font-semibold text-[#F1F5F9]">
                  {editingVoiceId ? 'Edit Custom Voice' : 'Custom Voice Creator'}
                </h2>
                <p className="text-xs text-[#94A3B8]">
                  Design, preview live, and save a custom speaking voice for PRIME.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  stopAllSpeech();
                  setPreviewingId(null);
                  onCloseCreatorModal();
                }}
                aria-label="Close voice creator"
                className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 flex flex-col gap-4">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                  Voice Name
                </label>
                <input
                  type="text"
                  required
                  value={draftName}
                  onChange={(ev) => setDraftName(ev.target.value)}
                  placeholder="e.g. Midnight Concierge"
                  className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                  Voice Engine
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setDraftEngine('neural_tts')}
                    className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                      draftEngine === 'neural_tts'
                        ? 'border-[#E5C07B] bg-[#161F30] text-[#E5C07B]'
                        : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                    }`}
                  >
                    Gemini Neural TTS
                  </button>
                  <button
                    type="button"
                    onClick={() => setDraftEngine('device_tts')}
                    className={`rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${
                      draftEngine === 'device_tts'
                        ? 'border-[#E5C07B] bg-[#161F30] text-[#E5C07B]'
                        : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                    }`}
                  >
                    Browser Voice
                  </button>
                </div>
              </div>

              {draftEngine === 'neural_tts' ? (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                      Base Persona
                    </label>
                    <select
                      value={draftPersona}
                      onChange={(ev) => setDraftPersona(ev.target.value as GeminiVoicePersona)}
                      className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                    >
                      {GEMINI_VOICE_PERSONAS.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.label} — {p.tone}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                      Vocal Style
                    </label>
                    <select
                      value={draftStyle}
                      onChange={(ev) => setDraftStyle(ev.target.value as VocalStyleId)}
                      className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                    >
                      {VOCAL_STYLES.map((st) => (
                        <option key={st.id} value={st.id}>
                          {st.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                      System Voice
                    </label>
                    <select
                      value={draftDeviceVoice}
                      onChange={(ev) => setDraftDeviceVoice(ev.target.value)}
                      className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                    >
                      {browserVoices.length === 0 ? (
                        <option value="">Default Browser Voice</option>
                      ) : (
                        browserVoices.map((v) => (
                          <option key={v.name} value={v.name}>
                            {v.name} ({v.lang})
                          </option>
                        ))
                      )}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="mb-1 flex justify-between text-xs text-[#94A3B8] font-mono-tabular">
                        <span>Pitch</span>
                        <span>{draftPitch.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min={0.6}
                        max={1.4}
                        step={0.05}
                        value={draftPitch}
                        onChange={(ev) => setDraftPitch(Number(ev.target.value))}
                        className="w-full accent-[#E5C07B]"
                      />
                    </div>
                    <div>
                      <div className="mb-1 flex justify-between text-xs text-[#94A3B8] font-mono-tabular">
                        <span>Speed</span>
                        <span>{draftRate.toFixed(2)}x</span>
                      </div>
                      <input
                        type="range"
                        min={0.7}
                        max={1.4}
                        step={0.05}
                        value={draftRate}
                        onChange={(ev) => setDraftRate(Number(ev.target.value))}
                        className="w-full accent-[#E5C07B]"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#94A3B8]">
                  Audition Phrase
                </label>
                <textarea
                  rows={2}
                  value={draftSample}
                  onChange={(ev) => setDraftSample(ev.target.value)}
                  className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                />
              </div>
            </div>

            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[#24324A] pt-4">
              <button
                type="button"
                onClick={() =>
                  handlePreviewVoice('modal_preview', draftSample, {
                    voiceEngine: draftEngine,
                    geminiVoicePersona: draftPersona,
                    vocalStyle: draftStyle,
                    deviceVoiceName: draftDeviceVoice,
                    devicePitch: draftPitch,
                    deviceSpeechRate: draftRate,
                  })
                }
                className="inline-flex items-center gap-2 rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-xs font-semibold text-[#F1F5F9] hover:border-[#E5C07B]"
              >
                {previewingId === 'modal_preview' ? (
                  <Square className="h-3.5 w-3.5 text-[#34D399]" />
                ) : (
                  <Play className="h-3.5 w-3.5 text-[#E5C07B]" />
                )}
                <span>{previewingId === 'modal_preview' ? 'Stop Audition' : 'Audition Live'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    stopAllSpeech();
                    setPreviewingId(null);
                    onCloseCreatorModal();
                  }}
                  className="rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-2 text-xs font-medium text-[#94A3B8] hover:text-[#F1F5F9]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingVoice}
                  className="rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40"
                >
                  {isSavingVoice ? 'Saving...' : 'Save & Activate'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Reset Chat Confirmation Modal */}
      {confirmResetOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        >
          <div className="w-full max-w-md rounded-xl border border-[#24324A] bg-[#101724] p-6">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Start a Fresh Conversation?
            </h3>
            <p className="mt-2 text-sm text-[#94A3B8]">
              This clears the active chat thread while keeping all saved memories, tasks, and custom
              voice profiles intact.
            </p>
            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmResetOpen(false)}
                className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-sm font-medium text-[#F1F5F9]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  await onResetChat();
                  setConfirmResetOpen(false);
                }}
                className="rounded-lg bg-[#E5C07B] px-4 py-2 text-sm font-semibold text-[#080C14]"
              >
                Reset Thread
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
