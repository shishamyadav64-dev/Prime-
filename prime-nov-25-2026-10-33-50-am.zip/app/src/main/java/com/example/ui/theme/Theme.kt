package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val PrimeColorScheme =
  darkColorScheme(
    primary = PrimeGold,
    onPrimary = PrimeObsidian,
    primaryContainer = PrimeCardElevated,
    onPrimaryContainer = PrimeGold,
    secondary = PrimeCyan,
    onSecondary = PrimeObsidian,
    secondaryContainer = PrimeCard,
    onSecondaryContainer = PrimeCyan,
    tertiary = PrimeMint,
    background = PrimeObsidian,
    onBackground = PrimeTextPrimary,
    surface = PrimeSurface,
    onSurface = PrimeTextPrimary,
    surfaceVariant = PrimeCard,
    onSurfaceVariant = PrimeTextSecondary,
    outline = PrimeBorder,
    error = PrimeRose,
    onError = PrimeObsidian,
  )

@Composable
fun PrimeTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = PrimeColorScheme,
    typography = Typography,
    content = content,
  )
}
