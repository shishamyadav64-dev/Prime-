import {useState} from 'react';
import {
  ArrowRight,
  BookmarkPlus,
  Brain,
  CheckCircle2,
  Eye,
  RefreshCw,
  Sparkles,
  Trash2,
} from 'lucide-react';
import {
  PRIME_SKILLS,
  type LearnedTopicResult,
  type PassiveObservation,
  type SkillCategory,
  type SkillDefinition,
} from '../types/prime.ts';

interface SkillsViewProps {
  autoLearnEnabled: boolean;
  passiveLearnEnabled: boolean;
  learnedCount: number;
  passiveObservations: PassiveObservation[];
  onToggleAutoLearn: (enabled: boolean) => Promise<void>;
  onTogglePassiveLearn: (enabled: boolean) => Promise<void>;
  onAutoLearnTopic: (topic: string, notes: string) => Promise<LearnedTopicResult>;
  onScanPassiveActivity: () => Promise<void>;
  onPromoteObservation: (id: string) => Promise<void>;
  onDismissObservation: (id: string) => Promise<void>;
  onLaunchSkill: (skill: SkillDefinition) => void;
  onNotify: (msg: string) => void;
}

const CATEGORIES: Array<{id: SkillCategory; label: string}> = [
  {id: 'all', label: 'All Skills'},
  {id: 'cognition', label: 'Human Brain'},
  {id: 'productivity', label: 'Executive'},
  {id: 'technical', label: 'Engineering'},
  {id: 'creative', label: 'Communication'},
];

export function SkillsView({
  autoLearnEnabled,
  passiveLearnEnabled,
  learnedCount,
  passiveObservations,
  onToggleAutoLearn,
  onTogglePassiveLearn,
  onAutoLearnTopic,
  onScanPassiveActivity,
  onPromoteObservation,
  onDismissObservation,
  onLaunchSkill,
  onNotify,
}: SkillsViewProps) {
  const [category, setCategory] = useState<SkillCategory>('all');
  const [studyTopic, setStudyTopic] = useState('');
  const [studyNotes, setStudyNotes] = useState('');
  const [isStudying, setIsStudying] = useState(false);
  const [isPromotingAll, setIsPromotingAll] = useState(false);
  const [isScanningPassive, setIsScanningPassive] = useState(false);
  const [latestResult, setLatestResult] = useState<LearnedTopicResult | null>(null);

  const filtered =
    category === 'all' ? PRIME_SKILLS : PRIME_SKILLS.filter((s) => s.category === category);

  const handleStudySubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const trimmed = studyTopic.trim();
    if (!trimmed || isStudying) return;
    setIsStudying(true);
    try {
      const result = await onAutoLearnTopic(trimmed, studyNotes.trim());
      setLatestResult(result);
      setStudyTopic('');
      setStudyNotes('');
      onNotify(
        result.learnedFacts.length > 0
          ? `Assimilated ${result.learnedFacts.length} new principle(s) into Memory Vault.`
          : 'Topic reviewed and verified against existing knowledge.',
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Auto-learn session failed.');
    } finally {
      setIsStudying(false);
    }
  };

  const handleScan = async () => {
    if (isScanningPassive) return;
    setIsScanningPassive(true);
    try {
      await onScanPassiveActivity();
      onNotify('Passive behavioral scan complete.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Passive scan failed.');
    } finally {
      setIsScanningPassive(false);
    }
  };

  return (
    <div className="flex h-full flex-col gap-5 overflow-y-auto pr-1">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#24324A] pb-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Multi-Skill Matrix &amp; Learners
          </h1>
          <p className="mt-1 text-sm text-[#94A3B8]">
            Manage Auto-Learner self-study, silent Passive Learning, and launch specialized PRIME
            disciplines.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-[#24324A] bg-[#101724] p-1">
          {CATEGORIES.map((cat) => {
            const active = category === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#161F30] text-[#E5C07B]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Auto-Learner & Passive Learner Row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Auto-Learner Self-Study Studio */}
        <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#24324A] pb-3">
            <div className="flex items-start gap-2.5">
              <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#24324A] bg-[#080C14]">
                <Brain className="h-4 w-4 text-[#E5C07B]" />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  Auto-Learner Engine
                </h2>
                <p className="mt-0.5 text-xs text-[#94A3B8] font-mono-tabular">
                  {autoLearnEnabled ? 'Active' : 'Paused'} · {learnedCount} rule
                  {learnedCount === 1 ? '' : 's'}
                </p>
              </div>
            </div>

            <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#F1F5F9]">
              <input
                type="checkbox"
                checked={autoLearnEnabled}
                onChange={(ev) => onToggleAutoLearn(ev.target.checked)}
                className="h-3.5 w-3.5 accent-[#E5C07B]"
              />
              <span>Auto-Learn</span>
            </label>
          </div>

          <form onSubmit={handleStudySubmit} className="mt-3.5 flex flex-col gap-2.5">
            <input
              type="text"
              value={studyTopic}
              onChange={(ev) => setStudyTopic(ev.target.value)}
              placeholder="Topic or skill to master..."
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <textarea
              rows={2}
              value={studyNotes}
              onChange={(ev) => setStudyNotes(ev.target.value)}
              placeholder="Optional rules or reference notes for PRIME..."
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <button
              type="submit"
              disabled={!studyTopic.trim() || isStudying}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:opacity-40"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{isStudying ? 'Studying...' : 'Auto-Learn Topic'}</span>
            </button>
          </form>

          {latestResult && (
            <div className="mt-3 rounded-lg border border-[#34D399]/35 bg-[#080C14] p-3">
              <p className="text-xs font-semibold text-[#34D399]">
                Learned: {latestResult.topic}
              </p>
              <p className="mt-1 text-xs leading-relaxed text-[#F1F5F9]">{latestResult.summary}</p>
              {latestResult.learnedFacts.length > 0 && (
                <ul className="mt-2 flex flex-col gap-1">
                  {latestResult.learnedFacts.map((fact) => (
                    <li key={fact} className="flex items-start gap-1.5 text-xs text-[#94A3B8]">
                      <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[#34D399]" />
                      <span>{fact}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </section>

        {/* Passive Learner Observer Panel */}
        <section className="flex flex-col rounded-xl border border-[#24324A] bg-[#101724] p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#24324A] pb-3">
            <div className="flex items-start gap-2.5">
              <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#24324A] bg-[#080C14]">
                <Eye className="h-4 w-4 text-[#38BDF8]" />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  Passive Learner
                </h2>
                <p className="mt-0.5 text-xs text-[#94A3B8] font-mono-tabular">
                  {passiveLearnEnabled ? 'Observing silently' : 'Paused'} ·{' '}
                  {passiveObservations.length} pattern{passiveObservations.length === 1 ? '' : 's'}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {passiveObservations.length > 0 && (
                <button
                  type="button"
                  disabled={isPromotingAll}
                  onClick={async () => {
                    setIsPromotingAll(true);
                    try {
                      for (const obs of passiveObservations) {
                        await onPromoteObservation(obs.id);
                      }
                      onNotify(`Saved all ${passiveObservations.length} suggested observations.`);
                    } finally {
                      setIsPromotingAll(false);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-2.5 py-1.5 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap"
                >
                  <BookmarkPlus className="h-3.5 w-3.5" />
                  <span>{isPromotingAll ? 'Saving...' : `Add All (${passiveObservations.length})`}</span>
                </button>
              )}
              <button
                type="button"
                disabled={isScanningPassive}
                onClick={handleScan}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-2.5 py-1.5 text-xs font-medium text-[#38BDF8] hover:border-[#38BDF8]/60 disabled:opacity-40"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                <span>{isScanningPassive ? 'Scanning...' : 'Scan Activity'}</span>
              </button>
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#F1F5F9]">
                <input
                  type="checkbox"
                  checked={passiveLearnEnabled}
                  onChange={(ev) => onTogglePassiveLearn(ev.target.checked)}
                  className="h-3.5 w-3.5 accent-[#38BDF8]"
                />
                <span>Observe</span>
              </label>
            </div>
          </div>

          <div className="mt-3.5 flex-1">
            {passiveObservations.length === 0 ? (
              <div className="flex h-full min-h-[132px] flex-col items-center justify-center rounded-lg border border-dashed border-[#24324A] bg-[#080C14] p-4 text-center">
                <p className="text-xs font-medium text-[#F1F5F9]">
                  Silently learning your habits
                </p>
                <p className="mt-1 text-xs text-[#94A3B8]">
                  Chat, schedule tasks, switch voices, or produce videos—PRIME automatically adapts
                  to your style and displays discovered patterns here.
                </p>
              </div>
            ) : (
              <div className="flex max-h-52 flex-col gap-2 overflow-y-auto pr-1">
                {passiveObservations.map((obs) => (
                  <div
                    key={obs.id}
                    className="flex items-start justify-between gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2.5 text-xs"
                  >
                    <div className="min-w-0">
                      <p className="font-mono-tabular text-[11px] text-[#38BDF8]">
                        {obs.signalSource} · {obs.confidence} · {obs.observationsCount}x
                      </p>
                      <p className="mt-0.5 text-[#F1F5F9]">{obs.pattern}</p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onPromoteObservation(obs.id)}
                        title="Save to Memory Vault"
                        aria-label="Promote observation to Memory Vault"
                        className="rounded p-1 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#E5C07B]"
                      >
                        <BookmarkPlus className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDismissObservation(obs.id)}
                        title="Dismiss observation"
                        aria-label="Dismiss observation"
                        className="rounded p-1 text-[#64748B] hover:bg-[#161F30] hover:text-[#FB7185]"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {filtered.map((skill) => (
          <button
            key={skill.id}
            type="button"
            onClick={() => onLaunchSkill(skill)}
            className="group flex flex-col justify-between rounded-xl border border-[#24324A] bg-[#101724] p-5 text-left transition-colors hover:border-[#E5C07B]/60 hover:bg-[#161F30]"
          >
            <div>
              <div className="flex items-center justify-between gap-3">
                <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
                  {skill.name}
                </h2>
                <ArrowRight className="h-4 w-4 shrink-0 text-[#64748B] transition-transform group-hover:translate-x-0.5 group-hover:text-[#E5C07B]" />
              </div>
              <p className="mt-1 text-xs text-[#94A3B8]">
                {CATEGORIES.find((c) => c.id === skill.category)?.label}
                {skill.requiresDeepBrain ? ' · Deep Reasoning' : ''}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-[#94A3B8]">{skill.summary}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
