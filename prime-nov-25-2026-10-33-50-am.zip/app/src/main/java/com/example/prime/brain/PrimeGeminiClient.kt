package com.example.prime.brain

import android.util.Base64
import com.example.BuildConfig
import com.example.prime.model.DeviceActionSuggestion
import com.example.prime.model.GroundingSource
import com.example.prime.model.PrimeMessage
import com.example.prime.model.PrimeSettings
import com.example.prime.model.ToolExecutionBadge
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class PrimeBrainOutcome(
  val replyText: String,
  val reasoningTrace: String?,
  val sources: List<GroundingSource>,
  val toolActions: List<ToolExecutionBadge>,
  val deviceAction: DeviceActionSuggestion?,
)

data class ToolCallOutcome(
  val responsePayload: JSONObject,
  val badge: ToolExecutionBadge? = null,
  val deviceAction: DeviceActionSuggestion? = null,
)

class PrimeGeminiClient {

  private val client =
    OkHttpClient.Builder()
      .connectTimeout(20, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .writeTimeout(30, TimeUnit.SECONDS)
      .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  fun hasValidApiKey(): Boolean {
    val key = BuildConfig.GEMINI_API_KEY.trim()
    return key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
  }

  suspend fun generateReply(
    userPrompt: String,
    attachedImageBytes: ByteArray?,
    attachedImageMime: String?,
    history: List<PrimeMessage>,
    settings: PrimeSettings,
    memories: List<String>,
    pendingTasks: List<String>,
    onToolCall: suspend (name: String, args: JSONObject) -> ToolCallOutcome,
  ): Result<PrimeBrainOutcome> =
    withContext(Dispatchers.IO) {
      runCatching {
        if (!hasValidApiKey()) {
          error(
            "GEMINI_API_KEY is not configured yet. Add your Gemini API key in Secrets or .env to enable full reasoning, while offline voice, tasks, memories, and math remain available."
          )
        }

        val systemText =
          PrimePersonality.buildSystemInstruction(
            settings = settings,
            memories = memories,
            pendingTasks = pendingTasks,
          )

        val contents = buildInitialContents(history, userPrompt, attachedImageBytes, attachedImageMime)
        val collectedBadges = mutableListOf<ToolExecutionBadge>()
        val collectedSources = mutableListOf<GroundingSource>()
        var suggestedDeviceAction: DeviceActionSuggestion? = null

        var includeSearch = settings.webSearchEnabled
        var modelId = settings.brainDepth.modelId
        var finalRawText = ""

        for (step in 0 until 4) {
          val requestBody =
            buildGenerateBody(
              systemText = systemText,
              contents = contents,
              includeSearch = includeSearch,
            )

          val responseJson =
            executeWithFallbacks(
              initialModel = modelId,
              body = requestBody,
              onModelFallback = { fallback -> modelId = fallback },
              retryWithoutSearch = {
                if (!includeSearch) null
                else {
                  includeSearch = false
                  buildGenerateBody(systemText = systemText, contents = contents, includeSearch = false)
                }
              },
            )

          val candidate = responseJson.optJSONArray("candidates")?.optJSONObject(0)
            ?: error("PRIME received an empty response from the reasoning engine.")

          extractGroundingSources(candidate, collectedSources)

          val modelContent = candidate.optJSONObject("content") ?: JSONObject()
          val parts = modelContent.optJSONArray("parts") ?: JSONArray()

          val functionCalls = mutableListOf<Pair<String, JSONObject>>()
          val textBuilder = StringBuilder()

          for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val fc = part.optJSONObject("functionCall")
            if (fc != null) {
              val fnName = fc.optString("name", "")
              val fnArgs = fc.optJSONObject("args") ?: JSONObject()
              if (fnName.isNotEmpty()) {
                functionCalls.add(fnName to fnArgs)
              }
            } else {
              val txt = part.optString("text", "")
              if (txt.isNotEmpty()) {
                if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                textBuilder.append(txt)
              }
            }
          }

          if (functionCalls.isEmpty()) {
            finalRawText = textBuilder.toString().trim()
            break
          }

          // Append model turn containing function calls
          contents.put(
            JSONObject().apply {
              put("role", "model")
              put("parts", parts)
            }
          )

          // Execute each local tool and return functionResponse parts
          val responseParts = JSONArray()
          for ((fnName, fnArgs) in functionCalls) {
            val outcome = onToolCall(fnName, fnArgs)
            outcome.badge?.let { collectedBadges.add(it) }
            outcome.deviceAction?.let { suggestedDeviceAction = it }

            responseParts.put(
              JSONObject().apply {
                put(
                  "functionResponse",
                  JSONObject().apply {
                    put("name", fnName)
                    put("response", outcome.responsePayload)
                  },
                )
              }
            )
          }

          contents.put(
            JSONObject().apply {
              put("role", "user")
              put("parts", responseParts)
            }
          )
        }

        if (finalRawText.isBlank()) {
          finalRawText =
            if (collectedBadges.isNotEmpty()) {
              "Done, ${settings.preferredTitle}. I have completed that for you."
            } else {
              "I apologize, ${settings.preferredTitle}, I could not form a complete reply just now."
            }
        }

        val (thought, reply) = PrimePersonality.extractThoughtAndReply(finalRawText)
        PrimeBrainOutcome(
          replyText = reply,
          reasoningTrace = thought,
          sources = collectedSources.distinctBy { it.uri },
          toolActions = collectedBadges,
          deviceAction = suggestedDeviceAction,
        )
      }
    }

  suspend fun synthesizeSpeechPcm(
    text: String,
    voiceName: String,
    vocalDirection: String = "",
  ): Result<ByteArray> =
    withContext(Dispatchers.IO) {
      runCatching {
        if (!hasValidApiKey()) error("No Gemini API key configured.")
        val cleanText = PrimePersonality.sanitizeForSpeech(text).take(1200)
        if (cleanText.isBlank()) error("Nothing to speak.")

        val ttsPrompt =
          if (vocalDirection.isNotBlank()) {
            "Say in a $vocalDirection voice: $cleanText"
          } else {
            cleanText
          }

        val body =
          JSONObject().apply {
            put(
              "contents",
              JSONArray().put(
                JSONObject().apply {
                  put("role", "user")
                  put("parts", JSONArray().put(JSONObject().put("text", ttsPrompt)))
                }
              ),
            )
            put(
              "generationConfig",
              JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put(
                  "speechConfig",
                  JSONObject().apply {
                    put(
                      "voiceConfig",
                      JSONObject().apply {
                        put(
                          "prebuiltVoiceConfig",
                          JSONObject().put("voiceName", voiceName),
                        )
                      },
                    )
                  },
                )
              },
            )
          }

        val response = postGenerateContent("gemini-2.5-flash-preview-tts", body)
        val parts =
          response
            .optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts") ?: error("No audio parts returned.")

        var audioBase64: String? = null
        for (i in 0 until parts.length()) {
          val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
          val data = inline.optString("data", "")
          if (data.isNotBlank()) {
            audioBase64 = data
            break
          }
        }

        val encoded = audioBase64 ?: error("Audio payload missing from TTS response.")
        Base64.decode(encoded, Base64.DEFAULT)
      }
    }

  private fun executeWithFallbacks(
    initialModel: String,
    body: JSONObject,
    onModelFallback: (String) -> Unit,
    retryWithoutSearch: () -> JSONObject?,
  ): JSONObject {
    val candidateModels =
      listOf(initialModel, "gemini-2.5-flash").distinct()
    var lastError: Throwable? = null

    for (model in candidateModels) {
      try {
        return postGenerateContent(model, body)
      } catch (ex: ApiHttpException) {
        lastError = ex
        // If combining Google Search with function declarations is rejected (400), retry without search
        if (ex.code == 400) {
          val fallbackBody = retryWithoutSearch()
          if (fallbackBody != null) {
            try {
              val res = postGenerateContent(model, fallbackBody)
              onModelFallback(model)
              return res
            } catch (inner: Throwable) {
              lastError = inner
            }
          }
        }
        // Try fallback model on 404 or unsupported model error
        if (ex.code != 404 && ex.code != 400) {
          throw ex
        }
      }
    }
    throw lastError ?: IOException("Unable to reach Gemini API.")
  }

  private fun postGenerateContent(model: String, body: JSONObject): JSONObject {
    val apiKey = BuildConfig.GEMINI_API_KEY.trim()
    val url =
      "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
    val req =
      Request.Builder()
        .url(url)
        .post(body.toString().toRequestBody(jsonMediaType))
        .build()

    client.newCall(req).execute().use { resp ->
      val raw = resp.body?.string().orEmpty()
      if (!resp.isSuccessful) {
        val message =
          runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
            ?: "HTTP ${resp.code}"
        throw ApiHttpException(resp.code, message)
      }
      return JSONObject(raw)
    }
  }

  private fun buildInitialContents(
    history: List<PrimeMessage>,
    userPrompt: String,
    attachedImageBytes: ByteArray?,
    attachedImageMime: String?,
  ): JSONArray {
    val contents = JSONArray()
    val recent = history.filter { !it.isError && it.text.isNotBlank() }.takeLast(14)
    for (msg in recent) {
      contents.put(
        JSONObject().apply {
          put("role", if (msg.isUser) "user" else "model")
          put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
        }
      )
    }

    val userParts = JSONArray()
    if (attachedImageBytes != null && attachedImageBytes.isNotEmpty()) {
      userParts.put(
        JSONObject().apply {
          put(
            "inlineData",
            JSONObject().apply {
              put("mimeType", attachedImageMime ?: "image/jpeg")
              put("data", Base64.encodeToString(attachedImageBytes, Base64.NO_WRAP))
            },
          )
        }
      )
    }
    userParts.put(JSONObject().put("text", userPrompt))

    contents.put(
      JSONObject().apply {
        put("role", "user")
        put("parts", userParts)
      }
    )
    return contents
  }

  private fun buildGenerateBody(
    systemText: String,
    contents: JSONArray,
    includeSearch: Boolean,
  ): JSONObject {
    return JSONObject().apply {
      put(
        "systemInstruction",
        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText))),
      )
      put("contents", contents)
      put("tools", buildToolsArray(includeSearch))
      put(
        "generationConfig",
        JSONObject().apply {
          put("temperature", 0.72)
          put("topP", 0.95)
        },
      )
    }
  }

  private fun buildToolsArray(includeSearch: Boolean): JSONArray {
    val declarations =
      JSONArray().apply {
        put(
          functionDecl(
            name = "remember_fact",
            description =
              "Save a personal fact, preference, name, habit, or goal about the user into PRIME's permanent memory vault.",
            properties =
              JSONObject().apply {
                put(
                  "category",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "Category such as Identity, Preference, Goal, Routine, or Note"),
                )
                put(
                  "fact",
                  JSONObject().put("type", "STRING").put("description", "Concise statement to remember"),
                )
              },
            required = listOf("category", "fact"),
          )
        )
        put(
          functionDecl(
            name = "create_task",
            description = "Add an actionable task or reminder to the user's PRIME agenda.",
            properties =
              JSONObject().apply {
                put("title", JSONObject().put("type", "STRING").put("description", "Clear task title"))
                put(
                  "priority",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "High, Normal, or Low"),
                )
                put(
                  "due_note",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "Optional timing or context note, e.g. 'Today 5 PM'"),
                )
              },
            required = listOf("title"),
          )
        )
        put(
          functionDecl(
            name = "complete_task",
            description = "Mark an existing pending task in the user's PRIME agenda as completed.",
            properties =
              JSONObject().apply {
                put(
                  "title_query",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "Keywords matching the task to mark complete"),
                )
              },
            required = listOf("title_query"),
          )
        )
        put(
          functionDecl(
            name = "evaluate_math",
            description =
              "Evaluate a mathematical expression deterministically. Supports +, -, *, /, %, ^, parentheses, sqrt(), abs(), sin(), cos(), tan(), log(), ln(), pi, e.",
            properties =
              JSONObject().apply {
                put(
                  "expression",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "Mathematical expression to evaluate, e.g. '(1250 * 1.07^5) - 1250'"),
                )
              },
            required = listOf("expression"),
          )
        )
        put(
          functionDecl(
            name = "prepare_device_action",
            description =
              "Prepare a one-tap Android launcher card for alarms, timers, email drafts, or sharing text.",
            properties =
              JSONObject().apply {
                put(
                  "action_type",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "One of: ALARM, TIMER, EMAIL, SHARE"),
                )
                put(
                  "label",
                  JSONObject()
                    .put("type", "STRING")
                    .put("description", "Short action button title"),
                )
                put(
                  "detail",
                  JSONObject()
                    .put("type", "STRING")
                    .put(
                      "description",
                      "Details such as '7:30 AM' for alarm, '15 minutes' for timer, or 'Subject: ...\nBody' for email",
                    ),
                )
              },
            required = listOf("action_type", "label", "detail"),
          )
        )
      }

    val tools = JSONArray()
    tools.put(JSONObject().put("functionDeclarations", declarations))
    if (includeSearch) {
      tools.put(JSONObject().put("googleSearch", JSONObject()))
    }
    return tools
  }

  private fun functionDecl(
    name: String,
    description: String,
    properties: JSONObject,
    required: List<String>,
  ): JSONObject {
    return JSONObject().apply {
      put("name", name)
      put("description", description)
      put(
        "parameters",
        JSONObject().apply {
          put("type", "OBJECT")
          put("properties", properties)
          put("required", JSONArray(required))
        },
      )
    }
  }

  private fun extractGroundingSources(
    candidate: JSONObject,
    out: MutableList<GroundingSource>,
  ) {
    val grounding = candidate.optJSONObject("groundingMetadata") ?: return
    val chunks = grounding.optJSONArray("groundingChunks") ?: return
    for (i in 0 until chunks.length()) {
      val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
      val uri = web.optString("uri", "")
      val title = web.optString("title", uri).ifBlank { uri }
      if (uri.isNotBlank()) {
        out.add(GroundingSource(title = title, uri = uri))
      }
    }
  }

  private class ApiHttpException(val code: Int, override val message: String) :
    IOException(message)
}
