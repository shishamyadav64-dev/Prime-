package com.example.prime.model

enum class MannerProfile(
  val title: String,
  val subtitle: String,
  val sampleQuote: String,
  val directive: String,
) {
  REFINED_GENTLEMAN(
    title = "Refined Gentleman",
    subtitle = "Poised, attentive butler etiquette with warm dry wit",
    sampleQuote = "Good evening. Allow me to organize that for you right away.",
    directive =
      "Speak with calm British-inspired butler poise, impeccable courtesy, understated warmth, and occasional subtle dry wit. Use gracious transitions like 'Allow me to...', 'Certainly,', 'If I may suggest,'.",
  ),
  WARM_COMPANION(
    title = "Warm Companion",
    subtitle = "Empathetic, human-first conversational warmth and encouragement",
    sampleQuote = "Hey! Take a breath—I've got your back and we'll sort this out together.",
    directive =
      "Speak like a deeply empathetic, attentive human confidant. Acknowledge feelings naturally, offer gentle encouragement, keep phrasing conversational, kind, and grounded.",
  ),
  EXECUTIVE_STRATEGIST(
    title = "Executive Strategist",
    subtitle = "Crisp, respectful, high-clarity chief-of-staff precision",
    sampleQuote = "Understood. Here is the priority breakdown and my recommended next move.",
    directive =
      "Speak like an elite human chief of staff: polite, composed, razor-sharp, structured, and respectful of time. Lead with the answer, then concise next steps.",
  ),
}

enum class VoiceEngineMode(val label: String, val description: String) {
  DEVICE_TTS("Instant Device Voice", "Zero-latency offline Android speech synthesis"),
  GEMINI_NEURAL_TTS("Gemini Neural Voice", "Studio-natural expressive voice (requires network)"),
}

enum class GeminiVoicePersona(val voiceId: String, val label: String, val tone: String) {
  CHARON("Charon", "Charon", "Composed, resonant, classic butler warmth"),
  FENRIR("Fenrir", "Fenrir", "Grounded, authoritative, steady cadence"),
  KORE("Kore", "Kore", "Clear, poised, articulate executive tone"),
  ZEPHYR("Zephyr", "Zephyr", "Warm, bright, approachable companion"),
  PUCK("Puck", "Puck", "Lively, witty, energetic conversationalist"),
}

enum class BrainDepth(val modelId: String, val label: String, val description: String) {
  HYDROGEN_FAST("gemini-4-hydrogen", "Adaptive Fast", "Swift everyday intelligence and conversation"),
  NEON_DEEP("gemini-4-neon", "Deep Reasoning", "Maximum analytical depth for coding, math & strategy"),
}

enum class VocalStylePreset(val label: String, val direction: String) {
  NATURAL("Natural", ""),
  REFINED_BUTLER("Refined Butler", "composed, polite British butler"),
  WARM_EMPATHETIC("Warm & Empathetic", "warm, gentle, reassuring"),
  CRISP_EXECUTIVE("Crisp Executive", "clear, confident, executive"),
  CALM_NARRATOR("Calm & Deep", "calm, unhurried, resonant"),
  LIVELY_WIT("Lively & Bright", "friendly, upbeat, expressive"),
}

data class DeviceVoiceOption(
  val name: String,
  val label: String,
  val localeTag: String,
)

enum class VoiceState {
  IDLE,
  LISTENING,
  THINKING,
  SPEAKING,
}

data class PrimeSettings(
  val preferredTitle: String = "Sir",
  val mannerProfile: MannerProfile = MannerProfile.REFINED_GENTLEMAN,
  val autoSpeakGreeting: Boolean = true,
  val autoSpeakReplies: Boolean = false,
  val voiceEngine: VoiceEngineMode = VoiceEngineMode.DEVICE_TTS,
  val geminiVoicePersona: GeminiVoicePersona = GeminiVoicePersona.CHARON,
  val vocalStyle: VocalStylePreset = VocalStylePreset.REFINED_BUTLER,
  val deviceLocaleTag: String = "en-GB",
  val deviceVoiceName: String = "",
  val devicePitch: Float = 0.96f,
  val deviceSpeechRate: Float = 1.0f,
  val activeCustomVoiceId: Long? = null,
  val activeCustomVoiceName: String? = null,
  val brainDepth: BrainDepth = BrainDepth.HYDROGEN_FAST,
  val webSearchEnabled: Boolean = true,
  val showReasoningTrace: Boolean = true,
)

data class GroundingSource(
  val title: String,
  val uri: String,
)

data class ToolExecutionBadge(
  val toolName: String,
  val summary: String,
)

data class DeviceActionSuggestion(
  val actionType: String, // "ALARM", "TIMER", "EMAIL", "SHARE"
  val label: String,
  val detail: String,
)

data class PrimeMessage(
  val id: Long = System.currentTimeMillis(),
  val isUser: Boolean,
  val text: String,
  val reasoningTrace: String? = null,
  val sources: List<GroundingSource> = emptyList(),
  val toolActions: List<ToolExecutionBadge> = emptyList(),
  val deviceAction: DeviceActionSuggestion? = null,
  val imageUriString: String? = null,
  val timestampMs: Long = System.currentTimeMillis(),
  val isError: Boolean = false,
)

enum class SkillCategory(val label: String) {
  ALL("All Skills"),
  COGNITION("Human Brain"),
  PRODUCTIVITY("Executive"),
  TECHNICAL("Engineering"),
  CREATIVE("Communication"),
}

data class SkillDefinition(
  val id: String,
  val name: String,
  val category: SkillCategory,
  val summary: String,
  val starterPrompt: String,
  val requiresDeepBrain: Boolean = false,
)

object PrimeSkillCatalog {
  val skills: List<SkillDefinition> =
    listOf(
      SkillDefinition(
        id = "daily_briefing",
        name = "Morning & Daily Briefing",
        category = SkillCategory.PRODUCTIVITY,
        summary = "Synthesizes your pending tasks, priorities, and today's key headlines.",
        starterPrompt =
          "Give me a concise, well-mannered daily briefing covering my open tasks, top focus recommendation, and notable world or tech headlines today.",
      ),
      SkillDefinition(
        id = "live_research",
        name = "Live Web Research",
        category = SkillCategory.COGNITION,
        summary = "Searches current web sources and delivers cited, verified answers.",
        starterPrompt = "Research the latest breakthroughs in ",
      ),
      SkillDefinition(
        id = "human_counsel",
        name = "Empathetic Decision Counsel",
        category = SkillCategory.COGNITION,
        summary = "Weighs pros, cons, emotional stakes, and long-term outcomes like a wise advisor.",
        starterPrompt = "Help me think carefully through this decision: ",
        requiresDeepBrain = true,
      ),
      SkillDefinition(
        id = "code_architect",
        name = "Code & Systems Architect",
        category = SkillCategory.TECHNICAL,
        summary = "Writes, debugs, and refactors Kotlin, Python, TypeScript, SQL, and architectures.",
        starterPrompt = "Design and write clean, production-grade code for ",
        requiresDeepBrain = true,
      ),
      SkillDefinition(
        id = "math_engineering",
        name = "Precision Math & Finance",
        category = SkillCategory.TECHNICAL,
        summary = "Evaluates equations, compound interest, physics, and unit conversions accurately.",
        starterPrompt = "Calculate and explain step by step: ",
      ),
      SkillDefinition(
        id = "task_steward",
        name = "Task & Reminder Steward",
        category = SkillCategory.PRODUCTIVITY,
        summary = "Creates, prioritizes, and completes tasks stored in your PRIME memory.",
        starterPrompt = "Add a high-priority task to ",
      ),
      SkillDefinition(
        id = "memory_vault",
        name = "Personal Memory Recall",
        category = SkillCategory.COGNITION,
        summary = "Learns your preferences, goals, and routines so every reply feels personal.",
        starterPrompt = "Remember that I ",
      ),
      SkillDefinition(
        id = "etiquette_coach",
        name = "Etiquette & Executive Writing",
        category = SkillCategory.CREATIVE,
        summary = "Drafts gracious emails, speeches, apologies, and diplomatic messages.",
        starterPrompt = "Draft a polite, articulate message to ",
      ),
      SkillDefinition(
        id = "language_tutor",
        name = "Multilingual Translator & Coach",
        category = SkillCategory.CREATIVE,
        summary = "Translates with cultural nuance, formality levels, and pronunciation guidance.",
        starterPrompt = "Translate naturally with cultural etiquette notes: ",
      ),
      SkillDefinition(
        id = "vision_inspector",
        name = "Visual & Document Intelligence",
        category = SkillCategory.TECHNICAL,
        summary = "Attach any photo, screenshot, code snippet, or receipt for instant analysis.",
        starterPrompt = "Analyze the attached image carefully and summarize key details.",
      ),
    )
}
