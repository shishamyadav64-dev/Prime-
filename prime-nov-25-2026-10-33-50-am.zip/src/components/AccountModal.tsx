import {useState} from 'react';
import type {User} from 'firebase/auth';
import {KeyRound, LogOut, ShieldCheck, UserCheck, UserPlus, X} from 'lucide-react';
import {PRIMARY_ADMIN_EMAIL, type AuthUserProfile} from '../types/prime.ts';

interface AccountModalProps {
  open: boolean;
  user: User | null;
  localUser: AuthUserProfile | null;
  isAdmin: boolean;
  isSigningIn: boolean;
  onSignInGoogle: () => Promise<void>;
  onLocalLogin: (email: string, password: string) => Promise<void>;
  onLocalRegister: (name: string, email: string, password: string) => Promise<void>;
  onSignOut: () => Promise<void>;
  onOpenAdminConsole: () => void;
  onClose: () => void;
}

export function AccountModal({
  open,
  user,
  localUser,
  isAdmin,
  isSigningIn,
  onSignInGoogle,
  onLocalLogin,
  onLocalRegister,
  onSignOut,
  onOpenAdminConsole,
  onClose,
}: AccountModalProps) {
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submittingLocal, setSubmittingLocal] = useState(false);

  if (!open) return null;

  const activeName = user?.displayName || localUser?.name || 'Signed-In User';
  const activeEmail = user?.email || localUser?.email || '';
  const isAuthenticated = Boolean(user || localUser);

  const handleLocalSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    setFormError(null);
    setSubmittingLocal(true);
    try {
      if (authTab === 'login') {
        await onLocalLogin(emailInput.trim(), passwordInput);
      } else {
        await onLocalRegister(nameInput.trim(), emailInput.trim(), passwordInput);
      }
      setPasswordInput('');
      onClose();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmittingLocal(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Account and Login"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
    >
      <div className="w-full max-w-md rounded-xl border border-[#24324A] bg-[#101724] p-6">
        <div className="flex items-start justify-between gap-4 border-b border-[#24324A] pb-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-[#F1F5F9]">
              PRIME Login &amp; Account
            </h2>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Sign in with your account or Google to personalize your workspace, YouTube uploads,
              and Admin access.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close account modal"
            className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {isAuthenticated ? (
          <div className="mt-4 flex flex-col gap-4">
            <div className="rounded-xl border border-[#24324A] bg-[#080C14] p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[#E5C07B]/50 bg-[#161F30] text-[#E5C07B]">
                  {isAdmin ? (
                    <ShieldCheck className="h-5 w-5" />
                  ) : (
                    <UserCheck className="h-5 w-5" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-[#F1F5F9]">{activeName}</p>
                  <p className="truncate text-xs text-[#94A3B8]">{activeEmail}</p>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between border-t border-[#24324A] pt-3 text-xs">
                <span className="text-[#94A3B8]">Session Provider</span>
                <span className="font-mono-tabular text-[#38BDF8]">
                  {user ? 'Google Verified' : 'Email Account'}
                </span>
              </div>

              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-[#94A3B8]">Access Role</span>
                <span className={isAdmin ? 'font-semibold text-[#E5C07B]' : 'text-[#34D399]'}>
                  {isAdmin ? 'Administrator (Full Control)' : 'Member Companion'}
                </span>
              </div>
            </div>

            {!user && (
              <button
                type="button"
                disabled={isSigningIn}
                onClick={async () => {
                  await onSignInGoogle();
                  onClose();
                }}
                className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-[#DADCE0] bg-white px-4 text-xs font-medium text-[#1F1F1F] transition-colors hover:bg-[#F8FAFC] disabled:opacity-50"
              >
                <span>
                  {isSigningIn ? 'Connecting Google...' : 'Also Connect Google / YouTube'}
                </span>
              </button>
            )}

            <div className="flex flex-wrap items-center justify-end gap-2.5">
              {isAdmin && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenAdminConsole();
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-3.5 py-2 text-xs font-semibold text-[#E5C07B] hover:bg-[#1E293E]"
                >
                  <ShieldCheck className="h-3.5 w-3.5" />
                  <span>Open Admin Console</span>
                </button>
              )}
              <button
                type="button"
                onClick={async () => {
                  await onSignOut();
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3.5 py-2 text-xs font-medium text-[#FB7185] hover:border-[#FB7185]"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="mt-4 flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-1 rounded-lg border border-[#24324A] bg-[#080C14] p-1">
              <button
                type="button"
                onClick={() => {
                  setAuthTab('login');
                  setFormError(null);
                }}
                className={`inline-flex items-center justify-center gap-1.5 rounded-md py-1.5 text-xs font-medium transition-colors ${
                  authTab === 'login' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
                }`}
              >
                <KeyRound className="h-3.5 w-3.5" />
                <span>Sign In</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthTab('register');
                  setFormError(null);
                }}
                className={`inline-flex items-center justify-center gap-1.5 rounded-md py-1.5 text-xs font-medium transition-colors ${
                  authTab === 'register' ? 'bg-[#161F30] text-[#E5C07B]' : 'text-[#94A3B8]'
                }`}
              >
                <UserPlus className="h-3.5 w-3.5" />
                <span>Create Account</span>
              </button>
            </div>

            <form onSubmit={handleLocalSubmit} className="flex flex-col gap-3">
              {authTab === 'register' && (
                <div>
                  <label className="mb-1 block text-xs text-[#94A3B8]">Display Name</label>
                  <input
                    type="text"
                    required
                    value={nameInput}
                    onChange={(ev) => setNameInput(ev.target.value)}
                    placeholder="Your name or title"
                    className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">Email Address</label>
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(ev) => setEmailInput(ev.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs text-[#94A3B8]">Password</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={passwordInput}
                  onChange={(ev) => setPasswordInput(ev.target.value)}
                  placeholder={authTab === 'register' ? 'At least 6 characters' : 'Enter password'}
                  className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                />
              </div>

              {formError && (
                <p className="rounded-lg border border-[#FB7185]/40 bg-[#FB7185]/10 px-3 py-2 text-xs text-[#FB7185]">
                  {formError}
                </p>
              )}

              <button
                type="submit"
                disabled={submittingLocal}
                className="inline-flex h-10 w-full items-center justify-center rounded-lg bg-[#E5C07B] px-4 text-sm font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:opacity-50"
              >
                {submittingLocal
                  ? authTab === 'login'
                    ? 'Signing in...'
                    : 'Creating account...'
                  : authTab === 'login'
                    ? 'Sign In'
                    : 'Create Account'}
              </button>
            </form>

            <div className="flex items-center gap-3 text-[11px] text-[#64748B]">
              <div className="h-px flex-1 bg-[#24324A]" />
              <span>or</span>
              <div className="h-px flex-1 bg-[#24324A]" />
            </div>

            <button
              type="button"
              disabled={isSigningIn}
              onClick={async () => {
                await onSignInGoogle();
                onClose();
              }}
              className="inline-flex h-11 w-full items-center justify-center gap-3 rounded-lg border border-[#DADCE0] bg-white px-4 text-sm font-medium text-[#1F1F1F] transition-colors hover:bg-[#F8FAFC] disabled:opacity-50"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                className="h-4 w-4 shrink-0"
              >
                <path
                  fill="#EA4335"
                  d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                />
                <path
                  fill="#4285F4"
                  d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                />
                <path
                  fill="#FBBC05"
                  d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                />
                <path
                  fill="#34A853"
                  d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                />
              </svg>
              <span>{isSigningIn ? 'Signing in...' : 'Continue with Google'}</span>
            </button>

            <p className="text-[11px] leading-relaxed text-[#64748B]">
              Google sign-in with <span className="text-[#94A3B8]">{PRIMARY_ADMIN_EMAIL}</span>{' '}
              also unlocks YouTube auto-publishing and Admin Console privileges.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
