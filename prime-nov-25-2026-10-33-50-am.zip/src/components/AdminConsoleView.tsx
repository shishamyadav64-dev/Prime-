import {useCallback, useEffect, useRef, useState} from 'react';
import {
  Download,
  Plus,
  RefreshCw,
  Shield,
  Trash2,
  Upload,
} from 'lucide-react';
import type {PrimeVaultSnapshot} from '../types/prime.ts';
import {PRIMARY_ADMIN_EMAIL} from '../types/prime.ts';
import {getFirebaseIdToken} from '../utils/youtubeAuth.ts';

interface AdminSummaryPayload {
  verifiedEmail: string;
  primaryAdminEmail: string;
  adminEmails: string[];
  storeBytes: number;
  apkAvailable: boolean;
  apkBytes: number;
  apkUpdatedAtMs: number | null;
  snapshot: PrimeVaultSnapshot;
}

interface AdminConsoleViewProps {
  onSnapshotUpdated: (snap: PrimeVaultSnapshot) => void;
  onNotify: (msg: string) => void;
}

export function AdminConsoleView({onSnapshotUpdated, onNotify}: AdminConsoleViewProps) {
  const [summary, setSummary] = useState<AdminSummaryPayload | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [pendingPurge, setPendingPurge] = useState<
    'completed_tasks' | 'memories' | 'messages' | null
  >(null);
  const [pendingRestorePayload, setPendingRestorePayload] =
    useState<Partial<PrimeVaultSnapshot> | null>(null);
  const restoreInputRef = useRef<HTMLInputElement | null>(null);

  const loadSummary = useCallback(async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const idToken = await getFirebaseIdToken();
      if (!idToken) {
        throw new Error('Please sign in with an administrator Google account.');
      }
      const res = await fetch('/api/prime/admin/summary', {
        headers: {Authorization: `Bearer ${idToken}`},
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Unable to verify admin privileges.');
      }
      setSummary(data as AdminSummaryPayload);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load admin summary.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSummary();
  }, [loadSummary]);

  const handleAddAdmin = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const trimmed = newAdminEmail.trim().toLowerCase();
    if (!trimmed || !trimmed.includes('@')) return;
    try {
      const idToken = await getFirebaseIdToken();
      const res = await fetch('/api/prime/admin/admins', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({email: trimmed}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not add admin.');
      setNewAdminEmail('');
      await loadSummary();
      onNotify(`Granted admin access to ${trimmed}.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to add admin email.');
    }
  };

  const handleRemoveAdmin = async (email: string) => {
    try {
      const idToken = await getFirebaseIdToken();
      const res = await fetch(`/api/prime/admin/admins/${encodeURIComponent(email)}`, {
        method: 'DELETE',
        headers: {Authorization: `Bearer ${idToken}`},
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not remove admin.');
      await loadSummary();
      onNotify(`Removed admin access for ${email}.`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Failed to remove admin email.');
    }
  };

  const handleExportBackup = () => {
    if (!summary) return;
    const blob = new Blob([JSON.stringify(summary.snapshot, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prime-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Exported PRIME workspace backup.');
  };

  const handleSelectRestoreFile = (ev: React.ChangeEvent<HTMLInputElement>) => {
    const file = ev.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result ?? '{}')) as Partial<PrimeVaultSnapshot>;
        setPendingRestorePayload(parsed);
      } catch {
        onNotify('Selected file is not valid JSON.');
      }
    };
    reader.readAsText(file);
    ev.target.value = '';
  };

  const executeRestore = async () => {
    if (!pendingRestorePayload) return;
    try {
      const idToken = await getFirebaseIdToken();
      const res = await fetch('/api/prime/admin/restore', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify(pendingRestorePayload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Restore failed.');
      onSnapshotUpdated(data.snapshot as PrimeVaultSnapshot);
      setPendingRestorePayload(null);
      await loadSummary();
      onNotify('Restored PRIME snapshot from backup.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Restore failed.');
    }
  };

  const executePurge = async () => {
    if (!pendingPurge) return;
    try {
      const idToken = await getFirebaseIdToken();
      const res = await fetch('/api/prime/admin/purge', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify({target: pendingPurge}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Purge failed.');
      onSnapshotUpdated(data.snapshot as PrimeVaultSnapshot);
      setPendingPurge(null);
      await loadSummary();
      onNotify('Maintenance operation completed.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Purge failed.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center rounded-xl border border-[#24324A] bg-[#101724] p-8 text-sm text-[#94A3B8]">
        Verifying administrator credentials...
      </div>
    );
  }

  if (errorMsg || !summary) {
    return (
      <div className="flex h-full flex-col items-center justify-center rounded-xl border border-[#FB7185]/40 bg-[#101724] p-8 text-center">
        <Shield className="h-7 w-7 text-[#FB7185]" />
        <h2 className="mt-3 font-display text-base font-semibold text-[#F1F5F9]">
          Administrator Verification Required
        </h2>
        <p className="mt-1 max-w-md text-xs text-[#94A3B8]">
          {errorMsg || `Sign in with ${PRIMARY_ADMIN_EMAIL} to unlock Admin Power.`}
        </p>
        <button
          type="button"
          onClick={loadSummary}
          className="mt-4 rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-xs font-medium text-[#F1F5F9]"
        >
          Retry Verification
        </button>
      </div>
    );
  }

  const snap = summary.snapshot;

  return (
    <div className="flex h-full flex-col gap-5 overflow-y-auto pr-1">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#24324A] pb-4">
        <div>
          <h1 className="flex items-center gap-2 font-display text-2xl font-semibold text-[#F1F5F9]">
            <Shield className="h-5 w-5 text-[#E5C07B]" />
            <span>Admin Console</span>
          </h1>
          <p className="mt-1 text-sm text-[#94A3B8]">
            Verified administrator: <span className="text-[#E5C07B]">{summary.verifiedEmail}</span>
          </p>
        </div>

        <button
          type="button"
          onClick={loadSummary}
          className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3.5 py-2 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B]/60"
        >
          <RefreshCw className="h-3.5 w-3.5 text-[#E5C07B]" />
          <span>Refresh</span>
        </button>
      </div>

      {/* Live Storage & Asset Metrics */}
      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <div className="rounded-xl border border-[#24324A] bg-[#101724] p-4">
          <p className="text-xs text-[#94A3B8]">Messages</p>
          <p className="mt-1 font-display text-2xl font-semibold text-[#F1F5F9] font-mono-tabular">
            {snap.messages.length}
          </p>
        </div>
        <div className="rounded-xl border border-[#24324A] bg-[#101724] p-4">
          <p className="text-xs text-[#94A3B8]">Saved Memories</p>
          <p className="mt-1 font-display text-2xl font-semibold text-[#F1F5F9] font-mono-tabular">
            {snap.memories.length}
          </p>
        </div>
        <div className="rounded-xl border border-[#24324A] bg-[#101724] p-4">
          <p className="text-xs text-[#94A3B8]">Tasks · Voices</p>
          <p className="mt-1 font-display text-2xl font-semibold text-[#F1F5F9] font-mono-tabular">
            {snap.tasks.length} · {snap.voiceProfiles.length}
          </p>
        </div>
        <div className="rounded-xl border border-[#24324A] bg-[#101724] p-4">
          <p className="text-xs text-[#94A3B8]">Vault Storage</p>
          <p className="mt-1 font-display text-2xl font-semibold text-[#E5C07B] font-mono-tabular">
            {(summary.storeBytes / 1024).toFixed(1)} KB
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        {/* Admin Access Governance */}
        <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
          <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
            Administrator Access List
          </h2>
          <p className="mt-1 text-xs text-[#94A3B8]">
            Google accounts verified on the server for full administrative control.
          </p>

          <form onSubmit={handleAddAdmin} className="mt-4 flex gap-2">
            <input
              type="email"
              value={newAdminEmail}
              onChange={(ev) => setNewAdminEmail(ev.target.value)}
              placeholder="Grant admin email..."
              className="flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <button
              type="submit"
              disabled={!newAdminEmail.trim()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3.5 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Add Admin</span>
            </button>
          </form>

          <div className="mt-4 flex flex-col gap-2">
            {summary.adminEmails.map((email) => {
              const isPrimary = email.toLowerCase() === summary.primaryAdminEmail.toLowerCase();
              return (
                <div
                  key={email}
                  className="flex items-center justify-between gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2.5 text-xs"
                >
                  <div className="min-w-0">
                    <p className="truncate font-medium text-[#F1F5F9]">{email}</p>
                    <p className="text-[#94A3B8]">
                      {isPrimary ? 'Primary Owner · Protected' : 'Secondary Admin'}
                    </p>
                  </div>
                  {!isPrimary && (
                    <button
                      type="button"
                      onClick={() => handleRemoveAdmin(email)}
                      aria-label={`Remove admin ${email}`}
                      className="rounded p-1.5 text-[#64748B] hover:text-[#FB7185]"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Backup, Restore, Maintenance & APK */}
        <div className="flex flex-col gap-5">
          <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Backup &amp; Restore
            </h2>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Download or restore the entire PRIME Vault (memories, tasks, custom voices, settings).
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleExportBackup}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3.5 py-2 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B]"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Export JSON Backup</span>
              </button>

              <input
                ref={restoreInputRef}
                type="file"
                accept="application/json,.json"
                onChange={handleSelectRestoreFile}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => restoreInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B]/60"
              >
                <Upload className="h-3.5 w-3.5 text-[#38BDF8]" />
                <span>Import Backup JSON</span>
              </button>
            </div>
          </section>

          <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
            <h2 className="font-display text-base font-semibold text-[#F1F5F9]">
              Android Build &amp; Maintenance
            </h2>
            <div className="mt-3 flex items-center justify-between gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2.5 text-xs">
              <div>
                <p className="font-medium text-[#F1F5F9]">Android Debug APK</p>
                <p className="text-[#94A3B8] font-mono-tabular">
                  {summary.apkAvailable
                    ? `${(summary.apkBytes / (1024 * 1024)).toFixed(2)} MB · Ready`
                    : 'Not built yet'}
                </p>
              </div>
              {summary.apkAvailable && (
                <a
                  href="/api/prime/android-apk"
                  download="PRIME-android-debug.apk"
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3 py-1.5 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download APK</span>
                </a>
              )}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setPendingPurge('completed_tasks')}
                className="rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#94A3B8] hover:text-[#F1F5F9]"
              >
                Purge Completed Tasks
              </button>
              <button
                type="button"
                onClick={() => setPendingPurge('messages')}
                className="rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#94A3B8] hover:text-[#FB7185]"
              >
                Reset Chat History
              </button>
              <button
                type="button"
                onClick={() => setPendingPurge('memories')}
                className="rounded-lg border border-[#FB7185]/40 bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#FB7185] hover:bg-[#FB7185]/10"
              >
                Purge Memory Vault
              </button>
            </div>
          </section>
        </div>
      </div>

      {/* Explicit Confirmation Modal for Purge */}
      {pendingPurge && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
        >
          <div className="w-full max-w-md rounded-xl border border-[#24324A] bg-[#101724] p-6">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Confirm Admin Maintenance
            </h3>
            <p className="mt-2 text-sm text-[#94A3B8]">
              {pendingPurge === 'completed_tasks'
                ? 'Remove all completed tasks from the Agenda?'
                : pendingPurge === 'messages'
                  ? 'Clear the conversation history and reset to a fresh greeting?'
                  : 'Permanently delete all saved facts in the Memory Vault?'}
            </p>
            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setPendingPurge(null)}
                className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-sm font-medium text-[#F1F5F9]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executePurge}
                className="rounded-lg bg-[#FB7185] px-4 py-2 text-sm font-semibold text-[#080C14]"
              >
                Confirm Purge
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Explicit Confirmation Modal for Backup Restore */}
      {pendingRestorePayload && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
        >
          <div className="w-full max-w-md rounded-xl border border-[#24324A] bg-[#101724] p-6">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Restore Workspace Snapshot?
            </h3>
            <p className="mt-2 text-sm text-[#94A3B8]">
              This will overwrite the current PRIME settings, memories, tasks, and custom voice
              profiles with the uploaded backup JSON.
            </p>
            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setPendingRestorePayload(null)}
                className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-sm font-medium text-[#F1F5F9]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={executeRestore}
                className="rounded-lg bg-[#E5C07B] px-4 py-2 text-sm font-semibold text-[#080C14]"
              >
                Restore Backup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
