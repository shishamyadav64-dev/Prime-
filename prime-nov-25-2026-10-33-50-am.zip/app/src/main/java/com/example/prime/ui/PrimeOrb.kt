package com.example.prime.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.prime.model.VoiceState
import com.example.ui.theme.PrimeBorder
import com.example.ui.theme.PrimeCard
import com.example.ui.theme.PrimeCyan
import com.example.ui.theme.PrimeGold
import com.example.ui.theme.PrimeMint
import com.example.ui.theme.PrimeTextPrimary
import com.example.ui.theme.PrimeTextSecondary

@Composable
fun PrimeCoreBanner(
  voiceState: VoiceState,
  audioLevel: Float,
  partialTranscript: String,
  preferredTitle: String,
  onOrbTap: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val statusHeadline =
    when (voiceState) {
      VoiceState.IDLE -> "At your service, ${preferredTitle.ifBlank { "friend" }}"
      VoiceState.LISTENING -> "Listening attentively..."
      VoiceState.THINKING -> "Reasoning through your request..."
      VoiceState.SPEAKING -> "Speaking — tap core to pause"
    }

  val statusSubtext =
    when {
      voiceState == VoiceState.LISTENING && partialTranscript.isNotBlank() -> "\"$partialTranscript\""
      voiceState == VoiceState.LISTENING -> "Speak naturally; I'll reply as soon as you pause."
      voiceState == VoiceState.THINKING -> "Weighing context, memory, and precision tools."
      voiceState == VoiceState.SPEAKING -> "Delivering spoken response with refined cadence."
      else -> "Tap the neural core to speak, or type below."
    }

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = PrimeCard,
    shape = MaterialTheme.shapes.large,
    tonalElevation = 2.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, PrimeBorder),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      PrimeNeuralOrb(
        voiceState = voiceState,
        audioLevel = audioLevel,
        onClick = onOrbTap,
        modifier = Modifier.size(62.dp),
      )

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = statusHeadline,
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.SemiBold,
          color = PrimeTextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = statusSubtext,
          style = MaterialTheme.typography.bodyMedium,
          color = if (voiceState == VoiceState.LISTENING) PrimeCyan else PrimeTextSecondary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun PrimeNeuralOrb(
  voiceState: VoiceState,
  audioLevel: Float,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val transition = rememberInfiniteTransition(label = "prime_orb")
  val rotation by
    transition.animateFloat(
      initialValue = 0f,
      targetValue = 360f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 5200, easing = LinearEasing),
          repeatMode = RepeatMode.Restart,
        ),
      label = "orb_rotation",
    )
  val breathe by
    transition.animateFloat(
      initialValue = 0.88f,
      targetValue = 1.06f,
      animationSpec =
        infiniteRepeatable(
          animation = tween(durationMillis = 2200),
          repeatMode = RepeatMode.Reverse,
        ),
      label = "orb_breathe",
    )

  val smoothLevel by
    animateFloatAsState(
      targetValue = audioLevel.coerceIn(0f, 1f),
      animationSpec = tween(durationMillis = 110),
      label = "orb_audio_level",
    )

  val primaryAccent by
    animateColorAsState(
      targetValue =
        when (voiceState) {
          VoiceState.IDLE -> PrimeGold
          VoiceState.LISTENING -> PrimeCyan
          VoiceState.THINKING -> PrimeGold
          VoiceState.SPEAKING -> PrimeMint
        },
      animationSpec = tween(durationMillis = 300),
      label = "orb_primary_color",
    )

  val secondaryAccent by
    animateColorAsState(
      targetValue =
        when (voiceState) {
          VoiceState.IDLE -> PrimeCyan
          VoiceState.LISTENING -> PrimeMint
          VoiceState.THINKING -> PrimeCyan
          VoiceState.SPEAKING -> PrimeGold
        },
      animationSpec = tween(durationMillis = 300),
      label = "orb_secondary_color",
    )

  Box(
    modifier =
      modifier
        .clip(CircleShape)
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onClick,
        ),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.matchParentSize()) {
      val radius = size.minDimension / 2f
      val center = Offset(size.width / 2f, size.height / 2f)

      val dynamicScale =
        when (voiceState) {
          VoiceState.IDLE -> breathe * 0.86f
          VoiceState.LISTENING -> 0.84f + (smoothLevel * 0.24f)
          VoiceState.THINKING -> 0.92f
          VoiceState.SPEAKING -> 0.86f + (smoothLevel * 0.22f)
        }

      // Ambient halo
      drawCircle(
        brush =
          Brush.radialGradient(
            colors = listOf(primaryAccent.copy(alpha = 0.34f), Color.Transparent),
            center = center,
            radius = radius,
          ),
        radius = radius * dynamicScale.coerceAtMost(1.05f),
        center = center,
      )

      // Outer rotating orbital arc
      val ringInset = radius * 0.16f
      val arcSize = Size(size.width - ringInset * 2f, size.height - ringInset * 2f)
      val arcTopLeft = Offset(ringInset, ringInset)
      val sweep = if (voiceState == VoiceState.THINKING) 110f else 85f
      val speedMultiplier = if (voiceState == VoiceState.THINKING) 2f else 1f
      val angle = (rotation * speedMultiplier) % 360f

      drawArc(
        color = primaryAccent.copy(alpha = 0.85f),
        startAngle = angle,
        sweepAngle = sweep,
        useCenter = false,
        topLeft = arcTopLeft,
        size = arcSize,
        style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round),
      )

      drawArc(
        color = secondaryAccent.copy(alpha = 0.7f),
        startAngle = angle + 180f,
        sweepAngle = sweep * 0.8f,
        useCenter = false,
        topLeft = arcTopLeft,
        size = arcSize,
        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
      )

      // Inner solid core
      drawCircle(
        brush =
          Brush.radialGradient(
            colors =
              listOf(
                primaryAccent.copy(alpha = 0.38f),
                secondaryAccent.copy(alpha = 0.16f),
              ),
            center = center,
            radius = radius * 0.62f,
          ),
        radius = radius * 0.60f,
        center = center,
      )
    }

    val icon =
      when (voiceState) {
        VoiceState.IDLE -> Icons.Rounded.Mic
        VoiceState.LISTENING -> Icons.Rounded.GraphicEq
        VoiceState.THINKING -> Icons.Rounded.Psychology
        VoiceState.SPEAKING -> Icons.Rounded.Stop
      }
    Icon(
      imageVector = icon,
      contentDescription = "PRIME Core",
      tint = primaryAccent,
      modifier = Modifier.size(22.dp),
    )
  }
}
