package com.example.prime.brain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Deterministic recursive-descent math evaluator so PRIME never hallucinates arithmetic.
 */
object PrimeMathTool {

  fun evaluate(expression: String): Result<Double> {
    return runCatching {
      val clean = expression.replace(",", "").replace("×", "*").replace("÷", "/").trim()
      require(clean.isNotEmpty()) { "Expression cannot be empty." }
      val parser = Parser(clean)
      val value = parser.parseExpression()
      require(!parser.hasNext()) { "Unexpected character '${parser.peek()}' at position ${parser.pos}" }
      require(!value.isNaN() && !value.isInfinite()) { "Math result is undefined or infinite." }
      value
    }
  }

  fun formatResult(value: Double): String {
    return if (value % 1.0 == 0.0 && abs(value) < 1e15) {
      value.toLong().toString()
    } else {
      String.format(java.util.Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
    }
  }

  private class Parser(private val input: String) {
    var pos: Int = 0
      private set

    fun hasNext(): Boolean {
      skipWhitespace()
      return pos < input.length
    }

    fun peek(): Char {
      skipWhitespace()
      return input[pos]
    }

    private fun skipWhitespace() {
      while (pos < input.length && input[pos].isWhitespace()) pos++
    }

    private fun eat(charToEat: Char): Boolean {
      skipWhitespace()
      if (pos < input.length && input[pos] == charToEat) {
        pos++
        return true
      }
      return false
    }

    fun parseExpression(): Double {
      var x = parseTerm()
      while (true) {
        when {
          eat('+') -> x += parseTerm()
          eat('-') -> x -= parseTerm()
          else -> return x
        }
      }
    }

    private fun parseTerm(): Double {
      var x = parsePower()
      while (true) {
        when {
          eat('*') -> x *= parsePower()
          eat('/') -> {
            val denom = parsePower()
            require(denom != 0.0) { "Division by zero." }
            x /= denom
          }
          eat('%') -> {
            val denom = parsePower()
            require(denom != 0.0) { "Modulo by zero." }
            x %= denom
          }
          else -> return x
        }
      }
    }

    private fun parsePower(): Double {
      val base = parseUnary()
      return if (eat('^')) base.pow(parsePower()) else base
    }

    private fun parseUnary(): Double {
      return when {
        eat('+') -> parseUnary()
        eat('-') -> -parseUnary()
        else -> parsePrimary()
      }
    }

    private fun parsePrimary(): Double {
      skipWhitespace()
      if (eat('(')) {
        val x = parseExpression()
        require(eat(')')) { "Missing closing parenthesis ')'" }
        return x
      }
      val start = pos
      if (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) {
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
        return input.substring(start, pos).toDouble()
      }
      if (pos < input.length && input[pos].isLetter()) {
        while (pos < input.length && input[pos].isLetter()) pos++
        val name = input.substring(start, pos).lowercase()
        if (name == "pi") return PI
        if (name == "e") return kotlin.math.E
        require(eat('(')) { "Unknown identifier '$name'" }
        val arg = parseExpression()
        require(eat(')')) { "Missing ')' after $name(...)" }
        return when (name) {
          "sqrt" -> {
            require(arg >= 0.0) { "Square root of negative number." }
            sqrt(arg)
          }
          "abs" -> abs(arg)
          "sin" -> sin(Math.toRadians(arg))
          "cos" -> cos(Math.toRadians(arg))
          "tan" -> tan(Math.toRadians(arg))
          "log" -> {
            require(arg > 0.0) { "Logarithm domain error." }
            log10(arg)
          }
          "ln" -> {
            require(arg > 0.0) { "Natural logarithm domain error." }
            ln(arg)
          }
          else -> throw IllegalArgumentException("Unsupported function '$name'")
        }
      }
      throw IllegalArgumentException("Unexpected token at position $pos")
    }
  }
}
