package com.example.prime.data

import com.example.prime.model.DeviceActionSuggestion
import com.example.prime.model.GroundingSource
import com.example.prime.model.PrimeMessage
import com.example.prime.model.ToolExecutionBadge
import org.json.JSONArray
import org.json.JSONObject

object PrimeSerializers {

  fun serializeSources(sources: List<GroundingSource>): String {
    if (sources.isEmpty()) return ""
    val array = JSONArray()
    sources.forEach { source ->
      array.put(
        JSONObject().apply {
          put("title", source.title)
          put("uri", source.uri)
        }
      )
    }
    return array.toString()
  }

  fun deserializeSources(raw: String): List<GroundingSource> {
    if (raw.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
          for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val uri = obj.optString("uri", "")
            if (uri.isNotBlank()) {
              add(
                GroundingSource(
                  title = obj.optString("title", uri).ifBlank { uri },
                  uri = uri,
                )
              )
            }
          }
        }
      }
      .getOrDefault(emptyList())
  }

  fun serializeToolActions(actions: List<ToolExecutionBadge>): String {
    if (actions.isEmpty()) return ""
    val array = JSONArray()
    actions.forEach { action ->
      array.put(
        JSONObject().apply {
          put("toolName", action.toolName)
          put("summary", action.summary)
        }
      )
    }
    return array.toString()
  }

  fun deserializeToolActions(raw: String): List<ToolExecutionBadge> {
    if (raw.isBlank()) return emptyList()
    return runCatching {
        val array = JSONArray(raw)
        buildList {
          for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val toolName = obj.optString("toolName", "")
            val summary = obj.optString("summary", "")
            if (toolName.isNotBlank()) {
              add(ToolExecutionBadge(toolName = toolName, summary = summary))
            }
          }
        }
      }
      .getOrDefault(emptyList())
  }

  fun serializeDeviceAction(action: DeviceActionSuggestion?): String {
    if (action == null) return ""
    return JSONObject()
      .apply {
        put("actionType", action.actionType)
        put("label", action.label)
        put("detail", action.detail)
      }
      .toString()
  }

  fun deserializeDeviceAction(raw: String): DeviceActionSuggestion? {
    if (raw.isBlank()) return null
    return runCatching {
        val obj = JSONObject(raw)
        val type = obj.optString("actionType", "")
        val label = obj.optString("label", "")
        val detail = obj.optString("detail", "")
        if (type.isBlank() || label.isBlank()) null
        else DeviceActionSuggestion(actionType = type, label = label, detail = detail)
      }
      .getOrNull()
  }

  fun ChatMessageEntity.toDomain(): PrimeMessage {
    return PrimeMessage(
      id = id,
      isUser = isUser,
      text = text,
      reasoningTrace = reasoningTrace,
      sources = deserializeSources(sourcesSerialized),
      toolActions = deserializeToolActions(toolActionsSerialized),
      deviceAction = deserializeDeviceAction(deviceActionSerialized),
      imageUriString = imageUriString,
      timestampMs = timestampMs,
      isError = isError,
    )
  }

  fun PrimeMessage.toEntity(): ChatMessageEntity {
    return ChatMessageEntity(
      isUser = isUser,
      text = text,
      reasoningTrace = reasoningTrace,
      sourcesSerialized = serializeSources(sources),
      toolActionsSerialized = serializeToolActions(toolActions),
      deviceActionSerialized = serializeDeviceAction(deviceAction),
      imageUriString = imageUriString,
      isError = isError,
      timestampMs = timestampMs,
    )
  }
}
