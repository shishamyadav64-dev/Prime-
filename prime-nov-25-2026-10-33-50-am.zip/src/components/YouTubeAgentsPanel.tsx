import {useEffect, useMemo, useRef, useState} from 'react';
import type {User} from 'firebase/auth';
import {
  Bot,
  CalendarClock,
  CheckCircle2,
  Download,
  ExternalLink,
  Film,
  Music,
  Play,
  Plus,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  Wand2,
  X,
} from 'lucide-react';
import {
  DEFAULT_YOUTUBE_AGENTS,
  DEFAULT_YOUTUBE_AGENT_SETTINGS,
  type PrimeSettings,
  type PrimeVaultSnapshot,
  type VideoFormat,
  type VideoProject,
  type YouTubeAgentConfig,
  type YouTubeAgentPostJob,
  type YouTubeAgentSettings,
  type YouTubePostStage,
  type YouTubeVideoTheme,
} from '../types/prime.ts';
import {
  buildFreeLocalVideoProject,
  runFreeLocalRecheck,
  scoutFreeTopicsFromNiche,
} from '../utils/freeVideoBuilder.ts';
import {renderProjectThumbnail, renderProjectVideo} from '../utils/videoRenderer.ts';
import {uploadVideoToYouTube, type YouTubeChannelInfo} from '../utils/youtubeApi.ts';
import {getCachedYouTubeToken} from '../utils/youtubeAuth.ts';

export interface RenderedJobMedia {
  videoBlob?: Blob;
  videoUrl?: string;
  thumbnailBlob?: Blob;
  thumbnailDataUrl?: string;
  durationSec?: number;
}

interface YouTubeAgentsPanelProps {
  settings: PrimeSettings;
  agents?: YouTubeAgentConfig[];
  queue?: YouTubeAgentPostJob[];
  agentSettings?: YouTubeAgentSettings;
  needsAuth: boolean;
  googleUser: User | null;
  channelInfo: YouTubeChannelInfo | null;
  onGoogleLogin: () => Promise<boolean>;
  onSnapshotUpdated?: (snapshot: PrimeVaultSnapshot) => void;
  onOpenProjectInEditor: (
    project: VideoProject,
    media?: RenderedJobMedia,
    theme?: YouTubeVideoTheme,
  ) => void;
  onNotify: (msg: string) => void;
}

const STAGE_LABELS: Record<YouTubePostStage, {label: string; colorClass: string}> = {
  queued: {label: 'Queued', colorClass: 'text-[#94A3B8]'},
  script_ready: {label: 'Script Ready', colorClass: 'text-[#38BDF8]'},
  rendered: {label: 'Video Rendered', colorClass: 'text-[#E5C07B]'},
  audited: {label: 'Ready to Post', colorClass: 'text-[#34D399]'},
  scheduled: {label: 'Scheduled', colorClass: 'text-[#38BDF8]'},
  published: {label: 'Published', colorClass: 'text-[#34D399]'},
  failed: {label: 'Needs Retry', colorClass: 'text-[#FB7185]'},
};

function toDateTimeLocalValue(ms: number): string {
  const d = new Date(ms);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function YouTubeAgentsPanel({
  settings,
  agents = DEFAULT_YOUTUBE_AGENTS,
  queue = [],
  agentSettings = DEFAULT_YOUTUBE_AGENT_SETTINGS,
  needsAuth,
  googleUser,
  channelInfo,
  onGoogleLogin,
  onSnapshotUpdated,
  onOpenProjectInEditor,
  onNotify,
}: YouTubeAgentsPanelProps) {
  const [quickTopic, setQuickTopic] = useState('');
  const [nicheInput, setNicheInput] = useState(agentSettings.niche);
  const [scoutCount, setScoutCount] = useState(4);
  const [stageFilter, setStageFilter] = useState<'all' | 'queued' | 'ready' | 'published' | 'failed'>(
    'all',
  );
  const [isPipelineRunning, setIsPipelineRunning] = useState(false);
  const [busyJobId, setBusyJobId] = useState<string | null>(null);
  const [activeRenderText, setActiveRenderText] = useState('');
  const [activeRenderPct, setActiveRenderPct] = useState(0);
  const [mediaByJob, setMediaByJob] = useState<Record<string, RenderedJobMedia>>({});
  const [previewJobId, setPreviewJobId] = useState<string | null>(null);
  const mediaUrlsRef = useRef<string[]>([]);

  useEffect(() => {
    setNicheInput(agentSettings.niche);
  }, [agentSettings.niche]);

  useEffect(() => {
    const urls = mediaUrlsRef.current;
    return () => {
      for (const u of urls) {
        URL.revokeObjectURL(u);
      }
    };
  }, []);

  const updateSettings = async (patch: Partial<YouTubeAgentSettings>) => {
    const res = await fetch('/api/prime/youtube/agent-settings', {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(patch),
    });
    if (res.ok) {
      onSnapshotUpdated?.((await res.json()) as PrimeVaultSnapshot);
    }
  };

  const updateAgent = async (id: string, patch: Partial<YouTubeAgentConfig>) => {
    const res = await fetch(`/api/prime/youtube/agents/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(patch),
    });
    if (res.ok) {
      onSnapshotUpdated?.((await res.json()) as PrimeVaultSnapshot);
    }
  };

  const patchJob = async (id: string, patch: Partial<YouTubeAgentPostJob>) => {
    const res = await fetch(`/api/prime/youtube/queue/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(patch),
    });
    if (res.ok) {
      const updated = (await res.json()) as PrimeVaultSnapshot;
      onSnapshotUpdated?.(updated);
      return updated;
    }
    return null;
  };

  const deleteJob = async (id: string) => {
    const res = await fetch(`/api/prime/youtube/queue/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (res.ok) {
      onSnapshotUpdated?.((await res.json()) as PrimeVaultSnapshot);
      onNotify('Removed job from YouTube Agent posting queue.');
    }
  };

  const handleAddSingleTopic = async () => {
    const clean = quickTopic.trim();
    if (!clean) {
      onNotify('Enter a video topic to add to the YouTube Agent queue.');
      return;
    }
    const res = await fetch('/api/prime/youtube/queue', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        topic: clean,
        title: clean,
        hook: clean.split(/\s+/).slice(0, 4).join(' ').toUpperCase(),
        format: agentSettings.defaultFormat,
        theme: agentSettings.defaultTheme,
        privacyStatus: agentSettings.defaultPrivacy,
        scheduledForMs: Date.now() + 2 * 60 * 60_000,
        autoPost: agentSettings.autoPublishConnected,
      }),
    });
    if (res.ok) {
      onSnapshotUpdated?.((await res.json()) as PrimeVaultSnapshot);
      setQuickTopic('');
      onNotify(`Queued "${clean}" for YouTube Agents.`);
    }
  };

  const runScoutAgent = async (): Promise<YouTubeAgentPostJob[]> => {
    const targetNiche = nicheInput.trim() || agentSettings.niche || 'Productivity & Tech';
    await updateSettings({niche: targetNiche});
    await updateAgent('yt_agent_strategist', {
      status: 'running',
      lastAction: `Scouting ${scoutCount} topics in "${targetNiche}"...`,
    });

    try {
      let scouted: Array<{topic: string; title: string; hook: string}> = [];
      if (agentSettings.engineMode === 'ai_producer') {
        const res = await fetch('/api/prime/youtube/agents/scout', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            niche: targetNiche,
            count: scoutCount,
            format: agentSettings.defaultFormat,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'AI Trend Scout failed.');
        }
        scouted = Array.isArray(data.items) ? data.items : [];
      } else {
        scouted = scoutFreeTopicsFromNiche(targetNiche, scoutCount, agentSettings.defaultFormat);
      }

      const intervalMs = Math.round((24 * 60 * 60_000) / Math.max(1, agentSettings.postsPerDay));
      const baseMs = Date.now() + 60 * 60_000;
      const payload = scouted.map((item, idx) => ({
        topic: item.topic,
        title: item.title,
        hook: item.hook,
        format: agentSettings.defaultFormat,
        theme: agentSettings.defaultTheme,
        privacyStatus: agentSettings.defaultPrivacy,
        scheduledForMs: baseMs + idx * intervalMs,
        autoPost: agentSettings.autoPublishConnected,
      }));

      const qRes = await fetch('/api/prime/youtube/queue', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({items: payload}),
      });
      const updatedSnap = (await qRes.json()) as PrimeVaultSnapshot;
      onSnapshotUpdated?.(updatedSnap);

      const scoutAgent = agents.find((a) => a.id === 'yt_agent_strategist');
      await updateAgent('yt_agent_strategist', {
        status: 'completed',
        lastAction: `Queued ${payload.length} videos (${agentSettings.defaultFormat}) for "${targetNiche}".`,
        tasksCompleted: (scoutAgent?.tasksCompleted ?? 0) + payload.length,
      });
      onNotify(`Trend Scout Agent queued ${payload.length} free video concepts.`);
      return (updatedSnap.youtubePostQueue ?? []).slice(0, payload.length);
    } catch (err) {
      await updateAgent('yt_agent_strategist', {
        status: 'error',
        lastAction: err instanceof Error ? err.message : 'Scout failed.',
      });
      throw err;
    }
  };

  const produceSingleJob = async (
    job: YouTubeAgentPostJob,
    options?: {allowPublish?: boolean},
  ): Promise<void> => {
    setBusyJobId(job.id);
    try {
      // 1. Script & Storyboard Agent
      let workingProject = job.project;
      if (!workingProject) {
        await updateAgent('yt_agent_scriptwriter', {
          status: 'running',
          lastAction: `Writing script & SEO for "${job.title}"...`,
        });

        if (agentSettings.engineMode === 'ai_producer') {
          const pkgRes = await fetch('/api/prime/video/generate-package', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({topic: job.topic, format: job.format}),
          });
          const pkgData = await pkgRes.json();
          if (!pkgRes.ok) {
            throw new Error(pkgData.error || 'AI script generation failed.');
          }
          workingProject = pkgData as VideoProject;
        } else {
          workingProject = buildFreeLocalVideoProject({
            topic: job.topic,
            format: job.format,
            theme: job.theme,
            customHook: job.hook,
            customTitle: job.title,
          });
        }

        await patchJob(job.id, {
          project: workingProject,
          title: workingProject.title,
          hook: workingProject.thumbnailHook,
          stage: 'script_ready',
          error: undefined,
        });
        const scriptAgent = agents.find((a) => a.id === 'yt_agent_scriptwriter');
        await updateAgent('yt_agent_scriptwriter', {
          status: 'completed',
          lastAction: `Scripted "${workingProject.title}" (${workingProject.scenes.length} scenes).`,
          tasksCompleted: (scriptAgent?.tasksCompleted ?? 0) + 1,
        });
      }

      // 2. HD Video & Thumbnail Producer Agent
      let existingMedia = mediaByJob[job.id];
      if (!existingMedia?.videoBlob || !existingMedia?.thumbnailBlob) {
        await updateAgent('yt_agent_producer', {
          status: 'running',
          lastAction: `Rendering thumbnail & ${job.format} video for "${workingProject.title}"...`,
        });
        const thumb = await renderProjectThumbnail(workingProject, job.theme);
        const rendered = await renderProjectVideo(
          workingProject,
          settings,
          (stage, pct) => {
            setActiveRenderText(`${workingProject?.title.slice(0, 28)}: ${stage}`);
            setActiveRenderPct(pct);
          },
          {
            useFreeSynthAudio: agentSettings.engineMode === 'free_local',
            ambientMusicEnabled: agentSettings.ambientMusicEnabled,
            theme: job.theme,
          },
        );
        mediaUrlsRef.current.push(rendered.videoUrl);

        workingProject = {
          ...workingProject,
          captions: rendered.syncedCaptions,
          srtText: rendered.syncedSrt,
        };

        existingMedia = {
          videoBlob: rendered.videoBlob,
          videoUrl: rendered.videoUrl,
          thumbnailBlob: thumb.thumbnailBlob,
          thumbnailDataUrl: thumb.thumbnailDataUrl,
          durationSec: rendered.durationSec,
        };
        setMediaByJob((prev) => ({...prev, [job.id]: existingMedia!}));

        await patchJob(job.id, {
          project: workingProject,
          stage: 'rendered',
          error: undefined,
        });

        const prodAgent = agents.find((a) => a.id === 'yt_agent_producer');
        await updateAgent('yt_agent_producer', {
          status: 'completed',
          lastAction: `Rendered ${rendered.durationSec.toFixed(1)}s WebM + JPEG thumbnail.`,
          tasksCompleted: (prodAgent?.tasksCompleted ?? 0) + 1,
        });
      }

      // 3. SEO Audit & Publish Manager Agent
      if (agentSettings.autoAuditBeforePost && !workingProject.recheckReport) {
        await updateAgent('yt_agent_publisher', {
          status: 'running',
          lastAction: `Auditing SEO & captions for "${workingProject.title}"...`,
        });
        let report;
        if (agentSettings.engineMode === 'ai_producer') {
          const auditRes = await fetch('/api/prime/video/recheck', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(workingProject),
          });
          report = auditRes.ok ? await auditRes.json() : runFreeLocalRecheck(workingProject);
        } else {
          report = runFreeLocalRecheck(workingProject);
        }

        workingProject = {
          ...workingProject,
          title: report.improvedTitle || workingProject.title,
          description: report.improvedDescription || workingProject.description,
          recheckReport: report,
        };

        await patchJob(job.id, {
          project: workingProject,
          title: workingProject.title,
          stage: 'audited',
        });
      } else {
        await patchJob(job.id, {stage: 'audited'});
      }

      // 4. Optional Direct Auto-Publish to Connected YouTube Channel
      const token = getCachedYouTubeToken();
      if (options?.allowPublish && token && existingMedia?.videoBlob) {
        await updateAgent('yt_agent_publisher', {
          status: 'running',
          lastAction: `Uploading "${workingProject.title}" to YouTube...`,
        });
        const uploaded = await uploadVideoToYouTube({
          accessToken: token,
          videoBlob: existingMedia.videoBlob,
          title: workingProject.title,
          description: workingProject.description,
          tags: workingProject.tags,
          privacyStatus: job.privacyStatus,
          srtText: workingProject.srtText,
          thumbnailBlob: existingMedia.thumbnailBlob,
        });
        await patchJob(job.id, {
          stage: 'published',
          watchUrl: uploaded.watchUrl,
          videoId: uploaded.videoId,
          error: undefined,
        });
        const pubAgent = agents.find((a) => a.id === 'yt_agent_publisher');
        await updateAgent('yt_agent_publisher', {
          status: 'completed',
          lastAction: `Published "${workingProject.title}" to YouTube.`,
          tasksCompleted: (pubAgent?.tasksCompleted ?? 0) + 1,
        });
      } else {
        const pubAgent = agents.find((a) => a.id === 'yt_agent_publisher');
        await updateAgent('yt_agent_publisher', {
          status: 'completed',
          lastAction: `Prepared & audited "${workingProject.title}" (ready to post or download).`,
          tasksCompleted: (pubAgent?.tasksCompleted ?? 0) + 1,
        });
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'YouTube agent execution failed.';
      await patchJob(job.id, {stage: 'failed', error: errMsg});
      throw err;
    } finally {
      setBusyJobId(null);
      setActiveRenderText('');
      setActiveRenderPct(0);
    }
  };

  const handleRunFullAgentTeam = async () => {
    if (isPipelineRunning) return;
    setIsPipelineRunning(true);
    try {
      let pendingJobs = queue.filter((j) => j.stage !== 'published' && j.stage !== 'audited');
      if (pendingJobs.length === 0) {
        pendingJobs = await runScoutAgent();
      }
      let producedCount = 0;
      for (const job of pendingJobs.slice(0, 4)) {
        await produceSingleJob(job, {
          allowPublish: agentSettings.autoPublishConnected && job.autoPost,
        });
        producedCount += 1;
      }
      onNotify(
        `YouTube Agent Team completed ${producedCount} video production run(s) — completely free!`,
      );
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'YouTube Agent pipeline paused on error.');
    } finally {
      setIsPipelineRunning(false);
    }
  };

  const handlePublishSingleJob = async (job: YouTubeAgentPostJob) => {
    let token = getCachedYouTubeToken();
    if (!token || needsAuth) {
      const ok = await onGoogleLogin();
      if (!ok) return;
      token = getCachedYouTubeToken();
    }
    if (!token) {
      onNotify('Connect Google YouTube channel first to publish directly.');
      return;
    }
    setBusyJobId(job.id);
    try {
      let media = mediaByJob[job.id];
      if (!media?.videoBlob || !job.project) {
        await produceSingleJob(job, {allowPublish: false});
        media = mediaByJob[job.id];
      }
      const activeJob = job;
      const proj = activeJob.project;
      const activeMedia = media;
      if (!proj || !activeMedia?.videoBlob) {
        onNotify('Video finished rendering — click Post to YouTube again to upload.');
        return;
      }
      const result = await uploadVideoToYouTube({
        accessToken: token,
        videoBlob: activeMedia.videoBlob,
        title: activeJob.title || proj.title,
        description: proj.description,
        tags: proj.tags,
        privacyStatus: activeJob.privacyStatus,
        srtText: proj.srtText,
        thumbnailBlob: activeMedia.thumbnailBlob,
      });
      await patchJob(activeJob.id, {
        stage: 'published',
        watchUrl: result.watchUrl,
        videoId: result.videoId,
        error: undefined,
      });
      onNotify(`Published "${activeJob.title}" directly to YouTube!`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'YouTube publish failed.';
      await patchJob(job.id, {stage: 'failed', error: msg});
      onNotify(msg);
    } finally {
      setBusyJobId(null);
    }
  };

  const handleDownloadJobBundle = (job: YouTubeAgentPostJob) => {
    const media = mediaByJob[job.id];
    const safeName =
      (job.title || job.topic).toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 48) ||
      'prime-youtube-video';

    if (media?.videoUrl) {
      const v = document.createElement('a');
      v.href = media.videoUrl;
      v.download = `${safeName}.webm`;
      v.click();
    }
    if (media?.thumbnailDataUrl) {
      const t = document.createElement('a');
      t.href = media.thumbnailDataUrl;
      t.download = `${safeName}-thumbnail.jpg`;
      t.click();
    }
    if (job.project?.srtText) {
      const sBlob = new Blob([job.project.srtText], {type: 'text/plain;charset=utf-8'});
      const sUrl = URL.createObjectURL(sBlob);
      const s = document.createElement('a');
      s.href = sUrl;
      s.download = `${safeName}.srt`;
      s.click();
      URL.revokeObjectURL(sUrl);
    }
    onNotify('Downloaded available video (.webm), cover (.jpg), and captions (.srt).');
  };

  const filteredQueue = useMemo(() => {
    if (stageFilter === 'all') return queue;
    if (stageFilter === 'queued') {
      return queue.filter((j) => j.stage === 'queued' || j.stage === 'script_ready');
    }
    if (stageFilter === 'ready') {
      return queue.filter(
        (j) => j.stage === 'rendered' || j.stage === 'audited' || j.stage === 'scheduled',
      );
    }
    if (stageFilter === 'published') return queue.filter((j) => j.stage === 'published');
    return queue.filter((j) => j.stage === 'failed');
  }, [queue, stageFilter]);

  const previewJob = queue.find((j) => j.id === previewJobId) ?? null;
  const previewMedia = previewJob ? mediaByJob[previewJob.id] : undefined;

  return (
    <div className="flex flex-col gap-5">
      {/* Free Unlimited Mode & Studio Config Header */}
      <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#24324A] pb-4">
          <div>
            <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
              <Bot className="h-4 w-4 text-[#E5C07B]" />
              <span>Autonomous YouTube Agent Team (100% Free · Zero Plans)</span>
            </h2>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Scout topics, write scripts, synthesize audio, render HD 16:9 / 9:16 videos +
              thumbnails + captions, and manage YouTube posting with zero subscription or quota lock.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#080C14] p-1">
              <button
                type="button"
                onClick={() => void updateSettings({engineMode: 'free_local'})}
                className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap ${
                  agentSettings.engineMode === 'free_local'
                    ? 'bg-[#161F30] text-[#34D399]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                Free Instant Engine (Unlimited)
              </button>
              <button
                type="button"
                onClick={() => void updateSettings({engineMode: 'ai_producer'})}
                className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap ${
                  agentSettings.engineMode === 'ai_producer'
                    ? 'bg-[#161F30] text-[#E5C07B]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                Gemini AI Producer
              </button>
            </div>

            <button
              type="button"
              disabled={isPipelineRunning || Boolean(busyJobId)}
              onClick={() => void handleRunFullAgentTeam()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap shrink-0"
            >
              <Wand2 className="h-3.5 w-3.5" />
              <span>
                {isPipelineRunning ? 'Agents Producing...' : 'Run Full YouTube Agent Team'}
              </span>
            </button>
          </div>
        </div>

        {/* Settings Strip: Format, Theme, Visibility, Cadence, Ambient Beat */}
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <label className="mb-1 block text-[11px] text-[#94A3B8]">Channel Niche / Focus</label>
            <input
              type="text"
              value={nicheInput}
              onChange={(ev) => setNicheInput(ev.target.value)}
              onBlur={() => void updateSettings({niche: nicheInput.trim() || agentSettings.niche})}
              placeholder="e.g., Free AI hacks, mobile gaming, tech tips..."
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
          </div>

          <div>
            <label className="mb-1 block text-[11px] text-[#94A3B8]">Default Format</label>
            <select
              aria-label="Default video format"
              value={agentSettings.defaultFormat}
              onChange={(ev) =>
                void updateSettings({defaultFormat: ev.target.value as VideoFormat})
              }
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs text-[#F1F5F9]"
            >
              <option value="9:16">9:16 YouTube Shorts</option>
              <option value="16:9">16:9 HD Landscape</option>
            </select>
          </div>

          <div>
            <label className="mb-1 block text-[11px] text-[#94A3B8]">Visual Theme</label>
            <select
              aria-label="Visual studio theme"
              value={agentSettings.defaultTheme}
              onChange={(ev) =>
                void updateSettings({defaultTheme: ev.target.value as YouTubeVideoTheme})
              }
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs text-[#F1F5F9]"
            >
              <option value="gold">Obsidian Gold</option>
              <option value="cyan">Cyber Cyan</option>
              <option value="emerald">Emerald Studio</option>
              <option value="crimson">Crimson Gaming</option>
            </select>
          </div>

          <div>
            <label className="mb-1 block text-[11px] text-[#94A3B8]">Post Visibility</label>
            <select
              aria-label="Default upload visibility"
              value={agentSettings.defaultPrivacy}
              onChange={(ev) =>
                void updateSettings({
                  defaultPrivacy: ev.target.value as 'private' | 'unlisted' | 'public',
                })
              }
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs text-[#F1F5F9]"
            >
              <option value="private">Private (Safe Draft)</option>
              <option value="unlisted">Unlisted</option>
              <option value="public">Public (Go Live)</option>
            </select>
          </div>

          <div>
            <label className="mb-1 block text-[11px] text-[#94A3B8]">Posting Cadence</label>
            <select
              aria-label="Posting cadence per day"
              value={agentSettings.postsPerDay}
              onChange={(ev) => void updateSettings({postsPerDay: Number(ev.target.value)})}
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-mono-tabular text-[#F1F5F9]"
            >
              <option value={1}>1 post / day</option>
              <option value={2}>2 posts / day</option>
              <option value={3}>3 posts / day</option>
              <option value={6}>6 posts / day</option>
            </select>
          </div>
        </div>

        {/* Automation Toggles */}
        <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-[#24324A] pt-3 text-xs text-[#94A3B8]">
          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={agentSettings.ambientMusicEnabled}
              onChange={(ev) => void updateSettings({ambientMusicEnabled: ev.target.checked})}
              className="h-3.5 w-3.5 rounded accent-[#E5C07B]"
            />
            <Music className="h-3.5 w-3.5 text-[#38BDF8]" />
            <span>Free Royalty-Free Ambient Audio Bed</span>
          </label>

          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={agentSettings.autoAuditBeforePost}
              onChange={(ev) => void updateSettings({autoAuditBeforePost: ev.target.checked})}
              className="h-3.5 w-3.5 rounded accent-[#34D399]"
            />
            <ShieldCheck className="h-3.5 w-3.5 text-[#34D399]" />
            <span>Auto SEO &amp; Caption Audit</span>
          </label>

          <label className="inline-flex cursor-pointer items-center gap-1.5">
            <input
              type="checkbox"
              checked={agentSettings.autoPublishConnected}
              onChange={(ev) => void updateSettings({autoPublishConnected: ev.target.checked})}
              className="h-3.5 w-3.5 rounded accent-[#E5C07B]"
            />
            <Upload className="h-3.5 w-3.5 text-[#E5C07B]" />
            <span>
              Auto-Post When YouTube Connected (
              {channelInfo?.title || googleUser?.email || 'Not Connected'})
            </span>
          </label>
        </div>

        {activeRenderText && (
          <div className="mt-3 rounded-lg border border-[#E5C07B]/40 bg-[#080C14] p-3">
            <div className="mb-1.5 flex items-center justify-between text-xs">
              <span className="truncate text-[#F1F5F9]">{activeRenderText}</span>
              <span className="font-mono-tabular text-[#E5C07B]">{activeRenderPct}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#161F30]">
              <div
                className="h-full bg-[#E5C07B] transition-all duration-150"
                style={{width: `${activeRenderPct}%`}}
              />
            </div>
          </div>
        )}
      </section>

      {/* 4 YouTube Agents Roster */}
      <section className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
        {agents.map((ag) => (
          <div
            key={ag.id}
            className="flex flex-col justify-between rounded-xl border border-[#24324A] bg-[#101724] p-4"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-display text-sm font-semibold text-[#F1F5F9]">{ag.name}</h3>
                <button
                  type="button"
                  onClick={() => void updateAgent(ag.id, {enabled: !ag.enabled})}
                  className={`rounded-md border px-2 py-0.5 text-[11px] font-medium whitespace-nowrap shrink-0 ${
                    ag.enabled
                      ? 'border-[#34D399]/50 bg-[#161F30] text-[#34D399]'
                      : 'border-[#24324A] bg-[#080C14] text-[#64748B]'
                  }`}
                >
                  {ag.enabled ? 'Active' : 'Paused'}
                </button>
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-[#94A3B8]">{ag.specialty}</p>
            </div>

            <div className="mt-3 border-t border-[#24324A] pt-2.5">
              <div className="flex items-center justify-between text-[11px] font-mono-tabular text-[#64748B]">
                <span>
                  State:{' '}
                  <strong
                    className={
                      ag.status === 'running'
                        ? 'text-[#E5C07B]'
                        : ag.status === 'error'
                          ? 'text-[#FB7185]'
                          : 'text-[#34D399]'
                    }
                  >
                    {ag.status}
                  </strong>
                </span>
                <span>{ag.tasksCompleted} done</span>
              </div>
              <p className="mt-1 truncate text-[11px] text-[#94A3B8]">{ag.lastAction}</p>

              <div className="mt-2.5">
                {ag.role === 'strategist' && (
                  <button
                    type="button"
                    disabled={isPipelineRunning || Boolean(busyJobId)}
                    onClick={() =>
                      void runScoutAgent().catch((err) =>
                        onNotify(err instanceof Error ? err.message : 'Scout failed.'),
                      )
                    }
                    className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Scout {scoutCount} Topics</span>
                  </button>
                )}
                {ag.role === 'scriptwriter' && (
                  <button
                    type="button"
                    disabled={isPipelineRunning || Boolean(busyJobId)}
                    onClick={async () => {
                      const target = queue.find((j) => !j.project) ?? queue[0];
                      if (!target) {
                        onNotify('Add or scout a video topic first.');
                        return;
                      }
                      const proj =
                        agentSettings.engineMode === 'free_local'
                          ? buildFreeLocalVideoProject({
                              topic: target.topic,
                              format: target.format,
                              theme: target.theme,
                              customHook: target.hook,
                              customTitle: target.title,
                            })
                          : await (async () => {
                              const r = await fetch('/api/prime/video/generate-package', {
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                body: JSON.stringify({topic: target.topic, format: target.format}),
                              });
                              const d = await r.json();
                              if (!r.ok) throw new Error(d.error || 'Script generation failed.');
                              return d as VideoProject;
                            })();
                      await patchJob(target.id, {
                        project: proj,
                        title: proj.title,
                        hook: proj.thumbnailHook,
                        stage: 'script_ready',
                      });
                      await updateAgent(ag.id, {
                        status: 'completed',
                        lastAction: `Scripted "${proj.title}".`,
                        tasksCompleted: ag.tasksCompleted + 1,
                      });
                      onNotify(`Script Agent wrote "${proj.title}".`);
                    }}
                    className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#38BDF8] hover:border-[#38BDF8] disabled:opacity-40"
                  >
                    <Play className="h-3.5 w-3.5" />
                    <span>Script Next Queued</span>
                  </button>
                )}
                {ag.role === 'producer' && (
                  <button
                    type="button"
                    disabled={isPipelineRunning || Boolean(busyJobId)}
                    onClick={() => {
                      const target =
                        queue.find((j) => !mediaByJob[j.id]?.videoBlob && j.stage !== 'published') ??
                        queue[0];
                      if (!target) {
                        onNotify('Add or scout a video topic first.');
                        return;
                      }
                      void produceSingleJob(target, {allowPublish: false}).catch((err) =>
                        onNotify(err instanceof Error ? err.message : 'Render failed.'),
                      );
                    }}
                    className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#34D399] hover:border-[#34D399] disabled:opacity-40"
                  >
                    <Film className="h-3.5 w-3.5" />
                    <span>Render Next Video</span>
                  </button>
                )}
                {ag.role === 'publisher' && (
                  <button
                    type="button"
                    disabled={isPipelineRunning || Boolean(busyJobId)}
                    onClick={() => {
                      const ready = queue.find(
                        (j) =>
                          mediaByJob[j.id]?.videoBlob &&
                          (j.stage === 'rendered' || j.stage === 'audited'),
                      );
                      if (!ready) {
                        onNotify('Render a video first, then click Post Next Ready.');
                        return;
                      }
                      void handlePublishSingleJob(ready);
                    }}
                    className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#E5C07B]/50 bg-[#080C14] px-2.5 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    <span>Post Next Ready</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Queue Composer + Posting Queue Manager */}
      <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#24324A] pb-4">
          <div className="flex flex-1 flex-wrap items-center gap-2">
            <input
              type="text"
              value={quickTopic}
              onChange={(ev) => setQuickTopic(ev.target.value)}
              onKeyDown={(ev) => {
                if (ev.key === 'Enter') {
                  ev.preventDefault();
                  void handleAddSingleTopic();
                }
              }}
              placeholder="Add custom video topic (e.g., Top 5 Free Gaming Settings for 120 FPS)..."
              className="min-w-[240px] flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <button
              type="button"
              onClick={() => void handleAddSingleTopic()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-2 text-xs font-semibold text-[#F1F5F9] hover:border-[#E5C07B] whitespace-nowrap"
            >
              <Plus className="h-3.5 w-3.5 text-[#E5C07B]" />
              <span>Add Topic</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <select
              aria-label="Topics to scout"
              value={scoutCount}
              onChange={(ev) => setScoutCount(Number(ev.target.value))}
              className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-2 text-xs font-mono-tabular text-[#F1F5F9]"
            >
              <option value={2}>Scout 2</option>
              <option value={4}>Scout 4</option>
              <option value={6}>Scout 6</option>
            </select>
            <button
              type="button"
              disabled={isPipelineRunning}
              onClick={() =>
                void runScoutAgent().catch((err) =>
                  onNotify(err instanceof Error ? err.message : 'Scout failed.'),
                )
              }
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-3 py-2 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Auto-Fill Queue</span>
            </button>
          </div>
        </div>

        {/* Queue Filter Tabs */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1 rounded-lg border border-[#24324A] bg-[#080C14] p-1">
            {(
              [
                {id: 'all', label: `All (${queue.length})`},
                {
                  id: 'queued',
                  label: `Queued (${queue.filter((j) => j.stage === 'queued' || j.stage === 'script_ready').length})`,
                },
                {
                  id: 'ready',
                  label: `Ready (${queue.filter((j) => j.stage === 'rendered' || j.stage === 'audited' || j.stage === 'scheduled').length})`,
                },
                {
                  id: 'published',
                  label: `Published (${queue.filter((j) => j.stage === 'published').length})`,
                },
                {
                  id: 'failed',
                  label: `Failed (${queue.filter((j) => j.stage === 'failed').length})`,
                },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setStageFilter(tab.id)}
                className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap font-mono-tabular ${
                  stageFilter === tab.id
                    ? 'bg-[#161F30] text-[#E5C07B]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {filteredQueue.length === 0 ? (
          <div className="mt-4 rounded-xl border border-dashed border-[#24324A] bg-[#080C14] p-8 text-center">
            <Bot className="mx-auto h-7 w-7 text-[#E5C07B]" />
            <p className="mt-2 text-sm font-semibold text-[#F1F5F9]">
              YouTube Agent Posting Queue is Empty
            </p>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Type a topic above or click <strong className="text-[#E5C07B]">Auto-Fill Queue</strong>{' '}
              to let Trend Scout generate free video topics and thumbnails automatically.
            </p>
          </div>
        ) : (
          <div className="mt-4 grid grid-cols-1 gap-3 lg:grid-cols-2">
            {filteredQueue.map((job) => {
              const media = mediaByJob[job.id];
              const stageInfo = STAGE_LABELS[job.stage] ?? STAGE_LABELS.queued;
              const isBusy = busyJobId === job.id;

              return (
                <article
                  key={job.id}
                  className="flex flex-col justify-between gap-3 rounded-xl border border-[#24324A] bg-[#080C14] p-4"
                >
                  <div className="flex gap-3">
                    {/* Live Thumbnail Slot */}
                    <div className="h-20 w-28 shrink-0 overflow-hidden rounded-lg border border-[#24324A] bg-[#101724]">
                      {media?.thumbnailDataUrl ? (
                        <img
                          src={media.thumbnailDataUrl}
                          alt={job.title}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full flex-col items-center justify-center p-2 text-center">
                          <Film className="h-4 w-4 text-[#E5C07B]" />
                          <span className="mt-1 text-[10px] font-mono-tabular text-[#64748B]">
                            {job.format}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono-tabular">
                        <span className={stageInfo.colorClass}>{stageInfo.label}</span>
                        <span className="text-[#64748B]">
                          {job.format} · {job.theme} · {job.privacyStatus}
                        </span>
                      </div>

                      <input
                        type="text"
                        value={job.title}
                        aria-label="Job YouTube title"
                        onChange={(ev) => void patchJob(job.id, {title: ev.target.value})}
                        className="mt-1.5 w-full rounded border border-transparent bg-transparent px-1 py-0.5 text-sm font-semibold text-[#F1F5F9] focus:border-[#24324A] focus:bg-[#101724] focus:outline-none"
                      />

                      <p className="mt-0.5 truncate px-1 text-xs text-[#94A3B8]">
                        Hook: {job.hook}
                      </p>

                      {job.error && (
                        <p className="mt-1 px-1 text-xs text-[#FB7185]">{job.error}</p>
                      )}

                      {job.watchUrl && (
                        <a
                          href={job.watchUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="mt-1 inline-flex items-center gap-1 px-1 text-xs text-[#34D399] hover:underline"
                        >
                          <CheckCircle2 className="h-3 w-3" />
                          <span>Published · Open on YouTube</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Schedule & Privacy Controls */}
                  <div className="grid grid-cols-1 gap-2 border-t border-[#24324A] pt-2.5 sm:grid-cols-2">
                    <div className="flex items-center gap-1.5 text-xs">
                      <CalendarClock className="h-3.5 w-3.5 shrink-0 text-[#38BDF8]" />
                      <input
                        type="datetime-local"
                        aria-label="Scheduled publish date"
                        value={toDateTimeLocalValue(job.scheduledForMs)}
                        onChange={(ev) => {
                          const parsed = Date.parse(ev.target.value);
                          if (Number.isFinite(parsed)) {
                            void patchJob(job.id, {scheduledForMs: parsed});
                          }
                        }}
                        className="w-full rounded border border-[#24324A] bg-[#101724] px-2 py-1 text-[11px] font-mono-tabular text-[#F1F5F9]"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <select
                        aria-label="Job privacy visibility"
                        value={job.privacyStatus}
                        onChange={(ev) =>
                          void patchJob(job.id, {
                            privacyStatus: ev.target.value as 'private' | 'unlisted' | 'public',
                          })
                        }
                        className="flex-1 rounded border border-[#24324A] bg-[#101724] px-2 py-1 text-[11px] text-[#F1F5F9]"
                      >
                        <option value="private">Private</option>
                        <option value="unlisted">Unlisted</option>
                        <option value="public">Public</option>
                      </select>

                      <select
                        aria-label="Job format"
                        value={job.format}
                        onChange={(ev) =>
                          void patchJob(job.id, {format: ev.target.value as VideoFormat})
                        }
                        className="rounded border border-[#24324A] bg-[#101724] px-2 py-1 text-[11px] font-mono-tabular text-[#F1F5F9]"
                      >
                        <option value="9:16">9:16</option>
                        <option value="16:9">16:9</option>
                      </select>
                    </div>
                  </div>

                  {/* Action Row */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#24324A] pt-2.5">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        disabled={isPipelineRunning || isBusy}
                        onClick={() =>
                          void produceSingleJob(job, {allowPublish: false}).catch((err) =>
                            onNotify(err instanceof Error ? err.message : 'Production failed.'),
                          )
                        }
                        className="inline-flex items-center gap-1 rounded-md bg-[#E5C07B] px-2.5 py-1 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap"
                      >
                        {job.stage === 'failed' ? (
                          <RotateCcw className="h-3 w-3" />
                        ) : (
                          <Wand2 className="h-3 w-3" />
                        )}
                        <span>
                          {isBusy
                            ? 'Producing...'
                            : media?.videoBlob
                              ? 'Re-Render'
                              : 'Create Video'}
                        </span>
                      </button>

                      {media?.videoUrl && (
                        <button
                          type="button"
                          onClick={() => setPreviewJobId(job.id)}
                          className="inline-flex items-center gap-1 rounded-md border border-[#24324A] bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#38BDF8] hover:border-[#38BDF8] whitespace-nowrap"
                        >
                          <Play className="h-3 w-3" />
                          <span>Preview</span>
                        </button>
                      )}

                      {(media?.videoUrl || job.project) && (
                        <button
                          type="button"
                          onClick={() => handleDownloadJobBundle(job)}
                          className="inline-flex items-center gap-1 rounded-md border border-[#24324A] bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B] whitespace-nowrap"
                        >
                          <Download className="h-3 w-3 text-[#E5C07B]" />
                          <span>Bundle</span>
                        </button>
                      )}

                      {job.project && (
                        <button
                          type="button"
                          onClick={() =>
                            onOpenProjectInEditor(job.project!, mediaByJob[job.id], job.theme)
                          }
                          className="inline-flex items-center gap-1 rounded-md border border-[#24324A] bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#94A3B8] hover:text-[#F1F5F9] whitespace-nowrap"
                        >
                          <RefreshCw className="h-3 w-3" />
                          <span>Edit</span>
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={isPipelineRunning || isBusy}
                        onClick={() => void handlePublishSingleJob(job)}
                        className="inline-flex items-center gap-1 rounded-md border border-[#34D399]/50 bg-[#161F30] px-2.5 py-1 text-xs font-semibold text-[#34D399] hover:border-[#34D399] disabled:opacity-40 whitespace-nowrap"
                      >
                        <Upload className="h-3 w-3" />
                        <span>{job.watchUrl ? 'Re-Post' : 'Post Now'}</span>
                      </button>

                      <button
                        type="button"
                        aria-label={`Delete ${job.title}`}
                        onClick={() => void deleteJob(job.id)}
                        className="rounded-md p-1.5 text-[#64748B] hover:bg-[#161F30] hover:text-[#FB7185]"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Video Preview Modal */}
      {previewJob && previewMedia?.videoUrl && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="YouTube Agent Video Preview"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
        >
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-xl border border-[#24324A] bg-[#101724] p-5">
            <div className="flex items-start justify-between gap-3 border-b border-[#24324A] pb-3">
              <div className="min-w-0">
                <h3 className="truncate font-display text-base font-semibold text-[#F1F5F9]">
                  {previewJob.title}
                </h3>
                <p className="mt-0.5 text-xs text-[#94A3B8] font-mono-tabular">
                  {previewJob.format} · {previewMedia.durationSec?.toFixed(1) ?? '0'}s ·{' '}
                  {previewMedia.videoBlob
                    ? `${(previewMedia.videoBlob.size / (1024 * 1024)).toFixed(2)} MB`
                    : ''}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewJobId(null)}
                aria-label="Close video preview"
                className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <video
              src={previewMedia.videoUrl}
              controls
              autoPlay
              className="mt-4 max-h-[420px] w-full rounded-lg border border-[#24324A] bg-[#080C14]"
            />

            <div className="mt-4 flex flex-wrap items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => handleDownloadJobBundle(previewJob)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-3.5 py-2 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B]"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download Video, Cover &amp; SRT</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setPreviewJobId(null);
                  void handlePublishSingleJob(previewJob);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3.5 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93]"
              >
                <Upload className="h-3.5 w-3.5" />
                <span>Post to YouTube</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
