package com.example.prime

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.prime.brain.PrimeGeminiClient
import com.example.prime.brain.PrimeMathTool
import com.example.prime.brain.PrimePersonality
import com.example.prime.brain.ToolCallOutcome
import com.example.prime.data.MemoryEntity
import com.example.prime.data.PrimeDatabase
import com.example.prime.data.PrimeSerializers.toDomain
import com.example.prime.data.PrimeSerializers.toEntity
import com.example.prime.data.SettingsRepository
import com.example.prime.data.TaskEntity
import com.example.prime.data.VoiceProfileEntity
import com.example.prime.model.BrainDepth
import com.example.prime.model.DeviceActionSuggestion
import com.example.prime.model.DeviceVoiceOption
import com.example.prime.model.GeminiVoicePersona
import com.example.prime.model.PrimeMessage
import com.example.prime.model.PrimeSettings
import com.example.prime.model.SkillDefinition
import com.example.prime.model.ToolExecutionBadge
import com.example.prime.model.VocalStylePreset
import com.example.prime.model.VoiceEngineMode
import com.example.prime.model.VoiceState
import com.example.prime.voice.PrimeVoiceController
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class PrimeViewModel(application: Application) : AndroidViewModel(application) {

  private val db = PrimeDatabase.getInstance(application)
  private val dao = db.primeDao()
  private val settingsRepo = SettingsRepository(application)
  private val geminiClient = PrimeGeminiClient()
  private val voiceController = PrimeVoiceController(application, geminiClient, viewModelScope)

  val settings: StateFlow<PrimeSettings> = settingsRepo.settings

  val messages: StateFlow<List<PrimeMessage>> =
    dao
      .observeMessages()
      .map { list -> list.map { it.toDomain() } }
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val memories: StateFlow<List<MemoryEntity>> =
    dao.observeMemories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val tasks: StateFlow<List<TaskEntity>> =
    dao.observeTasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val voiceProfiles: StateFlow<List<VoiceProfileEntity>> =
    dao
      .observeVoiceProfiles()
      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val availableDeviceVoices: StateFlow<List<DeviceVoiceOption>> =
    voiceController.availableDeviceVoices

  val voiceState: StateFlow<VoiceState> = voiceController.voiceState
  val partialTranscript: StateFlow<String> = voiceController.partialTranscript
  val audioLevel: StateFlow<Float> = voiceController.audioLevel

  private val _draftInput = MutableStateFlow("")
  val draftInput: StateFlow<String> = _draftInput.asStateFlow()

  private val _attachedImageUri = MutableStateFlow<String?>(null)
  val attachedImageUri: StateFlow<String?> = _attachedImageUri.asStateFlow()

  private val _isProcessing = MutableStateFlow(false)
  val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

  private val _statusBanner = MutableStateFlow<String?>(null)
  val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

  init {
    bootstrapSessionGreeting()
  }

  private fun bootstrapSessionGreeting() {
    viewModelScope.launch {
      val existingMessages = dao.observeMessages().first()
      val currentSettings = settings.value
      val pendingCount = dao.getPendingTasksOnce().size

      if (existingMessages.isEmpty()) {
        val greeting =
          PrimePersonality.buildTimeGreeting(
            settings = currentSettings,
            pendingTaskCount = pendingCount,
          )
        dao.insertMessage(
          PrimeMessage(
            isUser = false,
            text = greeting,
            reasoningTrace =
              "Session initialized with ${currentSettings.mannerProfile.title} etiquette. Checked $pendingCount pending tasks.",
          )
            .toEntity()
        )
        if (currentSettings.autoSpeakGreeting) {
          voiceController.speak(greeting, currentSettings)
        }
      } else if (currentSettings.autoSpeakGreeting) {
        val greeting =
          PrimePersonality.buildTimeGreeting(
            settings = currentSettings,
            pendingTaskCount = pendingCount,
          )
        voiceController.speak(greeting, currentSettings)
      }
    }
  }

  fun updateDraft(value: String) {
    _draftInput.value = value
  }

  fun clearStatusBanner() {
    _statusBanner.value = null
  }

  fun showBanner(message: String) {
    _statusBanner.value = message
  }

  fun attachImageFromUri(uri: Uri) {
    viewModelScope.launch {
      val savedPath = copyAndCompressImage(uri)
      if (savedPath != null) {
        _attachedImageUri.value = savedPath
      } else {
        _statusBanner.value = "Could not load the selected image."
      }
    }
  }

  fun clearAttachedImage() {
    _attachedImageUri.value = null
  }

  fun sendMessage(overrideText: String? = null) {
    val text = (overrideText ?: _draftInput.value).trim()
    val imagePath = _attachedImageUri.value
    if ((text.isEmpty() && imagePath == null) || _isProcessing.value) return

    val promptText = text.ifEmpty { "Please analyze the attached image carefully." }
    if (overrideText == null) _draftInput.value = ""
    _attachedImageUri.value = null

    viewModelScope.launch {
      _isProcessing.value = true
      voiceController.setThinking(true)

      val historySnapshot = messages.value
      dao.insertMessage(
        PrimeMessage(
          isUser = true,
          text = promptText,
          imageUriString = imagePath,
        )
          .toEntity()
      )

      val imageBytes =
        imagePath?.let { path -> withContext(Dispatchers.IO) { runCatching { File(path).readBytes() }.getOrNull() } }

      val currentSettings = settings.value
      val memoryList = dao.getMemoriesOnce().map { "[${it.category}] ${it.fact}" }
      val pendingTaskList =
        dao.getPendingTasksOnce().map { task ->
          val due = if (task.dueNote.isNotBlank()) " (${task.dueNote})" else ""
          "[${task.priority}] ${task.title}$due"
        }

      val result =
        geminiClient.generateReply(
          userPrompt = promptText,
          attachedImageBytes = imageBytes,
          attachedImageMime = if (imageBytes != null) "image/jpeg" else null,
          history = historySnapshot,
          settings = currentSettings,
          memories = memoryList,
          pendingTasks = pendingTaskList,
          onToolCall = { toolName, args -> executeToolCall(toolName, args) },
        )

      voiceController.setThinking(false)
      _isProcessing.value = false

      result
        .onSuccess { outcome ->
          dao.insertMessage(
            PrimeMessage(
              isUser = false,
              text = outcome.replyText,
              reasoningTrace = outcome.reasoningTrace,
              sources = outcome.sources,
              toolActions = outcome.toolActions,
              deviceAction = outcome.deviceAction,
            )
              .toEntity()
          )
          if (currentSettings.autoSpeakReplies) {
            voiceController.speak(outcome.replyText, currentSettings)
          }
        }
        .onFailure { err ->
          val msg = err.message ?: "Unable to complete request right now."
          dao.insertMessage(
            PrimeMessage(
              isUser = false,
              text = msg,
              isError = true,
            )
              .toEntity()
          )
        }
    }
  }

  private suspend fun executeToolCall(toolName: String, args: JSONObject): ToolCallOutcome {
    return when (toolName) {
      "remember_fact" -> {
        val category = args.optString("category", "Note").ifBlank { "Note" }
        val fact = args.optString("fact", "").trim()
        if (fact.isNotEmpty()) {
          dao.insertMemory(MemoryEntity(category = category, fact = fact))
          ToolCallOutcome(
            responsePayload = JSONObject().put("status", "saved").put("fact", fact),
            badge = ToolExecutionBadge("Memory Vault", "Saved: $fact"),
          )
        } else {
          ToolCallOutcome(JSONObject().put("status", "ignored"))
        }
      }

      "create_task" -> {
        val title = args.optString("title", "").trim()
        val priority = args.optString("priority", "Normal").ifBlank { "Normal" }
        val dueNote = args.optString("due_note", "").trim()
        if (title.isNotEmpty()) {
          dao.insertTask(TaskEntity(title = title, priority = priority, dueNote = dueNote))
          ToolCallOutcome(
            responsePayload = JSONObject().put("status", "created").put("title", title),
            badge = ToolExecutionBadge("Agenda Task", "Added: $title"),
          )
        } else {
          ToolCallOutcome(JSONObject().put("status", "ignored"))
        }
      }

      "complete_task" -> {
        val query = args.optString("title_query", "").trim().lowercase()
        val pending = dao.getPendingTasksOnce()
        val match =
          pending.firstOrNull { it.title.lowercase().contains(query) }
            ?: pending.firstOrNull { query.contains(it.title.lowercase()) }
        if (match != null) {
          dao.updateTask(match.copy(isCompleted = true))
          ToolCallOutcome(
            responsePayload = JSONObject().put("status", "completed").put("title", match.title),
            badge = ToolExecutionBadge("Agenda Task", "Completed: ${match.title}"),
          )
        } else {
          ToolCallOutcome(JSONObject().put("status", "not_found"))
        }
      }

      "evaluate_math" -> {
        val expression = args.optString("expression", "")
        val eval = PrimeMathTool.evaluate(expression)
        eval.fold(
          onSuccess = { value ->
            val formatted = PrimeMathTool.formatResult(value)
            ToolCallOutcome(
              responsePayload =
                JSONObject()
                  .put("expression", expression)
                  .put("result", formatted),
              badge = ToolExecutionBadge("Exact Math", "$expression = $formatted"),
            )
          },
          onFailure = { err ->
            ToolCallOutcome(
              responsePayload =
                JSONObject()
                  .put("expression", expression)
                  .put("error", err.message ?: "Invalid expression"),
            )
          },
        )
      }

      "prepare_device_action" -> {
        val actionType = args.optString("action_type", "SHARE").uppercase()
        val label = args.optString("label", "Open Action")
        val detail = args.optString("detail", "")
        val suggestion = DeviceActionSuggestion(actionType = actionType, label = label, detail = detail)
        ToolCallOutcome(
          responsePayload = JSONObject().put("status", "prepared").put("label", label),
          badge = ToolExecutionBadge("Device Action", label),
          deviceAction = suggestion,
        )
      }

      else -> ToolCallOutcome(JSONObject().put("status", "unknown_tool"))
    }
  }

  fun triggerVoiceGreeting() {
    viewModelScope.launch {
      val pending = dao.getPendingTasksOnce().size
      val currentSettings = settings.value
      val greeting =
        PrimePersonality.buildTimeGreeting(
          settings = currentSettings,
          pendingTaskCount = pending,
        )
      voiceController.speak(greeting, currentSettings)
    }
  }

  fun speakMessage(text: String) {
    voiceController.speak(text, settings.value)
  }

  fun stopVoice() {
    voiceController.stopSpeaking()
    voiceController.stopListening()
  }

  fun toggleVoiceListening() {
    when (voiceState.value) {
      VoiceState.LISTENING -> voiceController.stopListening()
      VoiceState.SPEAKING -> voiceController.stopSpeaking()
      VoiceState.THINKING -> Unit
      VoiceState.IDLE -> {
        voiceController.startListening(
          onFinalResult = { transcript ->
            if (transcript.isNotBlank()) {
              sendMessage(transcript)
            }
          },
          onErrorMessage = { errorMsg -> _statusBanner.value = errorMsg },
        )
      }
    }
  }

  fun clearConversation() {
    viewModelScope.launch {
      voiceController.stopSpeaking()
      dao.clearMessages()
      val currentSettings = settings.value
      val pendingCount = dao.getPendingTasksOnce().size
      val greeting =
        PrimePersonality.buildTimeGreeting(
          settings = currentSettings,
          pendingTaskCount = pendingCount,
        )
      dao.insertMessage(
        PrimeMessage(
          isUser = false,
          text = greeting,
          reasoningTrace = "Fresh conversation started with ${currentSettings.mannerProfile.title} tone.",
        )
          .toEntity()
      )
      if (currentSettings.autoSpeakGreeting) {
        voiceController.speak(greeting, currentSettings)
      }
    }
  }

  fun activateSkill(skill: SkillDefinition, onNavigateToChat: () -> Unit) {
    if (skill.requiresDeepBrain && settings.value.brainDepth != BrainDepth.NEON_DEEP) {
      settingsRepo.update { it.copy(brainDepth = BrainDepth.NEON_DEEP) }
      _statusBanner.value = "Switched to Deep Reasoning for ${skill.name}."
    }
    if (skill.id == "daily_briefing") {
      onNavigateToChat()
      sendMessage(skill.starterPrompt)
    } else {
      _draftInput.value = skill.starterPrompt
      onNavigateToChat()
    }
  }

  fun addManualMemory(category: String, fact: String) {
    val cleanFact = fact.trim()
    if (cleanFact.isEmpty()) return
    viewModelScope.launch {
      dao.insertMemory(MemoryEntity(category = category.ifBlank { "Note" }, fact = cleanFact))
    }
  }

  fun deleteMemory(memory: MemoryEntity) {
    viewModelScope.launch { dao.deleteMemory(memory) }
  }

  fun clearAllMemories() {
    viewModelScope.launch { dao.clearMemories() }
  }

  fun addManualTask(title: String, priority: String, dueNote: String) {
    val cleanTitle = title.trim()
    if (cleanTitle.isEmpty()) return
    viewModelScope.launch {
      dao.insertTask(
        TaskEntity(
          title = cleanTitle,
          priority = priority.ifBlank { "Normal" },
          dueNote = dueNote.trim(),
        )
      )
    }
  }

  fun toggleTaskCompleted(task: TaskEntity) {
    viewModelScope.launch { dao.updateTask(task.copy(isCompleted = !task.isCompleted)) }
  }

  fun deleteTask(task: TaskEntity) {
    viewModelScope.launch { dao.deleteTask(task) }
  }

  fun updateSettings(transform: (PrimeSettings) -> PrimeSettings) {
    settingsRepo.update(transform)
  }

  fun previewCustomVoice(
    engineMode: VoiceEngineMode,
    geminiPersona: GeminiVoicePersona,
    vocalStyle: VocalStylePreset,
    deviceLocaleTag: String,
    deviceVoiceName: String,
    pitch: Float,
    speechRate: Float,
    samplePhrase: String,
  ) {
    val current = settings.value
    val previewSettings =
      current.copy(
        voiceEngine = engineMode,
        geminiVoicePersona = geminiPersona,
        vocalStyle = vocalStyle,
        deviceLocaleTag = deviceLocaleTag,
        deviceVoiceName = deviceVoiceName,
        devicePitch = pitch,
        deviceSpeechRate = speechRate,
      )
    val phrase =
      samplePhrase.trim().ifEmpty {
        "Good evening, ${current.preferredTitle}. This is your custom PRIME voice."
      }
    voiceController.speak(phrase, previewSettings)
  }

  fun saveAndActivateVoiceProfile(
    editingId: Long? = null,
    name: String,
    engineMode: VoiceEngineMode,
    geminiPersona: GeminiVoicePersona,
    vocalStyle: VocalStylePreset,
    deviceLocaleTag: String,
    deviceVoiceName: String,
    pitch: Float,
    speechRate: Float,
    samplePhrase: String,
    activateImmediately: Boolean = true,
  ) {
    val cleanName = name.trim().ifEmpty { "Custom Voice" }
    val cleanPhrase =
      samplePhrase.trim().ifEmpty {
        "At your service, ${settings.value.preferredTitle}. My voice is calibrated and ready."
      }
    viewModelScope.launch {
      val entity =
        VoiceProfileEntity(
          id = editingId ?: 0L,
          name = cleanName,
          engineMode = engineMode.name,
          geminiPersona = geminiPersona.name,
          vocalStyle = vocalStyle.name,
          deviceLocaleTag = deviceLocaleTag,
          deviceVoiceName = deviceVoiceName,
          pitch = pitch,
          speechRate = speechRate,
          samplePhrase = cleanPhrase,
        )
      val savedId =
        if (editingId != null && editingId > 0L) {
          dao.updateVoiceProfile(entity)
          editingId
        } else {
          dao.insertVoiceProfile(entity)
        }
      if (activateImmediately) {
        val saved = entity.copy(id = savedId)
        applyVoiceProfileToSettings(saved)
        _statusBanner.value = "Created and activated voice \"$cleanName\"."
        voiceController.speak(cleanPhrase, settings.value)
      } else {
        _statusBanner.value = "Saved voice \"$cleanName\"."
      }
    }
  }

  fun activateVoiceProfile(profile: VoiceProfileEntity, speakPreview: Boolean = true) {
    applyVoiceProfileToSettings(profile)
    _statusBanner.value = "Active voice set to \"${profile.name}\"."
    if (speakPreview) {
      voiceController.speak(profile.samplePhrase, settings.value)
    }
  }

  private fun applyVoiceProfileToSettings(profile: VoiceProfileEntity) {
    val engine =
      VoiceEngineMode.entries.firstOrNull { it.name == profile.engineMode }
        ?: VoiceEngineMode.DEVICE_TTS
    val persona =
      GeminiVoicePersona.entries.firstOrNull { it.name == profile.geminiPersona }
        ?: GeminiVoicePersona.CHARON
    val style =
      VocalStylePreset.entries.firstOrNull { it.name == profile.vocalStyle }
        ?: VocalStylePreset.REFINED_BUTLER
    settingsRepo.update {
      it.copy(
        voiceEngine = engine,
        geminiVoicePersona = persona,
        vocalStyle = style,
        deviceLocaleTag = profile.deviceLocaleTag,
        deviceVoiceName = profile.deviceVoiceName,
        devicePitch = profile.pitch,
        deviceSpeechRate = profile.speechRate,
        activeCustomVoiceId = profile.id,
        activeCustomVoiceName = profile.name,
      )
    }
  }

  fun deleteVoiceProfile(profile: VoiceProfileEntity) {
    viewModelScope.launch {
      dao.deleteVoiceProfile(profile)
      if (settings.value.activeCustomVoiceId == profile.id) {
        settingsRepo.update {
          it.copy(activeCustomVoiceId = null, activeCustomVoiceName = null)
        }
      }
      _statusBanner.value = "Deleted voice \"${profile.name}\"."
    }
  }

  private suspend fun copyAndCompressImage(uri: Uri): String? =
    withContext(Dispatchers.IO) {
      runCatching {
          val resolver = getApplication<Application>().contentResolver
          val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: return@runCatching null
          val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size) ?: return@runCatching null

          val maxDim = 1280
          val scale =
            if (decoded.width > maxDim || decoded.height > maxDim) {
              maxDim.toFloat() / maxOf(decoded.width, decoded.height).toFloat()
            } else {
              1f
            }
          val targetW = maxOf(1, (decoded.width * scale).toInt())
          val targetH = maxOf(1, (decoded.height * scale).toInt())
          val resized =
            if (scale < 1f) Bitmap.createScaledBitmap(decoded, targetW, targetH, true) else decoded

          val outStream = ByteArrayOutputStream()
          resized.compress(Bitmap.CompressFormat.JPEG, 85, outStream)
          val dir = File(getApplication<Application>().filesDir, "attachments").apply { mkdirs() }
          val file = File(dir, "prime_img_${System.currentTimeMillis()}.jpg")
          FileOutputStream(file).use { it.write(outStream.toByteArray()) }
          file.absolutePath
        }
        .getOrNull()
    }

  override fun onCleared() {
    super.onCleared()
    voiceController.release()
  }
}
