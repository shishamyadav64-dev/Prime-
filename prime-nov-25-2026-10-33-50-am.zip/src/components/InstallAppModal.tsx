import {useEffect, useState} from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Copy,
  Download,
  ExternalLink,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{outcome: 'accepted' | 'dismissed'}>;
}

interface AppInfoResponse {
  appName: string;
  previewVersion: string;
  features: string[];
  apkAvailable: boolean;
  apkBytes: number;
  apkUpdatedAtMs: number | null;
  apkPath: string;
}

interface InstallAppModalProps {
  open: boolean;
  installPromptEvent: BeforeInstallPromptEvent | null;
  onConsumeInstallPrompt: () => void;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

const SHARED_PREVIEW_URL =
  'https://ais-pre-x5fvxa4gtx4d24wjwbtk2e-595301291183.asia-northeast1.run.app';

export function InstallAppModal({
  open,
  installPromptEvent,
  onConsumeInstallPrompt,
  onClose,
  onNotify,
}: InstallAppModalProps) {
  const [appInfo, setAppInfo] = useState<AppInfoResponse | null>(null);
  const [isInstallingPwa, setIsInstallingPwa] = useState(false);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    fetch('/api/prime/app-info')
      .then((r) => (r.ok ? r.json() : null))
      .then((data: AppInfoResponse | null) => {
        if (!cancelled && data) setAppInfo(data);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [open]);

  if (!open) return null;

  const liveUrl = typeof window !== 'undefined' ? window.location.origin : SHARED_PREVIEW_URL;
  const apkDirectUrl = `${liveUrl}/api/prime/android-apk`;
  const isIOS =
    typeof navigator !== 'undefined' &&
    /iphone|ipad|ipod/i.test(navigator.userAgent.toLowerCase());
  const inIframe =
    typeof window !== 'undefined' &&
    (() => {
      try {
        return window.self !== window.top;
      } catch {
        return true;
      }
    })();

  const handleTriggerNativeInstall = async () => {
    if (!installPromptEvent) {
      void navigator.clipboard?.writeText(liveUrl);
      onNotify(
        isIOS
          ? 'Link copied. Open it in Safari -> Share -> Add to Home Screen.'
          : 'Live App link copied. Open it directly in Android Chrome -> Menu (⋮) -> Install app.',
      );
      return;
    }
    setIsInstallingPwa(true);
    try {
      await installPromptEvent.prompt();
      const choice = await installPromptEvent.userChoice;
      if (choice.outcome === 'accepted') {
        onNotify('Installing the exact preview version (PRIME) onto your device.');
        onConsumeInstallPrompt();
        onClose();
      }
    } finally {
      setIsInstallingPwa(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Install Latest Preview App"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
    >
      <div className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-xl border border-[#24324A] bg-[#101724] p-6">
        <div className="flex items-start justify-between gap-4 border-b border-[#24324A] pb-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Install Exact Preview App (v{appInfo?.previewVersion ?? '2.5.0'})
            </h2>
            <p className="mt-1 text-xs text-[#94A3B8]">
              Full-screen standalone Android/Desktop app — 100% identical to what you see in preview.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close download modal"
            className="rounded-lg p-1.5 text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 flex flex-col gap-4">
          {/* Primary Recommended Option: Standalone WebAPK (Exact Preview) */}
          <section className="rounded-xl border border-[#E5C07B]/55 bg-[#080C14] p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="flex items-center gap-2 font-display text-sm font-semibold text-[#F1F5F9]">
                  <Sparkles className="h-4 w-4 text-[#E5C07B]" />
                  <span>Latest Preview App (Recommended for Android &amp; Desktop)</span>
                </h3>
                <p className="mt-1 text-xs leading-relaxed text-[#94A3B8]">
                  Installs as a real standalone Android home-screen app (Chrome WebAPK) with Game
                  Space, Free YouTube Agents, AI Workforce, Vault Tags, and Voice Studio.
                </p>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between gap-2 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-2 text-xs font-mono-tabular">
              <span className="truncate text-[#38BDF8]">{liveUrl}</span>
              <button
                type="button"
                onClick={() => {
                  void navigator.clipboard?.writeText(liveUrl);
                  onNotify('Copied latest live preview URL.');
                }}
                className="inline-flex shrink-0 items-center gap-1 rounded px-2 py-1 text-[11px] font-medium text-[#E5C07B] hover:bg-[#161F30]"
              >
                <Copy className="h-3 w-3" />
                <span>Copy Link</span>
              </button>
            </div>

            {appInfo?.features && (
              <div className="mt-3 grid grid-cols-1 gap-1 sm:grid-cols-2">
                {appInfo.features.map((feat) => (
                  <div key={feat} className="flex items-center gap-1.5 text-[11px] text-[#94A3B8]">
                    <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-[#34D399]" />
                    <span className="truncate">{feat}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Step-by-step instructions so phone users never hit the old APK */}
            <div className="mt-3 rounded-lg border border-[#24324A] bg-[#101724] p-3 text-[11px] text-[#94A3B8]">
              <p className="font-semibold text-[#F1F5F9]">
                {isIOS
                  ? 'How to install on iPhone / iPad:'
                  : 'How to install on Android (Exact Same Preview UI):'}
              </p>
              {isIOS ? (
                <ol className="mt-1 list-inside list-decimal space-y-0.5">
                  <li>Open the link above in Safari.</li>
                  <li>Tap the Share icon and choose &ldquo;Add to Home Screen&rdquo;.</li>
                </ol>
              ) : (
                <ol className="mt-1 list-inside list-decimal space-y-0.5">
                  <li>
                    {inIframe
                      ? 'Tap "Open in Chrome Tab" below (install prompts only appear outside preview frames).'
                      : 'Tap "Install Latest App Now" below or open Chrome Menu (⋮).'}
                  </li>
                  <li>Tap &ldquo;Install app&rdquo; or &ldquo;Add to Home screen&rdquo; → Install.</li>
                  <li>Launch PRIME from your phone&apos;s app drawer — exact preview UI &amp; tools.</li>
                </ol>
              )}
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                disabled={isInstallingPwa}
                onClick={() => void handleTriggerNativeInstall()}
                className="inline-flex items-center gap-2 rounded-lg bg-[#E5C07B] px-4 py-2 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-50 whitespace-nowrap"
              >
                <Smartphone className="h-4 w-4" />
                <span>
                  {installPromptEvent
                    ? isInstallingPwa
                      ? 'Installing...'
                      : 'Install Latest App Now'
                    : 'Copy Live App Link'}
                </span>
              </button>
              <a
                href={liveUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#38BDF8]/50 bg-[#101724] px-3.5 py-2 text-xs font-semibold text-[#38BDF8] hover:border-[#38BDF8] whitespace-nowrap"
              >
                <span>Open in Chrome Tab</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </section>

          {/* Google Play Store (.aab / Signed .apk via PWABuilder) */}
          <section className="rounded-xl border border-[#24324A] bg-[#080C14] p-4">
            <h3 className="flex items-center gap-2 font-display text-sm font-semibold text-[#F1F5F9]">
              <Download className="h-4 w-4 text-[#34D399]" />
              <span>Export Signed Google Play Bundle (.aab / .apk)</span>
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-[#94A3B8]">
              Generate a Play-Store-ready Android App Bundle (`.aab`) or signed `.apk` wrapping
              this exact preview URL using Microsoft PWABuilder, then upload to your Google Play
              Console account.
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <a
                href={`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(SHARED_PREVIEW_URL)}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#34D399]/50 bg-[#101724] px-3.5 py-2 text-xs font-semibold text-[#34D399] hover:border-[#34D399] whitespace-nowrap"
              >
                <span>Build Play Store APK / AAB</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </section>

          {/* Secondary / Legacy APK Disclosure */}
          <details className="rounded-xl border border-[#24324A] bg-[#080C14] p-4">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-2 text-xs font-medium text-[#94A3B8] hover:text-[#F1F5F9]">
              <span className="flex items-center gap-2">
                <AlertTriangle className="h-3.5 w-3.5 text-[#F59E0B]" />
                <span>Legacy Native Kotlin Prototype (.apk — Older v1.0 UI)</span>
              </span>
              <ChevronDown className="h-3.5 w-3.5" />
            </summary>

            <div className="mt-3 border-t border-[#24324A] pt-3">
              <p className="text-xs leading-relaxed text-[#F59E0B]">
                Warning: This prebuilt `.apk` is the earlier offline Jetpack Compose prototype (`v1.0`
                with only PRIME / Skills / Vault / Studio tabs). It does NOT include Game Space,
                Free YouTube Agents, AI Workforce, or Vault Tags because Android Gradle compilation
                is not available in this web container. Use &ldquo;Latest Preview App&rdquo; above
                to install the exact current version on Android.
              </p>

              <div className="mt-3 flex items-center justify-between gap-2 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-2 text-xs font-mono-tabular">
                <span className="truncate text-[#64748B]">{apkDirectUrl}</span>
                <button
                  type="button"
                  onClick={() => {
                    void navigator.clipboard?.writeText(apkDirectUrl);
                    onNotify('Copied legacy v1.0 APK URL.');
                  }}
                  className="inline-flex shrink-0 items-center gap-1 rounded px-2 py-1 text-[11px] font-medium text-[#94A3B8] hover:bg-[#161F30] hover:text-[#F1F5F9]"
                >
                  <Copy className="h-3 w-3" />
                  <span>Copy</span>
                </button>
              </div>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                <span className="text-[11px] text-[#64748B] font-mono-tabular">
                  {appInfo?.apkAvailable
                    ? `${(appInfo.apkBytes / (1024 * 1024)).toFixed(2)} MB · Legacy Build`
                    : 'Unavailable'}
                </span>
                <a
                  href="/api/prime/android-apk"
                  download="PRIME-legacy-v1-prototype.apk"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#94A3B8] hover:border-[#F59E0B]/60 hover:text-[#F1F5F9] whitespace-nowrap"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download Legacy .apk</span>
                </a>
              </div>
            </div>
          </details>
        </div>
      </div>
    </div>
  );
}
