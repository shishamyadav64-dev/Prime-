package com.example.prime.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.prime.data.MemoryEntity
import com.example.prime.data.TaskEntity
import com.example.prime.data.VoiceProfileEntity
import com.example.prime.device.PrimeDeviceActions
import com.example.prime.model.BrainDepth
import com.example.prime.model.DeviceActionSuggestion
import com.example.prime.model.DeviceVoiceOption
import com.example.prime.model.GeminiVoicePersona
import com.example.prime.model.MannerProfile
import com.example.prime.model.PrimeMessage
import com.example.prime.model.PrimeSettings
import com.example.prime.model.PrimeSkillCatalog
import com.example.prime.model.SkillCategory
import com.example.prime.model.SkillDefinition
import com.example.prime.model.VocalStylePreset
import com.example.prime.model.VoiceEngineMode
import com.example.prime.model.VoiceState
import com.example.ui.theme.PrimeAmber
import com.example.ui.theme.PrimeBorder
import com.example.ui.theme.PrimeCard
import com.example.ui.theme.PrimeCardElevated
import com.example.ui.theme.PrimeCyan
import com.example.ui.theme.PrimeCyanSoft
import com.example.ui.theme.PrimeGold
import com.example.ui.theme.PrimeGoldSoft
import com.example.ui.theme.PrimeMint
import com.example.ui.theme.PrimeObsidian
import com.example.ui.theme.PrimeRose
import com.example.ui.theme.PrimeSurface
import com.example.ui.theme.PrimeTextPrimary
import com.example.ui.theme.PrimeTextSecondary
import com.example.ui.theme.PrimeTextTertiary
import java.io.File

@Composable
fun PrimeCompanionScreen(
  messages: List<PrimeMessage>,
  settings: PrimeSettings,
  voiceState: VoiceState,
  audioLevel: Float,
  partialTranscript: String,
  draftInput: String,
  attachedImagePath: String?,
  isProcessing: Boolean,
  onDraftChange: (String) -> Unit,
  onSend: (String?) -> Unit,
  onPickImage: () -> Unit,
  onClearImage: () -> Unit,
  onMicTap: () -> Unit,
  onSpeakMessage: (String) -> Unit,
  onStopVoice: () -> Unit,
  onNotify: (String) -> Unit,
) {
  val listState = rememberLazyListState()

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.lastIndex)
    }
  }

  Column(modifier = Modifier.fillMaxSize().imePadding()) {
    PrimeCoreBanner(
      voiceState = voiceState,
      audioLevel = audioLevel,
      partialTranscript = partialTranscript,
      preferredTitle = settings.preferredTitle,
      onOrbTap = onMicTap,
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
    )

    LazyColumn(
      state = listState,
      modifier = Modifier.weight(1f).fillMaxWidth(),
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      items(messages, key = { "${it.id}_${it.timestampMs}_${it.isUser}" }) { msg ->
        PrimeMessageBubble(
          message = msg,
          showReasoning = settings.showReasoningTrace,
          isSpeakingNow = voiceState == VoiceState.SPEAKING,
          onSpeak = { onSpeakMessage(msg.text) },
          onStopSpeaking = onStopVoice,
          onNotify = onNotify,
        )
      }

      if (messages.size <= 1 && !isProcessing) {
        item {
          QuickStarterRow(
            onSelectPrompt = { prompt -> onSend(prompt) },
          )
        }
      }
    }

    if (attachedImagePath != null) {
      AttachedImagePreviewBar(
        imagePath = attachedImagePath,
        onRemove = onClearImage,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
      )
    }

    Surface(
      color = PrimeSurface,
      border = BorderStroke(1.dp, PrimeBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        IconButton(onClick = onPickImage, enabled = !isProcessing) {
          Icon(
            imageVector = Icons.Rounded.Image,
            contentDescription = "Attach image",
            tint = PrimeTextSecondary,
          )
        }

        OutlinedTextField(
          value = draftInput,
          onValueChange = onDraftChange,
          placeholder = {
            Text(
              text = "Ask PRIME anything...",
              color = PrimeTextTertiary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          },
          modifier = Modifier.weight(1f),
          maxLines = 4,
          shape = RoundedCornerShape(22.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedContainerColor = PrimeCard,
              unfocusedContainerColor = PrimeCard,
              focusedBorderColor = PrimeGold.copy(alpha = 0.7f),
              unfocusedBorderColor = PrimeBorder,
              focusedTextColor = PrimeTextPrimary,
              unfocusedTextColor = PrimeTextPrimary,
              cursorColor = PrimeGold,
            ),
        )

        val micTint =
          when (voiceState) {
            VoiceState.LISTENING -> PrimeCyan
            VoiceState.SPEAKING -> PrimeRose
            else -> PrimeGold
          }
        Surface(
          shape = CircleShape,
          color = if (voiceState == VoiceState.LISTENING) PrimeCyanSoft else PrimeGoldSoft,
          modifier = Modifier.size(44.dp),
        ) {
          IconButton(onClick = onMicTap) {
            Icon(
              imageVector = if (voiceState == VoiceState.SPEAKING) Icons.Rounded.Stop else Icons.Rounded.Mic,
              contentDescription = "Voice input",
              tint = micTint,
            )
          }
        }

        Surface(
          shape = CircleShape,
          color = if ((draftInput.isNotBlank() || attachedImagePath != null) && !isProcessing) PrimeGold else PrimeCardElevated,
          modifier = Modifier.size(44.dp),
        ) {
          IconButton(
            onClick = { onSend(null) },
            enabled = (draftInput.isNotBlank() || attachedImagePath != null) && !isProcessing,
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.Send,
              contentDescription = "Send",
              tint =
                if ((draftInput.isNotBlank() || attachedImagePath != null) && !isProcessing)
                  PrimeObsidian
                else PrimeTextTertiary,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun QuickStarterRow(onSelectPrompt: (String) -> Unit) {
  val prompts =
    listOf(
      "Brief me on my agenda & top priorities" to "Give me a polite daily briefing covering my tasks and focus recommendations.",
      "Remember a preference" to "Remember that I prefer concise answers in the morning and deep explanations at night.",
      "Exact compound math" to "Calculate the final balance if I invest 5000 at 7.5% annual compound interest for 6 years.",
      "Set 15m focus timer" to "Prepare a 15 minute deep-work timer for me.",
    )
  Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Text(
      text = "SUGGESTED COMMANDS",
      style = MaterialTheme.typography.labelSmall,
      color = PrimeTextTertiary,
      modifier = Modifier.padding(top = 4.dp),
    )
    Row(
      modifier = Modifier.horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      prompts.forEach { (label, prompt) ->
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = PrimeCard,
          border = BorderStroke(1.dp, PrimeBorder),
          modifier = Modifier.clickable { onSelectPrompt(prompt) },
        ) {
          Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = PrimeGold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun AttachedImagePreviewBar(
  imagePath: String,
  onRemove: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val bitmap = remember(imagePath) { BitmapFactory.decodeFile(imagePath)?.asImageBitmap() }
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = PrimeCardElevated,
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, PrimeBorder),
  ) {
    Row(
      modifier = Modifier.padding(8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      if (bitmap != null) {
        Image(
          bitmap = bitmap,
          contentDescription = "Attached image",
          contentScale = ContentScale.Crop,
          modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)),
        )
      }
      Text(
        text = "Image attached for visual analysis",
        style = MaterialTheme.typography.bodyMedium,
        color = PrimeTextPrimary,
        modifier = Modifier.weight(1f),
      )
      IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
        Icon(Icons.Rounded.Close, contentDescription = "Remove image", tint = PrimeTextSecondary)
      }
    }
  }
}

@Composable
private fun PrimeMessageBubble(
  message: PrimeMessage,
  showReasoning: Boolean,
  isSpeakingNow: Boolean,
  onSpeak: () -> Unit,
  onStopSpeaking: () -> Unit,
  onNotify: (String) -> Unit,
) {
  val context = LocalContext.current
  val uriHandler = LocalUriHandler.current
  val clipboard = LocalClipboardManager.current
  var traceExpanded by remember(message.id) { mutableStateOf(false) }

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
  ) {
    val containerColor =
      when {
        message.isError -> PrimeRose.copy(alpha = 0.14f)
        message.isUser -> PrimeCardElevated
        else -> PrimeCard
      }
    val borderColor =
      when {
        message.isError -> PrimeRose.copy(alpha = 0.5f)
        message.isUser -> PrimeGold.copy(alpha = 0.35f)
        else -> PrimeBorder
      }

    Surface(
      color = containerColor,
      shape =
        RoundedCornerShape(
          topStart = 18.dp,
          topEnd = 18.dp,
          bottomStart = if (message.isUser) 18.dp else 4.dp,
          bottomEnd = if (message.isUser) 4.dp else 18.dp,
        ),
      border = BorderStroke(1.dp, borderColor),
      modifier = Modifier.widthIn(max = 336.dp),
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!message.isUser) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              Icon(
                imageVector = Icons.Rounded.AutoAwesome,
                contentDescription = null,
                tint = PrimeGold,
                modifier = Modifier.size(15.dp),
              )
              Text(
                text = "PRIME",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = PrimeGold,
              )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
              IconButton(
                onClick = { if (isSpeakingNow) onStopSpeaking() else onSpeak() },
                modifier = Modifier.size(28.dp),
              ) {
                Icon(
                  imageVector = if (isSpeakingNow) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                  contentDescription = "Speak reply",
                  tint = PrimeTextSecondary,
                  modifier = Modifier.size(17.dp),
                )
              }
              IconButton(
                onClick = {
                  clipboard.setText(AnnotatedString(message.text))
                  onNotify("Copied to clipboard.")
                },
                modifier = Modifier.size(28.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.ContentCopy,
                  contentDescription = "Copy",
                  tint = PrimeTextSecondary,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
          }
        }

        if (message.imageUriString != null) {
          val bmp =
            remember(message.imageUriString) {
              runCatching {
                  val f = File(message.imageUriString)
                  if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
                }
                .getOrNull()
            }
          if (bmp != null) {
            Image(
              bitmap = bmp,
              contentDescription = "User attachment",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)),
            )
          }
        }

        if (!message.isUser && showReasoning && !message.reasoningTrace.isNullOrBlank()) {
          Surface(
            color = PrimeSurface,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, PrimeBorder),
            modifier = Modifier.fillMaxWidth().clickable { traceExpanded = !traceExpanded },
          ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.Psychology,
                    contentDescription = null,
                    tint = PrimeCyan,
                    modifier = Modifier.size(15.dp),
                  )
                  Text(
                    text = "Human Brain Reflection",
                    style = MaterialTheme.typography.labelMedium,
                    color = PrimeCyan,
                  )
                }
                Icon(
                  imageVector = if (traceExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                  contentDescription = null,
                  tint = PrimeTextSecondary,
                  modifier = Modifier.size(18.dp),
                )
              }
              AnimatedVisibility(visible = traceExpanded) {
                Text(
                  text = message.reasoningTrace,
                  style = MaterialTheme.typography.bodyMedium,
                  color = PrimeTextSecondary,
                  fontStyle = FontStyle.Italic,
                  modifier = Modifier.padding(top = 6.dp),
                )
              }
            }
          }
        }

        Text(
          text = message.text,
          style = MaterialTheme.typography.bodyLarge,
          color = if (message.isError) PrimeRose else PrimeTextPrimary,
        )

        if (message.toolActions.isNotEmpty()) {
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            message.toolActions.forEach { badge ->
              Surface(
                color = PrimeMint.copy(alpha = 0.12f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, PrimeMint.copy(alpha = 0.35f)),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.Build,
                    contentDescription = null,
                    tint = PrimeMint,
                    modifier = Modifier.size(13.dp),
                  )
                  Text(
                    text = "${badge.toolName}: ${badge.summary}",
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimeMint,
                  )
                }
              }
            }
          }
        }

        if (message.deviceAction != null) {
          DeviceActionCard(
            suggestion = message.deviceAction,
            onLaunch = {
              PrimeDeviceActions.launch(context, message.deviceAction)
                .onSuccess { msg -> onNotify(msg) }
                .onFailure { onNotify("No compatible app found for ${message.deviceAction.label}.") }
            },
          )
        }

        if (message.sources.isNotEmpty()) {
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = "VERIFIED SOURCES",
              style = MaterialTheme.typography.labelSmall,
              color = PrimeTextTertiary,
            )
            Row(
              modifier = Modifier.horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              message.sources.forEach { src ->
                Surface(
                  color = PrimeCyanSoft,
                  shape = RoundedCornerShape(8.dp),
                  border = BorderStroke(1.dp, PrimeCyan.copy(alpha = 0.4f)),
                  modifier = Modifier.clickable { runCatching { uriHandler.openUri(src.uri) } },
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.Public,
                      contentDescription = null,
                      tint = PrimeCyan,
                      modifier = Modifier.size(13.dp),
                    )
                    Text(
                      text = src.title.take(28),
                      style = MaterialTheme.typography.labelSmall,
                      color = PrimeCyan,
                      maxLines = 1,
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DeviceActionCard(suggestion: DeviceActionSuggestion, onLaunch: () -> Unit) {
  val icon =
    when (suggestion.actionType.uppercase()) {
      "ALARM" -> Icons.Rounded.Alarm
      "TIMER" -> Icons.Rounded.Timer
      "EMAIL" -> Icons.Rounded.Email
      else -> Icons.Rounded.Share
    }
  Button(
    onClick = onLaunch,
    colors =
      ButtonDefaults.buttonColors(
        containerColor = PrimeGold,
        contentColor = PrimeObsidian,
      ),
    shape = RoundedCornerShape(12.dp),
    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
  ) {
    Icon(icon, contentDescription = null, modifier = Modifier.size(17.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Text(text = suggestion.label, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
fun PrimeSkillsScreen(
  onActivateSkill: (SkillDefinition) -> Unit,
) {
  var selectedCategory by remember { mutableStateOf(SkillCategory.ALL) }
  val filtered =
    remember(selectedCategory) {
      if (selectedCategory == SkillCategory.ALL) PrimeSkillCatalog.skills
      else PrimeSkillCatalog.skills.filter { it.category == selectedCategory }
    }

  Column(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
      Text(
        text = "Multi-Skill Matrix",
        style = MaterialTheme.typography.headlineSmall,
        color = PrimeTextPrimary,
      )
      Text(
        text = "Tap any discipline to engage PRIME's specialized reasoning.",
        style = MaterialTheme.typography.bodyMedium,
        color = PrimeTextSecondary,
      )
    }

    Row(
      modifier = Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      SkillCategory.entries.forEach { cat ->
        FilterChip(
          selected = selectedCategory == cat,
          onClick = { selectedCategory = cat },
          label = { Text(cat.label) },
          colors =
            FilterChipDefaults.filterChipColors(
              selectedContainerColor = PrimeGoldSoft,
              selectedLabelColor = PrimeGold,
              containerColor = PrimeCard,
              labelColor = PrimeTextSecondary,
            ),
          border =
            FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = selectedCategory == cat,
              borderColor = PrimeBorder,
              selectedBorderColor = PrimeGold,
            ),
        )
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      items(filtered, key = { it.id }) { skill ->
        val icon =
          when (skill.category) {
            SkillCategory.COGNITION -> Icons.Rounded.Psychology
            SkillCategory.PRODUCTIVITY -> Icons.Rounded.TaskAlt
            SkillCategory.TECHNICAL -> Icons.Rounded.Code
            SkillCategory.CREATIVE -> Icons.Rounded.Language
            SkillCategory.ALL -> Icons.Rounded.AutoAwesome
          }
        Surface(
          color = PrimeCard,
          shape = RoundedCornerShape(16.dp),
          border = BorderStroke(1.dp, PrimeBorder),
          modifier = Modifier.fillMaxWidth().clickable { onActivateSkill(skill) },
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (skill.requiresDeepBrain) PrimeCyanSoft else PrimeGoldSoft,
              modifier = Modifier.size(44.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = icon,
                  contentDescription = null,
                  tint = if (skill.requiresDeepBrain) PrimeCyan else PrimeGold,
                )
              }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Text(
                  text = skill.name,
                  style = MaterialTheme.typography.titleMedium,
                  color = PrimeTextPrimary,
                  modifier = Modifier.weight(1f, fill = false),
                )
                if (skill.requiresDeepBrain) {
                  Surface(
                    color = PrimeCyanSoft,
                    shape = RoundedCornerShape(6.dp),
                  ) {
                    Text(
                      text = "DEEP BRAIN",
                      style = MaterialTheme.typography.labelSmall,
                      color = PrimeCyan,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                  }
                }
              }
              Text(
                text = skill.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = PrimeTextSecondary,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun PrimeVaultScreen(
  tasks: List<TaskEntity>,
  memories: List<MemoryEntity>,
  onAddTask: (title: String, priority: String, dueNote: String) -> Unit,
  onToggleTask: (TaskEntity) -> Unit,
  onDeleteTask: (TaskEntity) -> Unit,
  onAddMemory: (category: String, fact: String) -> Unit,
  onDeleteMemory: (MemoryEntity) -> Unit,
  onClearMemories: () -> Unit,
) {
  var showTasksTab by remember { mutableStateOf(true) }
  var showAddTaskDialog by remember { mutableStateOf(false) }
  var showAddMemoryDialog by remember { mutableStateOf(false) }
  var showClearConfirm by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize()) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(
          text = if (showTasksTab) "Executive Agenda" else "Memory Vault",
          style = MaterialTheme.typography.headlineSmall,
          color = PrimeTextPrimary,
        )
        Text(
          text =
            if (showTasksTab) "${tasks.count { !it.isCompleted }} pending tasks"
            else "${memories.size} long-term personal facts",
          style = MaterialTheme.typography.bodyMedium,
          color = PrimeTextSecondary,
        )
      }
      Button(
        onClick = { if (showTasksTab) showAddTaskDialog = true else showAddMemoryDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = PrimeGold, contentColor = PrimeObsidian),
        shape = RoundedCornerShape(12.dp),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(if (showTasksTab) "Task" else "Fact")
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      FilterChip(
        selected = showTasksTab,
        onClick = { showTasksTab = true },
        label = { Text("Agenda (${tasks.count { !it.isCompleted }})") },
        modifier = Modifier.weight(1f),
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = PrimeGoldSoft,
            selectedLabelColor = PrimeGold,
            containerColor = PrimeCard,
            labelColor = PrimeTextSecondary,
          ),
      )
      FilterChip(
        selected = !showTasksTab,
        onClick = { showTasksTab = false },
        label = { Text("Memory (${memories.size})") },
        modifier = Modifier.weight(1f),
        colors =
          FilterChipDefaults.filterChipColors(
            selectedContainerColor = PrimeCyanSoft,
            selectedLabelColor = PrimeCyan,
            containerColor = PrimeCard,
            labelColor = PrimeTextSecondary,
          ),
      )
    }

    if (showTasksTab) {
      if (tasks.isEmpty()) {
        VaultEmptyState(
          icon = Icons.Rounded.TaskAlt,
          title = "Agenda is clear",
          subtitle = "Ask PRIME in chat to add reminders, or tap + Task above.",
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(tasks, key = { it.id }) { task ->
            Surface(
              color = PrimeCard,
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(1.dp, PrimeBorder),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                IconButton(onClick = { onToggleTask(task) }, modifier = Modifier.size(32.dp)) {
                  Icon(
                    imageVector =
                      if (task.isCompleted) Icons.Rounded.CheckCircle
                      else Icons.Rounded.RadioButtonUnchecked,
                    contentDescription = "Toggle task",
                    tint = if (task.isCompleted) PrimeMint else PrimeGold,
                  )
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (task.isCompleted) PrimeTextTertiary else PrimeTextPrimary,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null,
                  )
                  Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                      text = task.priority,
                      style = MaterialTheme.typography.labelSmall,
                      color =
                        if (task.priority.equals("High", ignoreCase = true)) PrimeAmber
                        else PrimeCyan,
                    )
                    if (task.dueNote.isNotBlank()) {
                      Text(
                        text = "• ${task.dueNote}",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimeTextSecondary,
                      )
                    }
                  }
                }
                IconButton(onClick = { onDeleteTask(task) }, modifier = Modifier.size(32.dp)) {
                  Icon(
                    Icons.Rounded.DeleteOutline,
                    contentDescription = "Delete task",
                    tint = PrimeTextTertiary,
                  )
                }
              }
            }
          }
        }
      }
    } else {
      if (memories.isEmpty()) {
        VaultEmptyState(
          icon = Icons.Rounded.Bookmark,
          title = "Memory Vault is empty",
          subtitle = "Tell PRIME your preferences, routines, or goals and it will remember them.",
        )
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          items(memories, key = { it.id }) { mem ->
            Surface(
              color = PrimeCard,
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(1.dp, PrimeBorder),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    text = mem.category.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimeCyan,
                  )
                  Text(
                    text = mem.fact,
                    style = MaterialTheme.typography.bodyMedium,
                    color = PrimeTextPrimary,
                  )
                }
                IconButton(onClick = { onDeleteMemory(mem) }, modifier = Modifier.size(32.dp)) {
                  Icon(
                    Icons.Rounded.DeleteOutline,
                    contentDescription = "Delete memory",
                    tint = PrimeTextTertiary,
                  )
                }
              }
            }
          }
          item {
            OutlinedButton(
              onClick = { showClearConfirm = true },
              border = BorderStroke(1.dp, PrimeRose.copy(alpha = 0.5f)),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimeRose),
              modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            ) {
              Text("Clear Memory Vault")
            }
          }
        }
      }
    }
  }

  if (showAddTaskDialog) {
    AddTaskDialog(
      onDismiss = { showAddTaskDialog = false },
      onSave = { title, priority, due ->
        onAddTask(title, priority, due)
        showAddTaskDialog = false
      },
    )
  }

  if (showAddMemoryDialog) {
    AddMemoryDialog(
      onDismiss = { showAddMemoryDialog = false },
      onSave = { cat, fact ->
        onAddMemory(cat, fact)
        showAddMemoryDialog = false
      },
    )
  }

  if (showClearConfirm) {
    AlertDialog(
      onDismissRequest = { showClearConfirm = false },
      containerColor = PrimeCard,
      title = { Text("Clear Memory Vault?", color = PrimeTextPrimary) },
      text = {
        Text(
          "This removes all saved personal facts. PRIME will remain courteous and ready to learn anew.",
          color = PrimeTextSecondary,
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            onClearMemories()
            showClearConfirm = false
          }
        ) {
          Text("Clear", color = PrimeRose)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirm = false }) {
          Text("Cancel", color = PrimeTextSecondary)
        }
      },
    )
  }
}

@Composable
private fun VaultEmptyState(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  subtitle: String,
) {
  Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(icon, contentDescription = null, tint = PrimeGold.copy(alpha = 0.7f), modifier = Modifier.size(44.dp))
      Text(title, style = MaterialTheme.typography.titleMedium, color = PrimeTextPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = PrimeTextSecondary)
    }
  }
}

@Composable
private fun AddTaskDialog(
  onDismiss: () -> Unit,
  onSave: (title: String, priority: String, dueNote: String) -> Unit,
) {
  var title by remember { mutableStateOf("") }
  var dueNote by remember { mutableStateOf("") }
  var priority by remember { mutableStateOf("Normal") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = PrimeCard,
    title = { Text("Add Agenda Task", color = PrimeTextPrimary) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Task title") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = dueNote,
          onValueChange = { dueNote = it },
          label = { Text("Due / note (optional)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("High", "Normal", "Low").forEach { level ->
            FilterChip(
              selected = priority == level,
              onClick = { priority = level },
              label = { Text(level) },
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { if (title.isNotBlank()) onSave(title, priority, dueNote) },
        colors = ButtonDefaults.buttonColors(containerColor = PrimeGold, contentColor = PrimeObsidian),
      ) {
        Text("Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel", color = PrimeTextSecondary) }
    },
  )
}

@Composable
private fun AddMemoryDialog(
  onDismiss: () -> Unit,
  onSave: (category: String, fact: String) -> Unit,
) {
  var category by remember { mutableStateOf("Preference") }
  var fact by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = PrimeCard,
    title = { Text("Store Personal Fact", color = PrimeTextPrimary) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          listOf("Preference", "Goal", "Identity", "Routine", "Note").forEach { cat ->
            FilterChip(
              selected = category == cat,
              onClick = { category = cat },
              label = { Text(cat) },
            )
          }
        }
        OutlinedTextField(
          value = fact,
          onValueChange = { fact = it },
          label = { Text("What should PRIME remember?") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { if (fact.isNotBlank()) onSave(category, fact) },
        colors = ButtonDefaults.buttonColors(containerColor = PrimeGold, contentColor = PrimeObsidian),
      ) {
        Text("Remember")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel", color = PrimeTextSecondary) }
    },
  )
}

@Composable
fun PrimeStudioScreen(
  settings: PrimeSettings,
  voiceProfiles: List<VoiceProfileEntity>,
  availableDeviceVoices: List<DeviceVoiceOption>,
  openVoiceCreatorOnLaunch: Boolean,
  onConsumeOpenVoiceCreator: () -> Unit,
  onUpdateSettings: ((PrimeSettings) -> PrimeSettings) -> Unit,
  onPreviewCustomVoice: (
    engineMode: VoiceEngineMode,
    geminiPersona: GeminiVoicePersona,
    vocalStyle: VocalStylePreset,
    deviceLocaleTag: String,
    deviceVoiceName: String,
    pitch: Float,
    speechRate: Float,
    samplePhrase: String,
  ) -> Unit,
  onSaveVoiceProfile: (
    editingId: Long?,
    name: String,
    engineMode: VoiceEngineMode,
    geminiPersona: GeminiVoicePersona,
    vocalStyle: VocalStylePreset,
    deviceLocaleTag: String,
    deviceVoiceName: String,
    pitch: Float,
    speechRate: Float,
    samplePhrase: String,
  ) -> Unit,
  onActivateVoiceProfile: (VoiceProfileEntity) -> Unit,
  onDeleteVoiceProfile: (VoiceProfileEntity) -> Unit,
  onTestGreetingVoice: () -> Unit,
  onClearChat: () -> Unit,
) {
  var showVoiceCreator by remember { mutableStateOf(false) }
  var editingVoiceProfile by remember { mutableStateOf<VoiceProfileEntity?>(null) }

  LaunchedEffect(openVoiceCreatorOnLaunch) {
    if (openVoiceCreatorOnLaunch) {
      editingVoiceProfile = null
      showVoiceCreator = true
      onConsumeOpenVoiceCreator()
    }
  }

  Column(
    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    Column {
      Text(
        text = "Persona & Voice Studio",
        style = MaterialTheme.typography.headlineSmall,
        color = PrimeTextPrimary,
      )
      Text(
        text = "Create custom voices and shape how PRIME addresses you and speaks.",
        style = MaterialTheme.typography.bodyMedium,
        color = PrimeTextSecondary,
      )
    }

    // Custom Voice Creator & Library
    StudioSectionCard(title = "VOICE CREATOR & SAVED VOICES") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
          Text(
            text =
              settings.activeCustomVoiceName?.let { "Active: $it" }
                ?: "Active: ${settings.voiceEngine.label}",
            style = MaterialTheme.typography.titleSmall,
            color = PrimeTextPrimary,
          )
          Text(
            text = "Craft your own signature voice with custom pitch, cadence, accent, or neural persona.",
            style = MaterialTheme.typography.bodyMedium,
            color = PrimeTextSecondary,
          )
        }
        Button(
          onClick = {
            editingVoiceProfile = null
            showVoiceCreator = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = PrimeGold, contentColor = PrimeObsidian),
          shape = RoundedCornerShape(12.dp),
        ) {
          Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Create Voice")
        }
      }

      if (voiceProfiles.isNotEmpty()) {
        HorizontalDivider(color = PrimeBorder)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          voiceProfiles.forEach { profile ->
            val isActive = settings.activeCustomVoiceId == profile.id
            val isNeural = profile.engineMode == VoiceEngineMode.GEMINI_NEURAL_TTS.name
            val styleLabel =
              VocalStylePreset.entries.firstOrNull { it.name == profile.vocalStyle }?.label ?: "Natural"
            val summary =
              if (isNeural) {
                "Neural • ${profile.geminiPersona} • $styleLabel"
              } else {
                "Device (${profile.deviceLocaleTag}) • Pitch ${String.format(java.util.Locale.US, "%.2f", profile.pitch)} • Rate ${String.format(java.util.Locale.US, "%.2f", profile.speechRate)}x"
              }

            Surface(
              color = if (isActive) PrimeGoldSoft else PrimeSurface,
              shape = RoundedCornerShape(12.dp),
              border = BorderStroke(1.dp, if (isActive) PrimeGold else PrimeBorder),
              modifier = Modifier.fillMaxWidth().clickable { onActivateVoiceProfile(profile) },
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.GraphicEq,
                  contentDescription = null,
                  tint = if (isActive) PrimeGold else PrimeCyan,
                  modifier = Modifier.size(22.dp),
                )
                Column(modifier = Modifier.weight(1f)) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                  ) {
                    Text(
                      text = profile.name,
                      style = MaterialTheme.typography.titleSmall,
                      color = if (isActive) PrimeGold else PrimeTextPrimary,
                    )
                    if (isActive) {
                      Surface(color = PrimeGold, shape = RoundedCornerShape(6.dp)) {
                        Text(
                          text = "ACTIVE",
                          style = MaterialTheme.typography.labelSmall,
                          color = PrimeObsidian,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                        )
                      }
                    }
                  }
                  Text(
                    text = summary,
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimeTextSecondary,
                  )
                }
                IconButton(
                  onClick = { onActivateVoiceProfile(profile) },
                  modifier = Modifier.size(32.dp),
                ) {
                  Icon(
                    Icons.Rounded.PlayArrow,
                    contentDescription = "Preview and activate",
                    tint = PrimeGold,
                  )
                }
                IconButton(
                  onClick = {
                    editingVoiceProfile = profile
                    showVoiceCreator = true
                  },
                  modifier = Modifier.size(32.dp),
                ) {
                  Icon(
                    Icons.Rounded.Edit,
                    contentDescription = "Edit voice",
                    tint = PrimeTextSecondary,
                    modifier = Modifier.size(18.dp),
                  )
                }
                IconButton(
                  onClick = { onDeleteVoiceProfile(profile) },
                  modifier = Modifier.size(32.dp),
                ) {
                  Icon(
                    Icons.Rounded.DeleteOutline,
                    contentDescription = "Delete voice",
                    tint = PrimeTextTertiary,
                    modifier = Modifier.size(18.dp),
                  )
                }
              }
            }
          }
        }
      }
    }

    // Addressing & Title
    StudioSectionCard(title = "HOW PRIME ADDRESSES YOU") {
      OutlinedTextField(
        value = settings.preferredTitle,
        onValueChange = { value -> onUpdateSettings { it.copy(preferredTitle = value) } },
        label = { Text("Preferred Title or Name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedBorderColor = PrimeGold,
            unfocusedBorderColor = PrimeBorder,
            focusedTextColor = PrimeTextPrimary,
            unfocusedTextColor = PrimeTextPrimary,
          ),
      )
      Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        listOf("Sir", "Ma'am", "Chief", "Partner", "Friend").forEach { titleOption ->
          FilterChip(
            selected = settings.preferredTitle == titleOption,
            onClick = { onUpdateSettings { it.copy(preferredTitle = titleOption) } },
            label = { Text(titleOption) },
          )
        }
      }
    }

    // Manners & Talking Style
    StudioSectionCard(title = "MANNERS & CONVERSATION STYLE") {
      MannerProfile.entries.forEach { profile ->
        val selected = settings.mannerProfile == profile
        Surface(
          color = if (selected) PrimeGoldSoft else PrimeSurface,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, if (selected) PrimeGold else PrimeBorder),
          modifier =
            Modifier.fillMaxWidth().clickable {
              onUpdateSettings { it.copy(mannerProfile = profile) }
            },
        ) {
          Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = profile.title,
              style = MaterialTheme.typography.titleSmall,
              color = if (selected) PrimeGold else PrimeTextPrimary,
            )
            Text(
              text = profile.subtitle,
              style = MaterialTheme.typography.bodyMedium,
              color = PrimeTextSecondary,
            )
            Text(
              text = "\"${profile.sampleQuote}\"",
              style = MaterialTheme.typography.labelMedium,
              fontStyle = FontStyle.Italic,
              color = PrimeCyan,
            )
          }
        }
      }
    }

    // Brain & Cognition
    StudioSectionCard(title = "HUMAN BRAIN & COGNITION") {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        BrainDepth.entries.forEach { depth ->
          val selected = settings.brainDepth == depth
          Surface(
            color = if (selected) PrimeCyanSoft else PrimeSurface,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (selected) PrimeCyan else PrimeBorder),
            modifier =
              Modifier.weight(1f).clickable {
                onUpdateSettings { it.copy(brainDepth = depth) }
              },
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
              Text(
                text = depth.label,
                style = MaterialTheme.typography.titleSmall,
                color = if (selected) PrimeCyan else PrimeTextPrimary,
              )
              Text(
                text = depth.description,
                style = MaterialTheme.typography.labelSmall,
                color = PrimeTextSecondary,
              )
            }
          }
        }
      }

      StudioSwitchRow(
        title = "Live Web Search Grounding",
        subtitle = "Consult current web sources with citations",
        checked = settings.webSearchEnabled,
        onCheckedChange = { checked -> onUpdateSettings { it.copy(webSearchEnabled = checked) } },
      )
      StudioSwitchRow(
        title = "Human Brain Reflection Trace",
        subtitle = "Show PRIME's internal empathetic reasoning",
        checked = settings.showReasoningTrace,
        onCheckedChange = { checked -> onUpdateSettings { it.copy(showReasoningTrace = checked) } },
      )
    }

    // Voice & Greeting Studio
    StudioSectionCard(title = "VOICE & GREETING STUDIO") {
      StudioSwitchRow(
        title = "Speak Time-of-Day Greeting on Launch",
        subtitle = "Warm spoken welcome whenever PRIME opens",
        checked = settings.autoSpeakGreeting,
        onCheckedChange = { checked -> onUpdateSettings { it.copy(autoSpeakGreeting = checked) } },
      )
      StudioSwitchRow(
        title = "Auto-Speak All Replies",
        subtitle = "Hands-free spoken conversation",
        checked = settings.autoSpeakReplies,
        onCheckedChange = { checked -> onUpdateSettings { it.copy(autoSpeakReplies = checked) } },
      )

      HorizontalDivider(color = PrimeBorder)

      Text("Voice Engine", style = MaterialTheme.typography.titleSmall, color = PrimeTextPrimary)
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        VoiceEngineMode.entries.forEach { mode ->
          val selected = settings.voiceEngine == mode
          Surface(
            color = if (selected) PrimeGoldSoft else PrimeSurface,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (selected) PrimeGold else PrimeBorder),
            modifier =
              Modifier.weight(1f).clickable {
                onUpdateSettings {
                  it.copy(voiceEngine = mode, activeCustomVoiceId = null, activeCustomVoiceName = null)
                }
              },
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = mode.label,
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) PrimeGold else PrimeTextPrimary,
              )
              Text(
                text = mode.description,
                style = MaterialTheme.typography.labelSmall,
                color = PrimeTextSecondary,
              )
            }
          }
        }
      }

      if (settings.voiceEngine == VoiceEngineMode.GEMINI_NEURAL_TTS) {
        Text("Neural Voice Persona", style = MaterialTheme.typography.titleSmall, color = PrimeTextPrimary)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          GeminiVoicePersona.entries.forEach { persona ->
            FilterChip(
              selected = settings.geminiVoicePersona == persona,
              onClick = {
                onUpdateSettings {
                  it.copy(
                    geminiVoicePersona = persona,
                    activeCustomVoiceId = null,
                    activeCustomVoiceName = null,
                  )
                }
              },
              label = { Text(persona.label) },
            )
          }
        }
        Text(
          text = settings.geminiVoicePersona.tone,
          style = MaterialTheme.typography.labelMedium,
          color = PrimeCyan,
        )

        Text("Vocal Cadence & Style", style = MaterialTheme.typography.titleSmall, color = PrimeTextPrimary)
        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          VocalStylePreset.entries.forEach { style ->
            FilterChip(
              selected = settings.vocalStyle == style,
              onClick = {
                onUpdateSettings {
                  it.copy(vocalStyle = style, activeCustomVoiceId = null, activeCustomVoiceName = null)
                }
              },
              label = { Text(style.label) },
            )
          }
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text("Accent / Region", style = MaterialTheme.typography.titleSmall, color = PrimeTextPrimary)
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            listOf("en-GB" to "British", "en-US" to "American", "en-AU" to "Australian", "auto" to "System")
              .forEach { (tag, label) ->
                FilterChip(
                  selected = settings.deviceLocaleTag == tag && settings.deviceVoiceName.isBlank(),
                  onClick = {
                    onUpdateSettings {
                      it.copy(
                        deviceLocaleTag = tag,
                        deviceVoiceName = "",
                        activeCustomVoiceId = null,
                        activeCustomVoiceName = null,
                      )
                    }
                  },
                  label = { Text(label) },
                )
              }
          }

          if (availableDeviceVoices.isNotEmpty()) {
            Text(
              "Installed Device Voices",
              style = MaterialTheme.typography.titleSmall,
              color = PrimeTextPrimary,
            )
            Row(
              modifier = Modifier.horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              availableDeviceVoices.forEach { voiceOpt ->
                FilterChip(
                  selected = settings.deviceVoiceName == voiceOpt.name,
                  onClick = {
                    onUpdateSettings {
                      it.copy(
                        deviceVoiceName = voiceOpt.name,
                        deviceLocaleTag = voiceOpt.localeTag,
                        activeCustomVoiceId = null,
                        activeCustomVoiceName = null,
                      )
                    }
                  },
                  label = { Text(voiceOpt.label) },
                )
              }
            }
          }

          Text(
            text = "Device Pitch (${String.format(java.util.Locale.US, "%.2f", settings.devicePitch)})",
            style = MaterialTheme.typography.labelMedium,
            color = PrimeTextSecondary,
          )
          Slider(
            value = settings.devicePitch,
            onValueChange = { v -> onUpdateSettings { it.copy(devicePitch = v) } },
            valueRange = 0.65f..1.35f,
            colors = SliderDefaults.colors(thumbColor = PrimeGold, activeTrackColor = PrimeGold),
          )
          Text(
            text = "Speech Rate (${String.format(java.util.Locale.US, "%.2f", settings.deviceSpeechRate)}x)",
            style = MaterialTheme.typography.labelMedium,
            color = PrimeTextSecondary,
          )
          Slider(
            value = settings.deviceSpeechRate,
            onValueChange = { v -> onUpdateSettings { it.copy(deviceSpeechRate = v) } },
            valueRange = 0.70f..1.40f,
            colors = SliderDefaults.colors(thumbColor = PrimeCyan, activeTrackColor = PrimeCyan),
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Button(
          onClick = onTestGreetingVoice,
          colors = ButtonDefaults.buttonColors(containerColor = PrimeGold, contentColor = PrimeObsidian),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.weight(1f),
        ) {
          Icon(Icons.Rounded.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Hear Greeting")
        }
        OutlinedButton(
          onClick = onClearChat,
          border = BorderStroke(1.dp, PrimeBorder),
          shape = RoundedCornerShape(12.dp),
        ) {
          Text("Reset Chat", color = PrimeTextSecondary)
        }
      }
    }
  }

  if (showVoiceCreator) {
    CreateVoiceDialog(
      initialProfile = editingVoiceProfile,
      currentSettings = settings,
      availableDeviceVoices = availableDeviceVoices,
      onDismiss = { showVoiceCreator = false },
      onPreview = onPreviewCustomVoice,
      onSave = { name, engine, persona, style, localeTag, voiceName, pitch, rate, phrase ->
        onSaveVoiceProfile(
          editingVoiceProfile?.id,
          name,
          engine,
          persona,
          style,
          localeTag,
          voiceName,
          pitch,
          rate,
          phrase,
        )
        showVoiceCreator = false
      },
    )
  }
}

@Composable
private fun CreateVoiceDialog(
  initialProfile: VoiceProfileEntity?,
  currentSettings: PrimeSettings,
  availableDeviceVoices: List<DeviceVoiceOption>,
  onDismiss: () -> Unit,
  onPreview: (
    engineMode: VoiceEngineMode,
    geminiPersona: GeminiVoicePersona,
    vocalStyle: VocalStylePreset,
    deviceLocaleTag: String,
    deviceVoiceName: String,
    pitch: Float,
    speechRate: Float,
    samplePhrase: String,
  ) -> Unit,
  onSave: (
    name: String,
    engineMode: VoiceEngineMode,
    geminiPersona: GeminiVoicePersona,
    vocalStyle: VocalStylePreset,
    deviceLocaleTag: String,
    deviceVoiceName: String,
    pitch: Float,
    speechRate: Float,
    samplePhrase: String,
  ) -> Unit,
) {
  var name by remember { mutableStateOf(initialProfile?.name ?: "") }
  var engineMode by remember {
    mutableStateOf(
      initialProfile?.let { p ->
        VoiceEngineMode.entries.firstOrNull { it.name == p.engineMode }
      } ?: currentSettings.voiceEngine
    )
  }
  var geminiPersona by remember {
    mutableStateOf(
      initialProfile?.let { p ->
        GeminiVoicePersona.entries.firstOrNull { it.name == p.geminiPersona }
      } ?: currentSettings.geminiVoicePersona
    )
  }
  var vocalStyle by remember {
    mutableStateOf(
      initialProfile?.let { p ->
        VocalStylePreset.entries.firstOrNull { it.name == p.vocalStyle }
      } ?: currentSettings.vocalStyle
    )
  }
  var deviceLocaleTag by remember {
    mutableStateOf(initialProfile?.deviceLocaleTag ?: currentSettings.deviceLocaleTag)
  }
  var deviceVoiceName by remember {
    mutableStateOf(initialProfile?.deviceVoiceName ?: currentSettings.deviceVoiceName)
  }
  var pitch by remember { mutableStateOf(initialProfile?.pitch ?: currentSettings.devicePitch) }
  var speechRate by remember {
    mutableStateOf(initialProfile?.speechRate ?: currentSettings.deviceSpeechRate)
  }
  var samplePhrase by remember {
    mutableStateOf(
      initialProfile?.samplePhrase
        ?: "Good evening, ${currentSettings.preferredTitle.ifBlank { "friend" }}. My custom voice is calibrated and at your service."
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = PrimeCard,
    title = {
      Text(
        text = if (initialProfile == null) "Create Custom Voice" else "Edit Voice",
        color = PrimeTextPrimary,
      )
    },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Voice Name (e.g., Jarvis Classic, Athena)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )

        Row(
          modifier = Modifier.horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          listOf("Jarvis Classic", "Athena", "Nova", "Arthur", "Aria").forEach { presetName ->
            FilterChip(
              selected = name == presetName,
              onClick = { name = presetName },
              label = { Text(presetName) },
            )
          }
        }

        Text("Engine", style = MaterialTheme.typography.labelMedium, color = PrimeGold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          VoiceEngineMode.entries.forEach { mode ->
            FilterChip(
              selected = engineMode == mode,
              onClick = { engineMode = mode },
              label = {
                Text(
                  if (mode == VoiceEngineMode.DEVICE_TTS) "Device Voice" else "Neural AI",
                  maxLines = 1,
                )
              },
              modifier = Modifier.weight(1f),
            )
          }
        }

        if (engineMode == VoiceEngineMode.GEMINI_NEURAL_TTS) {
          Text("Neural Base Persona", style = MaterialTheme.typography.labelMedium, color = PrimeCyan)
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            GeminiVoicePersona.entries.forEach { persona ->
              FilterChip(
                selected = geminiPersona == persona,
                onClick = { geminiPersona = persona },
                label = { Text(persona.label) },
              )
            }
          }
          Text(
            text = geminiPersona.tone,
            style = MaterialTheme.typography.labelSmall,
            color = PrimeTextSecondary,
          )

          Text("Vocal Style & Cadence", style = MaterialTheme.typography.labelMedium, color = PrimeCyan)
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            VocalStylePreset.entries.forEach { style ->
              FilterChip(
                selected = vocalStyle == style,
                onClick = { vocalStyle = style },
                label = { Text(style.label) },
              )
            }
          }
        } else {
          Text("Accent / Region", style = MaterialTheme.typography.labelMedium, color = PrimeCyan)
          Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            listOf("en-GB" to "UK", "en-US" to "US", "en-AU" to "AU", "auto" to "System")
              .forEach { (tag, label) ->
                FilterChip(
                  selected = deviceLocaleTag == tag && deviceVoiceName.isBlank(),
                  onClick = {
                    deviceLocaleTag = tag
                    deviceVoiceName = ""
                  },
                  label = { Text(label) },
                )
              }
          }

          if (availableDeviceVoices.isNotEmpty()) {
            Text(
              "Specific Device Voice",
              style = MaterialTheme.typography.labelMedium,
              color = PrimeCyan,
            )
            Row(
              modifier = Modifier.horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              availableDeviceVoices.forEach { voiceOpt ->
                FilterChip(
                  selected = deviceVoiceName == voiceOpt.name,
                  onClick = {
                    deviceVoiceName = voiceOpt.name
                    deviceLocaleTag = voiceOpt.localeTag
                  },
                  label = { Text(voiceOpt.label) },
                )
              }
            }
          }

          Text(
            text = "Pitch (${String.format(java.util.Locale.US, "%.2f", pitch)})",
            style = MaterialTheme.typography.labelMedium,
            color = PrimeTextSecondary,
          )
          Slider(
            value = pitch,
            onValueChange = { pitch = it },
            valueRange = 0.65f..1.35f,
            colors = SliderDefaults.colors(thumbColor = PrimeGold, activeTrackColor = PrimeGold),
          )

          Text(
            text = "Speech Rate (${String.format(java.util.Locale.US, "%.2f", speechRate)}x)",
            style = MaterialTheme.typography.labelMedium,
            color = PrimeTextSecondary,
          )
          Slider(
            value = speechRate,
            onValueChange = { speechRate = it },
            valueRange = 0.70f..1.40f,
            colors = SliderDefaults.colors(thumbColor = PrimeCyan, activeTrackColor = PrimeCyan),
          )
        }

        OutlinedTextField(
          value = samplePhrase,
          onValueChange = { samplePhrase = it },
          label = { Text("Audition Greeting Phrase") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth(),
        )

        OutlinedButton(
          onClick = {
            onPreview(
              engineMode,
              geminiPersona,
              vocalStyle,
              deviceLocaleTag,
              deviceVoiceName,
              pitch,
              speechRate,
              samplePhrase,
            )
          },
          border = BorderStroke(1.dp, PrimeCyan),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = PrimeCyan, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Preview Voice Now", color = PrimeCyan)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(
            name.ifBlank { "Custom Voice" },
            engineMode,
            geminiPersona,
            vocalStyle,
            deviceLocaleTag,
            deviceVoiceName,
            pitch,
            speechRate,
            samplePhrase,
          )
        },
        colors = ButtonDefaults.buttonColors(containerColor = PrimeGold, contentColor = PrimeObsidian),
      ) {
        Text("Save & Activate")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = PrimeTextSecondary)
      }
    },
  )
}

@Composable
private fun StudioSectionCard(
  title: String,
  content: @Composable () -> Unit,
) {
  Surface(
    color = PrimeCard,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, PrimeBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
      Text(text = title, style = MaterialTheme.typography.labelSmall, color = PrimeGold)
      content()
    }
  }
}

@Composable
private fun StudioSwitchRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(title, style = MaterialTheme.typography.titleSmall, color = PrimeTextPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = PrimeTextSecondary)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors =
        SwitchDefaults.colors(
          checkedThumbColor = PrimeObsidian,
          checkedTrackColor = PrimeGold,
          uncheckedTrackColor = PrimeSurface,
          uncheckedBorderColor = PrimeBorder,
        ),
    )
  }
}
