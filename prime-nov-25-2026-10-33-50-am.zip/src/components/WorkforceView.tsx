import {useState} from 'react';
import {
  AlertTriangle,
  Bot,
  Briefcase,
  Calendar,
  CheckCircle2,
  Cpu,
  Gauge,
  Layers,
  Mail,
  Play,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Sparkles,
  Upload,
  Volume2,
} from 'lucide-react';
import type {
  MorningBriefingEmail,
  MorningBriefingEvent,
  MorningBriefingResult,
  NexusPlatformExport,
  PrimeSettings,
  PrimeVaultSnapshot,
  TaskItem,
  TokenStats,
  WorkforceAgentRole,
  WorkforcePlan,
} from '../types/prime.ts';
import {getCachedYouTubeToken, signInWithYouTubeGoogle} from '../utils/youtubeAuth.ts';
import {fetchRecentGmailSummary, fetchUpcomingCalendarEvents} from '../utils/workspaceApi.ts';
import {OWNER_NEXUS_PRESET, parseNexusPlatformExport} from '../utils/nexusParser.ts';
import {isTaskOverdue} from '../utils/taskHelpers.ts';

interface WorkforceViewProps {
  settings: PrimeSettings;
  tasks: TaskItem[];
  tokenStats?: TokenStats;
  workforcePlan?: WorkforcePlan | null;
  nexusImport?: NexusPlatformExport | null;
  onSnapshotUpdated: (snapshot: PrimeVaultSnapshot) => void;
  onUpdateSettings: (patch: Partial<PrimeSettings>) => Promise<void>;
  onSpeakText: (text: string) => Promise<void>;
  onRetryAllAgendaFailed: () => Promise<void>;
  onNotify: (msg: string) => void;
}

const ROLE_COLORS: Record<WorkforceAgentRole, string> = {
  CEO: 'text-[#E5C07B] border-[#E5C07B]/50',
  CTO: 'text-[#38BDF8] border-[#38BDF8]/50',
  Developer: 'text-[#34D399] border-[#34D399]/50',
  Marketer: 'text-[#C084FC] border-[#C084FC]/50',
  Operator: 'text-[#94A3B8] border-[#24324A]',
};

export function WorkforceView({
  settings,
  tasks,
  tokenStats,
  workforcePlan,
  nexusImport,
  onSnapshotUpdated,
  onUpdateSettings,
  onSpeakText,
  onRetryAllAgendaFailed,
  onNotify,
}: WorkforceViewProps) {
  const [goalInput, setGoalInput] = useState('');
  const [budgetInput, setBudgetInput] = useState(120_000);
  const [requireApproval, setRequireApproval] = useState(false);
  const [autoRetryFailed, setAutoRetryFailed] = useState(true);
  const [isPlanning, setIsPlanning] = useState(false);
  const [busyTaskId, setBusyTaskId] = useState<string | null>(null);
  const [isRunningAuto, setIsRunningAuto] = useState(false);
  const [showNexusPaste, setShowNexusPaste] = useState(false);
  const [nexusRawJson, setNexusRawJson] = useState('');
  const [isImportingNexus, setIsImportingNexus] = useState(false);
  const [deployingTeamId, setDeployingTeamId] = useState<string | null>(null);

  // Jarvis Morning Briefing state
  const [isBriefingLoading, setIsBriefingLoading] = useState(false);
  const [briefing, setBriefing] = useState<MorningBriefingResult | null>(null);
  const [emails, setEmails] = useState<MorningBriefingEmail[]>([]);
  const [events, setEvents] = useState<MorningBriefingEvent[]>([]);
  const [workspaceConnected, setWorkspaceConnected] = useState(() =>
    Boolean(getCachedYouTubeToken()),
  );

  const sessionTokens = tokenStats?.sessionTokens ?? 0;
  const contextLimit = tokenStats?.contextLimitTokens ?? 1_000_000;
  const lifetimeTokens = tokenStats?.lifetimeTokens ?? 0;
  const contextPct = Math.min(100, Math.round((sessionTokens / contextLimit) * 1000) / 10);

  const failedWorkforceTasks = (workforcePlan?.tasks ?? []).filter((t) => t.status === 'failed');
  const failedOrOverdueAgenda = tasks.filter(
    (t) => !t.isCompleted && (t.status === 'failed' || Boolean(t.lastError) || isTaskOverdue(t)),
  );

  const handleConnectGoogleWorkspace = async () => {
    try {
      await signInWithYouTubeGoogle();
      setWorkspaceConnected(true);
      onNotify('Connected Google account for Gmail, Calendar & YouTube briefings.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Google Workspace sign-in failed.');
    }
  };

  const handleRunMorningBriefing = async () => {
    setIsBriefingLoading(true);
    try {
      let token = getCachedYouTubeToken();
      let loadedEmails: MorningBriefingEmail[] = [];
      let loadedEvents: MorningBriefingEvent[] = [];

      if (token) {
        setWorkspaceConnected(true);
        const [mailRes, calRes] = await Promise.allSettled([
          fetchRecentGmailSummary(token, 5),
          fetchUpcomingCalendarEvents(token, 6),
        ]);
        if (mailRes.status === 'fulfilled') loadedEmails = mailRes.value;
        if (calRes.status === 'fulfilled') loadedEvents = calRes.value;
        setEmails(loadedEmails);
        setEvents(loadedEvents);
      } else {
        setWorkspaceConnected(false);
      }

      const res = await fetch('/api/prime/briefing', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({emails: loadedEmails, events: loadedEvents}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Unable to generate Morning Briefing.');

      if (data.snapshot) onSnapshotUpdated(data.snapshot as PrimeVaultSnapshot);
      const result: MorningBriefingResult = {
        briefingText: data.briefingText,
        highlights: data.highlights ?? [],
        generatedAtMs: data.generatedAtMs ?? Date.now(),
        tokensUsed: data.tokensUsed ?? 0,
      };
      setBriefing(result);
      onNotify('Jarvis Morning Briefing generated.');
      await onSpeakText(result.briefingText);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Morning Briefing failed.');
    } finally {
      setIsBriefingLoading(false);
    }
  };

  const handleResetSessionTokens = async () => {
    const res = await fetch('/api/prime/tokens/reset', {method: 'POST'});
    if (res.ok) {
      onSnapshotUpdated((await res.json()) as PrimeVaultSnapshot);
      onNotify('Reset 1M context session token counter.');
    }
  };

  const handleDeployWorkforce = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!goalInput.trim() || isPlanning) return;
    setIsPlanning(true);
    try {
      const res = await fetch('/api/prime/workforce/plan', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          goal: goalInput.trim(),
          budgetTokens: budgetInput,
          requireApproval,
          autoRetryFailed,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Could not plan workforce.');
      onSnapshotUpdated(data as PrimeVaultSnapshot);
      setGoalInput('');
      onNotify('AI Workforce deployed with CEO, CTO, Developer & Marketer subtasks.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Workforce planning failed.');
    } finally {
      setIsPlanning(false);
    }
  };

  const handleRunTask = async (taskId: string, approve = false) => {
    setBusyTaskId(taskId);
    try {
      const url = approve
        ? `/api/prime/workforce/approve/${encodeURIComponent(taskId)}`
        : `/api/prime/workforce/run/${encodeURIComponent(taskId)}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({approved: approve}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Task execution failed.');
      onSnapshotUpdated(data as PrimeVaultSnapshot);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Agent run failed.');
    } finally {
      setBusyTaskId(null);
    }
  };

  const handleRetryTask = async (taskId: string) => {
    setBusyTaskId(taskId);
    try {
      const res = await fetch(`/api/prime/workforce/retry/${encodeURIComponent(taskId)}`, {
        method: 'POST',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Retry failed.');
      onSnapshotUpdated(data as PrimeVaultSnapshot);
      onNotify('Re-ran failed workforce task.');
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Unable to retry task.');
    } finally {
      setBusyTaskId(null);
    }
  };

  const handleRetryAllWorkforceFailed = async () => {
    setIsRunningAuto(true);
    try {
      const res = await fetch('/api/prime/workforce/retry-all-failed', {method: 'POST'});
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Retry all failed.');
      if (data.snapshot) onSnapshotUpdated(data.snapshot as PrimeVaultSnapshot);
      onNotify(`Retried ${data.retriedCount ?? 0} failed workforce task(s).`);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Batch retry failed.');
    } finally {
      setIsRunningAuto(false);
    }
  };

  const handleRunAllPendingAndRetry = async () => {
    if (!workforcePlan || isRunningAuto) return;
    setIsRunningAuto(true);
    try {
      let currentPlan = workforcePlan;
      for (const task of currentPlan.tasks) {
        if (task.status === 'pending' || (task.status === 'awaiting_approval' && !currentPlan.requireApproval)) {
          const res = await fetch(`/api/prime/workforce/run/${encodeURIComponent(task.id)}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({approved: !currentPlan.requireApproval}),
          });
          if (res.ok) {
            const snap = (await res.json()) as PrimeVaultSnapshot;
            onSnapshotUpdated(snap);
            if (snap.workforcePlan) currentPlan = snap.workforcePlan;
          }
        }
      }
      if (currentPlan.autoRetryFailed) {
        const failed = currentPlan.tasks.filter((t) => t.status === 'failed');
        if (failed.length > 0) {
          const retryRes = await fetch('/api/prime/workforce/retry-all-failed', {method: 'POST'});
          if (retryRes.ok) {
            const retryData = await retryRes.json();
            if (retryData.snapshot) onSnapshotUpdated(retryData.snapshot as PrimeVaultSnapshot);
          }
        }
      }
      onNotify('Workforce pipeline pass complete.');
    } finally {
      setIsRunningAuto(false);
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-5 overflow-y-auto pr-1">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold text-[#F1F5F9]">
            Jarvis Command &amp; AI Workforce
          </h1>
          <p className="mt-1 text-sm text-[#94A3B8]">
            1M token context telemetry, Gmail &amp; Calendar spoken briefings, coordinated AI
            agents, and failed-task recovery.
          </p>
        </div>

        {failedOrOverdueAgenda.length > 0 && (
          <button
            type="button"
            onClick={() => void onRetryAllAgendaFailed()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#FB7185]/50 bg-[#161F30] px-3.5 py-2 text-xs font-semibold text-[#FB7185] transition-colors hover:border-[#FB7185] whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Do Again All Failed/Overdue ({failedOrOverdueAgenda.length})</span>
          </button>
        )}
      </div>

      {/* Top Row: 1M Token Meter & OpenJarvis Spoken Briefing */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* 1M Context & Token Access Card (Reel 1) */}
        <section className="flex flex-col justify-between rounded-xl border border-[#24324A] bg-[#101724] p-4 lg:col-span-5">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 font-display text-sm font-semibold text-[#F1F5F9]">
                <Gauge className="h-4 w-4 text-[#E5C07B]" />
                <span>1M Token Context Window</span>
              </h2>
              <button
                type="button"
                onClick={() =>
                  void onUpdateSettings({
                    millionContextEnabled: settings.millionContextEnabled === false,
                  })
                }
                className={`rounded-md border px-2 py-1 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                  settings.millionContextEnabled !== false
                    ? 'border-[#34D399]/50 bg-[#161F30] text-[#34D399]'
                    : 'border-[#24324A] bg-[#080C14] text-[#94A3B8]'
                }`}
              >
                {settings.millionContextEnabled !== false ? '1M Mode Active' : 'Standard Window'}
              </button>
            </div>

            <div className="mt-3 flex items-baseline justify-between font-mono-tabular">
              <span className="text-lg font-bold text-[#F1F5F9]">
                {sessionTokens.toLocaleString()}
                <span className="ml-1 text-xs font-normal text-[#94A3B8]">
                  / 1,000,000 tokens
                </span>
              </span>
              <span className="text-xs font-semibold text-[#E5C07B]">{contextPct}%</span>
            </div>

            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-[#080C14]">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#38BDF8] to-[#E5C07B] transition-all"
                style={{width: `${Math.max(2, contextPct)}%`}}
              />
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] font-mono-tabular">
              <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
                <p className="text-[#64748B]">Last Request</p>
                <p className="font-semibold text-[#F1F5F9]">
                  {(tokenStats?.lastRequestTokens ?? 0).toLocaleString()} tok
                </p>
              </div>
              <div className="rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1.5">
                <p className="text-[#64748B]">Lifetime Total</p>
                <p className="font-semibold text-[#38BDF8]">
                  {lifetimeTokens.toLocaleString()} tok
                </p>
              </div>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between gap-2 border-t border-[#24324A] pt-3">
            <span className="text-[11px] text-[#94A3B8]">
              Retains 40 turns + full Vault in long-context mode
            </span>
            <button
              type="button"
              onClick={handleResetSessionTokens}
              className="text-xs font-medium text-[#E5C07B] hover:underline whitespace-nowrap shrink-0"
            >
              Reset Meter
            </button>
          </div>
        </section>

        {/* OpenJarvis Morning Briefing HUD (Reels 2 & 4) */}
        <section className="flex flex-col justify-between rounded-xl border border-[#24324A] bg-[#101724] p-4 lg:col-span-7">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 font-display text-sm font-semibold text-[#F1F5F9]">
                <Sparkles className="h-4 w-4 text-[#38BDF8]" />
                <span>OpenJarvis Spoken Morning Briefing</span>
              </h2>
              <div className="flex items-center gap-2">
                {!workspaceConnected && (
                  <button
                    type="button"
                    onClick={handleConnectGoogleWorkspace}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#DADCE0] bg-white px-2.5 py-1.5 text-[11px] font-medium text-[#1F1F1F] hover:bg-[#F8FAFC] whitespace-nowrap shrink-0"
                  >
                    <span>Connect Gmail &amp; Calendar</span>
                  </button>
                )}
                <button
                  type="button"
                  disabled={isBriefingLoading}
                  onClick={handleRunMorningBriefing}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3 py-1.5 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>{isBriefingLoading ? 'Briefing...' : 'Speak Morning Briefing'}</span>
                </button>
              </div>
            </div>

            {briefing ? (
              <div className="mt-3 flex flex-col gap-2.5 rounded-lg border border-[#38BDF8]/30 bg-[#080C14] p-3">
                <p className="text-xs leading-relaxed text-[#F1F5F9]">{briefing.briefingText}</p>
                {briefing.highlights.length > 0 && (
                  <ul className="flex flex-col gap-1 border-t border-[#24324A] pt-2 text-[11px] text-[#94A3B8]">
                    {briefing.highlights.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-[#E5C07B]">•</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="flex flex-wrap items-center gap-4 border-t border-[#24324A] pt-2 text-[11px] text-[#64748B] font-mono-tabular">
                  <span className="inline-flex items-center gap-1">
                    <Mail className="h-3 w-3 text-[#38BDF8]" />
                    {emails.length} Gmail synced
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Calendar className="h-3 w-3 text-[#34D399]" />
                    {events.length} Calendar events
                  </span>
                  <span>{briefing.tokensUsed.toLocaleString()} tok</span>
                </div>
              </div>
            ) : (
              <div className="mt-3 rounded-lg border border-[#24324A] bg-[#080C14] p-3 text-xs text-[#94A3B8]">
                {workspaceConnected
                  ? 'Google Gmail & Calendar connected. Click "Speak Morning Briefing" to summarize today’s inbox, meetings, and overdue/failed tasks aloud.'
                  : 'Connect Gmail & Calendar to include live inbox & schedule items, or click "Speak Morning Briefing" to brief your Vault agenda immediately.'}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Paperclip Multi-Agent AI Workforce Console (Reel 5 + Retry Failed Tasks) */}
      <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
            <Briefcase className="h-4 w-4 text-[#E5C07B]" />
            <span>AI Workforce Orchestrator (CEO · CTO · Developer · Marketer)</span>
          </h2>
          {workforcePlan && failedWorkforceTasks.length > 0 && (
            <button
              type="button"
              disabled={isRunningAuto}
              onClick={handleRetryAllWorkforceFailed}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#FB7185]/60 bg-[#080C14] px-3 py-1.5 text-xs font-semibold text-[#FB7185] hover:border-[#FB7185] disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Do Again Failed Tasks ({failedWorkforceTasks.length})</span>
            </button>
          )}
        </div>

        <form onSubmit={handleDeployWorkforce} className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-12">
          <div className="md:col-span-6">
            <label className="mb-1 block text-xs text-[#94A3B8]">
              Company / Project Goal
            </label>
            <input
              type="text"
              value={goalInput}
              onChange={(ev) => setGoalInput(ev.target.value)}
              placeholder="e.g., Launch an automated daily YouTube Shorts funnel & landing page"
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="mb-1 block text-xs text-[#94A3B8]">Token Budget</label>
            <input
              type="number"
              min={5000}
              step={5000}
              value={budgetInput}
              onChange={(ev) => setBudgetInput(Math.max(5000, Number(ev.target.value) || 120000))}
              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm font-mono-tabular text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
            />
          </div>

          <div className="flex flex-col justify-end gap-1.5 md:col-span-2">
            <label className="flex cursor-pointer items-center gap-1.5 text-xs text-[#94A3B8]">
              <input
                type="checkbox"
                checked={requireApproval}
                onChange={(ev) => setRequireApproval(ev.target.checked)}
                className="h-3.5 w-3.5 rounded accent-[#E5C07B]"
              />
              <span>Approval gate</span>
            </label>
            <label className="flex cursor-pointer items-center gap-1.5 text-xs text-[#94A3B8]">
              <input
                type="checkbox"
                checked={autoRetryFailed}
                onChange={(ev) => setAutoRetryFailed(ev.target.checked)}
                className="h-3.5 w-3.5 rounded accent-[#34D399]"
              />
              <span>Auto-retry failed</span>
            </label>
          </div>

          <div className="flex items-end md:col-span-2">
            <button
              type="submit"
              disabled={!goalInput.trim() || isPlanning}
              className="inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-lg bg-[#E5C07B] px-3 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap"
            >
              <Cpu className="h-3.5 w-3.5" />
              <span>{isPlanning ? 'Deploying...' : 'Deploy Team'}</span>
            </button>
          </div>
        </form>

        {workforcePlan && (
          <div className="mt-5 flex flex-col gap-4 border-t border-[#24324A] pt-4">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-4 py-3">
              <div className="min-w-0">
                <p className="text-xs font-semibold text-[#E5C07B]">Active Goal</p>
                <p className="truncate text-sm font-medium text-[#F1F5F9]">
                  {workforcePlan.goal}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs font-mono-tabular">
                <span className="text-[#94A3B8]">
                  Budget:{' '}
                  <strong className="text-[#F1F5F9]">
                    {workforcePlan.spentTokens.toLocaleString()} /{' '}
                    {workforcePlan.budgetTokens.toLocaleString()}
                  </strong>
                </span>
                <button
                  type="button"
                  disabled={isRunningAuto}
                  onClick={handleRunAllPendingAndRetry}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5C07B]/50 bg-[#161F30] px-3 py-1.5 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap shrink-0"
                >
                  <Play className="h-3.5 w-3.5" />
                  <span>{isRunningAuto ? 'Executing...' : 'Run Pipeline & Retry Failed'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {workforcePlan.tasks.map((task) => {
                const isBusy = busyTaskId === task.id;
                const roleStyle = ROLE_COLORS[task.role] ?? ROLE_COLORS.Operator;
                return (
                  <div
                    key={task.id}
                    className={`flex flex-col justify-between rounded-xl border bg-[#080C14] p-4 ${
                      task.status === 'failed'
                        ? 'border-[#FB7185]/60'
                        : task.status === 'completed'
                          ? 'border-[#34D399]/40'
                          : 'border-[#24324A]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[11px] font-semibold ${roleStyle}`}
                        >
                          <Bot className="h-3 w-3" />
                          {task.role}
                        </span>
                        <span className="text-[11px] font-mono-tabular text-[#94A3B8]">
                          {task.status === 'completed' && (
                            <span className="inline-flex items-center gap-1 text-[#34D399]">
                              <CheckCircle2 className="h-3 w-3" /> Completed
                            </span>
                          )}
                          {task.status === 'failed' && (
                            <span className="inline-flex items-center gap-1 text-[#FB7185]">
                              <AlertTriangle className="h-3 w-3" /> Failed
                              {task.retryCount > 0 ? ` (${task.retryCount}x)` : ''}
                            </span>
                          )}
                          {task.status === 'awaiting_approval' && (
                            <span className="text-[#E5C07B]">Needs Approval</span>
                          )}
                          {task.status === 'running' && (
                            <span className="inline-flex items-center gap-1 text-[#38BDF8]">
                              <RefreshCw className="h-3 w-3 animate-spin" /> Running
                            </span>
                          )}
                          {task.status === 'pending' && <span>Queued</span>}
                        </span>
                      </div>

                      <h3 className="mt-2.5 text-sm font-semibold text-[#F1F5F9]">{task.title}</h3>
                      <p className="mt-1 text-xs leading-relaxed text-[#94A3B8]">
                        {task.instruction}
                      </p>

                      {task.error && (
                        <p className="mt-2 rounded border border-[#FB7185]/40 bg-[#FB7185]/10 px-2.5 py-1.5 text-xs text-[#FB7185]">
                          {task.error}
                        </p>
                      )}

                      {task.output && (
                        <div className="mt-2.5 max-h-36 overflow-y-auto rounded border border-[#24324A] bg-[#101724] p-2.5 text-xs leading-relaxed text-[#F1F5F9]">
                          {task.output}
                        </div>
                      )}
                    </div>

                    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#24324A] pt-2.5">
                      <span className="text-[11px] font-mono-tabular text-[#64748B]">
                        {task.tokensUsed.toLocaleString()} tokens
                      </span>

                      <div className="flex items-center gap-2">
                        {task.status === 'failed' && (
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void handleRetryTask(task.id)}
                            className="inline-flex items-center gap-1 rounded-md border border-[#FB7185]/60 bg-[#161F30] px-2.5 py-1 text-xs font-semibold text-[#FB7185] hover:border-[#FB7185] disabled:opacity-40"
                          >
                            <RotateCcw className="h-3 w-3" />
                            <span>{isBusy ? 'Retrying...' : 'Do Again'}</span>
                          </button>
                        )}
                        {task.status === 'awaiting_approval' && (
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void handleRunTask(task.id, true)}
                            className="inline-flex items-center gap-1 rounded-md bg-[#E5C07B] px-2.5 py-1 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-40"
                          >
                            <ShieldCheck className="h-3 w-3" />
                            <span>{isBusy ? 'Running...' : 'Approve & Run'}</span>
                          </button>
                        )}
                        {(task.status === 'pending' || task.status === 'completed') && (
                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() => void handleRunTask(task.id, true)}
                            className="inline-flex items-center gap-1 rounded-md border border-[#24324A] bg-[#161F30] px-2.5 py-1 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40"
                          >
                            <Play className="h-3 w-3" />
                            <span>{task.status === 'completed' ? 'Re-Run' : 'Run Step'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </section>

      {/* Nexus Platform Export v1 Teams & Leader Agents */}
      <section className="rounded-xl border border-[#24324A] bg-[#101724] p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="flex items-center gap-2 font-display text-base font-semibold text-[#F1F5F9]">
              <Layers className="h-4 w-4 text-[#38BDF8]" />
              <span>Nexus Platform Teams &amp; Leader Agents</span>
            </h2>
            <p className="mt-0.5 text-xs text-[#94A3B8]">
              Import your <code className="text-[#E5C07B]">nexus-platform-export/v1</code> JSON or load your saved 8-team organization (Earn, Creater, YouTube video auto, &amp; more).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={isImportingNexus}
              onClick={async () => {
                setIsImportingNexus(true);
                try {
                  const res = await fetch('/api/prime/workforce/import-nexus', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify(OWNER_NEXUS_PRESET),
                  });
                  const data = await res.json();
                  if (!res.ok) throw new Error(data.error || 'Import failed.');
                  onSnapshotUpdated(data as PrimeVaultSnapshot);
                  onNotify('Loaded Owner Nexus Platform (Prime + 8 teams + leader agents).');
                } catch (err) {
                  onNotify(err instanceof Error ? err.message : 'Unable to load Nexus profile.');
                } finally {
                  setIsImportingNexus(false);
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#E5C07B] px-3 py-1.5 text-xs font-semibold text-[#080C14] hover:bg-[#ECCE93] disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{nexusImport ? 'Refresh Owner Nexus Teams' : 'Load My Nexus Teams (8)'}</span>
            </button>

            <button
              type="button"
              onClick={() => setShowNexusPaste((prev) => !prev)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#E5C07B]/60 whitespace-nowrap shrink-0"
            >
              <Upload className="h-3.5 w-3.5 text-[#38BDF8]" />
              <span>{showNexusPaste ? 'Hide JSON Import' : 'Paste Export JSON'}</span>
            </button>
          </div>
        </div>

        {showNexusPaste && (
          <div className="mt-3 rounded-lg border border-[#24324A] bg-[#080C14] p-3">
            <textarea
              value={nexusRawJson}
              onChange={(ev) => setNexusRawJson(ev.target.value)}
              rows={4}
              placeholder='Paste "nexus-platform-export/v1" JSON here...'
              className="w-full rounded-lg border border-[#24324A] bg-[#101724] px-3 py-2 font-mono-tabular text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
            />
            <div className="mt-2 flex justify-end">
              <button
                type="button"
                disabled={isImportingNexus || !nexusRawJson.trim()}
                onClick={async () => {
                  setIsImportingNexus(true);
                  try {
                    const parsed = parseNexusPlatformExport(nexusRawJson);
                    const res = await fetch('/api/prime/workforce/import-nexus', {
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify(parsed),
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error || 'Import failed.');
                    onSnapshotUpdated(data as PrimeVaultSnapshot);
                    setNexusRawJson('');
                    setShowNexusPaste(false);
                    onNotify(`Imported ${parsed.teams.length} Nexus team(s) and ${parsed.agents.length} agent(s).`);
                  } catch (err) {
                    onNotify(err instanceof Error ? err.message : 'Invalid Nexus JSON.');
                  } finally {
                    setIsImportingNexus(false);
                  }
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#38BDF8] px-3 py-1.5 text-xs font-semibold text-[#080C14] hover:opacity-90 disabled:opacity-40"
              >
                <span>Import Custom Nexus JSON</span>
              </button>
            </div>
          </div>
        )}

        {nexusImport && (
          <div className="mt-4 flex flex-col gap-3">
            {nexusImport.prime && (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#E5C07B]/40 bg-[#080C14] px-3.5 py-2.5 text-xs">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-[#E5C07B]">{nexusImport.prime.name} Core</span>
                  <span className="text-[#64748B]">·</span>
                  <span className="text-[#F1F5F9]">
                    Autonomy {nexusImport.prime.autonomyLevel}%
                  </span>
                  <span className="text-[#64748B]">·</span>
                  <span className="text-[#34D399]">
                    {nexusImport.prime.skills.length} skills synced
                  </span>
                </div>
                <span className="font-mono-tabular text-[11px] text-[#94A3B8]">
                  {nexusImport.owner?.email || 'Owner'}
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {nexusImport.teams.map((team) => {
                const leader = nexusImport.agents.find((a) => a.id === team.leaderAgentId);
                const busy = deployingTeamId === team.id;
                return (
                  <div
                    key={team.id}
                    className="flex flex-col justify-between rounded-xl border border-[#24324A] bg-[#080C14] p-3.5"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="truncate text-sm font-semibold text-[#F1F5F9]">{team.name}</h3>
                        <span className="rounded bg-[#161F30] px-1.5 py-0.5 text-[10px] font-mono-tabular text-[#38BDF8]">
                          {team.memberCount} agents
                        </span>
                      </div>
                      <p className="mt-1 line-clamp-2 text-xs text-[#94A3B8]">{team.domain}</p>
                      {leader && (
                        <p className="mt-2 text-[11px] text-[#E5C07B]">
                          Leader: <strong>{leader.name}</strong> (Autonomy {leader.autonomyLevel}%)
                        </p>
                      )}
                    </div>

                    <button
                      type="button"
                      disabled={busy || Boolean(deployingTeamId)}
                      onClick={async () => {
                        setDeployingTeamId(team.id);
                        try {
                          const res = await fetch(
                            `/api/prime/workforce/deploy-team/${encodeURIComponent(team.id)}`,
                            {method: 'POST'},
                          );
                          const data = await res.json();
                          if (!res.ok) throw new Error(data.error || 'Deploy failed.');
                          onSnapshotUpdated(data as PrimeVaultSnapshot);
                          onNotify(`Deployed Nexus team "${team.name}" into AI Workforce.`);
                        } catch (err) {
                          onNotify(err instanceof Error ? err.message : 'Unable to deploy team.');
                        } finally {
                          setDeployingTeamId(null);
                        }
                      }}
                      className="mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#24324A] bg-[#161F30] px-2.5 py-1.5 text-xs font-semibold text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40"
                    >
                      <Play className="h-3 w-3" />
                      <span>{busy ? 'Deploying...' : 'Deploy Team'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
