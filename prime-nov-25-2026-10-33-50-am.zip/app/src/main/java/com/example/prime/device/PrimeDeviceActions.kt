package com.example.prime.device

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.example.prime.model.DeviceActionSuggestion

object PrimeDeviceActions {

  fun launch(context: Context, suggestion: DeviceActionSuggestion): Result<String> {
    return runCatching {
      when (suggestion.actionType.uppercase()) {
        "ALARM" -> launchAlarm(context, suggestion)
        "TIMER" -> launchTimer(context, suggestion)
        "EMAIL" -> launchEmail(context, suggestion)
        else -> launchShare(context, suggestion)
      }
    }
  }

  private fun launchAlarm(context: Context, suggestion: DeviceActionSuggestion): String {
    val timeMatch = Regex("(\\d{1,2}):(\\d{2})\\s*(AM|PM|am|pm)?").find(suggestion.detail)
    val intent =
      Intent(AlarmClock.ACTION_SET_ALARM).apply {
        putExtra(AlarmClock.EXTRA_MESSAGE, suggestion.label)
        if (timeMatch != null) {
          var hour = timeMatch.groupValues[1].toIntOrNull() ?: 7
          val minute = timeMatch.groupValues[2].toIntOrNull() ?: 0
          val amPm = timeMatch.groupValues[3].uppercase()
          if (amPm == "PM" && hour < 12) hour += 12
          if (amPm == "AM" && hour == 12) hour = 0
          putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
          putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
        }
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    context.startActivity(intent)
    return "Opened Clock alarm setup."
  }

  private fun launchTimer(context: Context, suggestion: DeviceActionSuggestion): String {
    val secMatch = Regex("(\\d+)\\s*(sec|second|seconds|s)\\b", RegexOption.IGNORE_CASE).find(suggestion.detail)
    val minMatch = Regex("(\\d+)\\s*(min|minute|minutes|m)\\b", RegexOption.IGNORE_CASE).find(suggestion.detail)
    val hourMatch = Regex("(\\d+)\\s*(hr|hour|hours|h)\\b", RegexOption.IGNORE_CASE).find(suggestion.detail)
    val totalSeconds =
      (hourMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0) * 3600 +
        (minMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0) * 60 +
        (secMatch?.groupValues?.get(1)?.toIntOrNull() ?: 0)

    val intent =
      Intent(AlarmClock.ACTION_SET_TIMER).apply {
        putExtra(AlarmClock.EXTRA_MESSAGE, suggestion.label)
        if (totalSeconds > 0) {
          putExtra(AlarmClock.EXTRA_LENGTH, totalSeconds)
        }
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    context.startActivity(intent)
    return "Opened Clock timer setup."
  }

  private fun launchEmail(context: Context, suggestion: DeviceActionSuggestion): String {
    val lines = suggestion.detail.split("\n", limit = 2)
    val subject = lines.firstOrNull()?.removePrefix("Subject:")?.trim().orEmpty().ifEmpty { suggestion.label }
    val body = if (lines.size > 1) lines[1].trim() else suggestion.detail
    val intent =
      Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:")
        putExtra(Intent.EXTRA_SUBJECT, subject)
        putExtra(Intent.EXTRA_TEXT, body)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    context.startActivity(Intent.createChooser(intent, "Send with Email App").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    return "Opened email draft."
  }

  private fun launchShare(context: Context, suggestion: DeviceActionSuggestion): String {
    val intent =
      Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, suggestion.label)
        putExtra(Intent.EXTRA_TEXT, suggestion.detail)
      }
    context.startActivity(Intent.createChooser(intent, suggestion.label).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    return "Opened share sheet."
  }
}
