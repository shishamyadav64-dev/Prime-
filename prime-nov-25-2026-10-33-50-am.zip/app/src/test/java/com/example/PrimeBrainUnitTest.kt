package com.example

import com.example.prime.brain.PrimeMathTool
import com.example.prime.brain.PrimePersonality
import com.example.prime.data.PrimeSerializers
import com.example.prime.data.VoiceProfileEntity
import com.example.prime.model.DeviceActionSuggestion
import com.example.prime.model.GroundingSource
import com.example.prime.model.MannerProfile
import com.example.prime.model.PrimeSettings
import com.example.prime.model.ToolExecutionBadge
import com.example.prime.model.VocalStylePreset
import com.example.prime.model.VoiceEngineMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PrimeBrainUnitTest {

  @Test
  fun mathEvaluator_handlesArithmeticAndFunctions() {
    val compound = PrimeMathTool.evaluate("5000 * 1.07^2").getOrThrow()
    assertEquals("5724.5", PrimeMathTool.formatResult(compound))

    val trig = PrimeMathTool.evaluate("sqrt(144) + 2^5").getOrThrow()
    assertEquals("44", PrimeMathTool.formatResult(trig))

    val divZero = PrimeMathTool.evaluate("10 / 0")
    assertTrue(divZero.isFailure)
  }

  @Test
  fun personality_buildsTimeGreetingAndExtractsThought() {
    val settings =
      PrimeSettings(
        preferredTitle = "Alex",
        mannerProfile = MannerProfile.REFINED_GENTLEMAN,
      )
    val morning = PrimePersonality.buildTimeGreeting(hourOfDay = 8, settings = settings, pendingTaskCount = 2)
    assertTrue(morning.contains("Good morning, Alex"))
    assertTrue(morning.contains("2 tasks"))

    val raw = "[THOUGHT] User sounds stressed; keep tone reassuring. [/THOUGHT]Take a breath, Alex. I've organized your schedule."
    val (thought, reply) = PrimePersonality.extractThoughtAndReply(raw)
    assertEquals("User sounds stressed; keep tone reassuring.", thought)
    assertEquals("Take a breath, Alex. I've organized your schedule.", reply)

    val noThought = PrimePersonality.extractThoughtAndReply("Certainly, Alex.")
    assertNull(noThought.first)
    assertEquals("Certainly, Alex.", noThought.second)
  }

  @Test
  fun speechSanitizer_stripsMarkdownAndCodeBlocks() {
    val raw = "**Hello**, check `val x = 1` and ```kotlin\nprintln(x)\n``` at https://example.com"
    val clean = PrimePersonality.sanitizeForSpeech(raw)
    assertTrue(!clean.contains("**"))
    assertTrue(!clean.contains("https://"))
    assertTrue(clean.contains("code snippet on your screen"))
  }

  @Test
  fun serializers_roundTripSourcesBadgesAndDeviceAction() {
    val sources = listOf(GroundingSource("Example", "https://example.com"))
    val badges = listOf(ToolExecutionBadge("Memory Vault", "Saved fact"))
    val action = DeviceActionSuggestion("TIMER", "Start 15m Timer", "15 minutes")

    assertEquals(sources, PrimeSerializers.deserializeSources(PrimeSerializers.serializeSources(sources)))
    assertEquals(badges, PrimeSerializers.deserializeToolActions(PrimeSerializers.serializeToolActions(badges)))
    val decodedAction = PrimeSerializers.deserializeDeviceAction(PrimeSerializers.serializeDeviceAction(action))
    assertNotNull(decodedAction)
    assertEquals(action, decodedAction)
  }

  @Test
  fun customVoiceProfile_preservesParametersAndVocalDirections() {
    val profile =
      VoiceProfileEntity(
        id = 1L,
        name = "Athena",
        engineMode = VoiceEngineMode.GEMINI_NEURAL_TTS.name,
        geminiPersona = "KORE",
        vocalStyle = VocalStylePreset.WARM_EMPATHETIC.name,
        deviceLocaleTag = "en-GB",
        deviceVoiceName = "",
        pitch = 1.04f,
        speechRate = 0.98f,
        samplePhrase = "Good evening, Sir.",
      )
    assertEquals("Athena", profile.name)
    assertTrue(VocalStylePreset.WARM_EMPATHETIC.direction.contains("warm"))
    assertEquals("", VocalStylePreset.NATURAL.direction)
  }
}
