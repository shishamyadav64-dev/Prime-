import {useEffect, useRef, useState} from 'react';
import {
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  Crosshair,
  ExternalLink,
  HeartHandshake,
  HelpCircle,
  History,
  ImagePlus,
  ListChecks,
  Mic,
  Monitor,
  Plus,
  Radio,
  RotateCcw,
  Scan,
  Send,
  Sparkles,
  Square,
  Trash2,
  Volume2,
  X,
} from 'lucide-react';
import type {
  DeviceAnalysisResult,
  HowToGuideResult,
  PrimeMessage,
  PrimeSettings,
  TaskItem,
  TokenStats,
  VoiceShortcutDefinition,
  VoiceState,
} from '../types/prime.ts';
import {extractSuggestedTasks} from '../utils/taskHelpers.ts';
import {AudioWaveform} from './AudioWaveform.tsx';
import {DeviceAnalysisPanel, HowToGuidePanel} from './AssistantVisualTools.tsx';
import {HelpShortcutsModal} from './HelpShortcutsModal.tsx';
import {PrimeOrb} from './PrimeOrb.tsx';

interface CompanionViewProps {
  messages: PrimeMessage[];
  tasks: TaskItem[];
  settings: PrimeSettings;
  voiceState: VoiceState;
  partialTranscript: string;
  draftInput: string;
  attachedImageDataUrl: string | null;
  isProcessing: boolean;
  isAnalyzingDevice?: boolean;
  isBuildingGuide?: boolean;
  activeHowToGuide?: HowToGuideResult | null;
  activeDeviceAnalysis?: DeviceAnalysisResult | null;
  freeFirePlaystyle?: string;
  freeFireGrip?: string;
  voiceCommandHistory: string[];
  tokenStats?: TokenStats;
  onDraftChange: (val: string) => void;
  onSend: (overrideText?: string) => void;
  onReplayVoiceCommand: (commandText: string) => void;
  onClearCommandHistory: () => void;
  onAttachImage: (dataUrl: string | null) => void;
  onMicToggle: () => void;
  onBargeInAndListen?: () => void;
  onSpeakMessage: (text: string, styleOverride?: string) => void;
  onStopSpeaking: () => void;
  onUpdateSettings: (patch: Partial<PrimeSettings>) => void | Promise<void>;
  onAddSuggestedTask: (title: string, priority: TaskItem['priority']) => Promise<void>;
  onAddAllSuggestedTasks?: (
    items: Array<{title: string; priority: TaskItem['priority']}>,
  ) => Promise<void>;
  onExecuteVoiceShortcutExample: (shortcut: VoiceShortcutDefinition) => void;
  onAnalyzeMobile?: () => void;
  onAnalyzeScreen?: () => void;
  onShowMeHow?: () => void;
  onSaveFactToVault?: (fact: string) => void;
  onChangeFreeFirePlaystyle?: (style: string) => void;
  onChangeFreeFireGrip?: (grip: string) => void;
  onDismissHowToGuide?: () => void;
  onDismissDeviceAnalysis?: () => void;
  onOpenWorkforce?: () => void;
  onNotify: (msg: string) => void;
}

const STARTER_PROMPTS = [
  {
    label: 'Daily briefing',
    prompt:
      'Give me a polite daily briefing covering my pending tasks and top focus recommendations.',
  },
  {
    label: 'Remember a preference',
    prompt:
      'Remember that I prefer concise summaries in the morning and deeper explanations in the evening.',
  },
  {
    label: 'Compound math',
    prompt:
      'Calculate the final balance if I invest 5000 at 7.5% annual compound interest for 6 years.',
  },
  {
    label: 'Add focus task',
    prompt: 'Add a high-priority task to review my quarterly roadmap by 5 PM today.',
  },
];

export function CompanionView({
  messages,
  tasks,
  settings,
  voiceState,
  partialTranscript,
  draftInput,
  attachedImageDataUrl,
  isProcessing,
  isAnalyzingDevice = false,
  isBuildingGuide = false,
  activeHowToGuide = null,
  activeDeviceAnalysis = null,
  freeFirePlaystyle = 'One-Tap Headshot',
  freeFireGrip = '2-Finger / Thumb',
  voiceCommandHistory,
  tokenStats,
  onDraftChange,
  onSend,
  onReplayVoiceCommand,
  onClearCommandHistory,
  onAttachImage,
  onMicToggle,
  onBargeInAndListen,
  onSpeakMessage,
  onStopSpeaking,
  onUpdateSettings,
  onAddSuggestedTask,
  onAddAllSuggestedTasks,
  onExecuteVoiceShortcutExample,
  onAnalyzeMobile,
  onAnalyzeScreen,
  onShowMeHow,
  onSaveFactToVault,
  onChangeFreeFirePlaystyle,
  onChangeFreeFireGrip,
  onDismissHowToGuide,
  onDismissDeviceAnalysis,
  onOpenWorkforce,
  onNotify,
}: CompanionViewProps) {
  const scrollEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [expandedTraces, setExpandedTraces] = useState<Record<string, boolean>>({});
  const [helpModalOpen, setHelpModalOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(true);
  const [addingSuggestionId, setAddingSuggestionId] = useState<string | null>(null);
  const [isAddingAllSuggestions, setIsAddingAllSuggestions] = useState(false);
  const [addedSuggestionTitles, setAddedSuggestionTitles] = useState<Record<string, boolean>>({});

  const suggestedTasks = extractSuggestedTasks(messages, tasks).filter(
    (item) => !addedSuggestionTitles[item.title.toLowerCase()],
  );
  const smartContextAutoDeep = settings.smartContextEnabled && draftInput.trim().length > 50;

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({behavior: 'smooth'});
  }, [messages.length, isProcessing]);

  const handleFileChange = (ev: React.ChangeEvent<HTMLInputElement>) => {
    const file = ev.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      onNotify('Please select an image file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onAttachImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
    ev.target.value = '';
  };

  const handleKeyDown = (ev: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (ev.key === 'Enter' && !ev.shiftKey) {
      ev.preventDefault();
      if ((draftInput.trim() || attachedImageDataUrl) && !isProcessing) {
        onSend();
      }
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col gap-4">
      <PrimeOrb
        voiceState={voiceState}
        partialTranscript={partialTranscript}
        preferredTitle={settings.preferredTitle}
        onOrbClick={onMicToggle}
      />

      <AudioWaveform voiceState={voiceState} partialTranscript={partialTranscript} />

      {/* Smart Context, Wake Word, Command History & Help Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#24324A] bg-[#101724] px-3.5 py-2">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            aria-pressed={settings.smartContextEnabled}
            onClick={() =>
              onUpdateSettings({smartContextEnabled: !settings.smartContextEnabled})
            }
            title="Automatically switches to Deep Brain when prompt length exceeds 50 characters"
            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              settings.smartContextEnabled
                ? 'border-[#E5C07B]/60 bg-[#161F30] text-[#E5C07B]'
                : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Smart Context {settings.smartContextEnabled ? 'On' : 'Off'}</span>
          </button>

          <button
            type="button"
            aria-pressed={settings.wakeWordEnabled}
            onClick={() => onUpdateSettings({wakeWordEnabled: !settings.wakeWordEnabled})}
            title='Say "Prime" or "Hey PRIME" -> responds "What happened, boss?" and listens automatically'
            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              settings.wakeWordEnabled
                ? 'border-[#34D399]/60 bg-[#161F30] text-[#34D399]'
                : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Radio className="h-3.5 w-3.5" />
            <span>
              Wake &ldquo;Prime&rdquo; {settings.wakeWordEnabled ? 'On' : 'Off'}
            </span>
          </button>

          <button
            type="button"
            aria-pressed={Boolean(settings.backgroundListenMode)}
            onClick={() => {
              const nextBg = !settings.backgroundListenMode;
              void onUpdateSettings({
                backgroundListenMode: nextBg,
                ...(nextBg ? {wakeWordEnabled: true} : {}),
              });
            }}
            title="Show floating Boss HUD & keep wake word active in background"
            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              settings.backgroundListenMode
                ? 'border-[#E5C07B]/60 bg-[#161F30] text-[#E5C07B]'
                : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Monitor className="h-3.5 w-3.5" />
            <span>Boss HUD</span>
          </button>

          <button
            type="button"
            disabled={isAnalyzingDevice}
            onClick={() => onAnalyzeMobile?.()}
            title="Analyze this phone's RAM, Hz, DPI and create a Free Fire headshot sensitivity preset"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs font-medium text-[#E5C07B] transition-colors hover:border-[#E5C07B]/60 hover:bg-[#161F30] disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Crosshair className="h-3.5 w-3.5" />
            <span>{isAnalyzingDevice ? 'Analyzing...' : 'FF Sensitivity'}</span>
          </button>

          <button
            type="button"
            disabled={isAnalyzingDevice}
            onClick={() => onAnalyzeScreen?.()}
            title="Capture screen / screenshot and let PRIME analyze what is shown"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs font-medium text-[#34D399] transition-colors hover:border-[#34D399]/60 hover:bg-[#161F30] disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Scan className="h-3.5 w-3.5" />
            <span>Analyze Screen</span>
          </button>

          <button
            type="button"
            disabled={isBuildingGuide}
            onClick={() => onShowMeHow?.()}
            title="Turn your question or task into an interactive visual step-by-step walkthrough"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs font-medium text-[#38BDF8] transition-colors hover:border-[#38BDF8]/60 hover:bg-[#161F30] disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <ListChecks className="h-3.5 w-3.5" />
            <span>{isBuildingGuide ? 'Guiding...' : 'Show Me How'}</span>
          </button>

          <button
            type="button"
            onClick={onOpenWorkforce}
            title="View 1M token usage & Jarvis Morning Briefing / AI Workforce"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs font-mono-tabular text-[#38BDF8] transition-colors hover:border-[#E5C07B]/60 hover:text-[#E5C07B] whitespace-nowrap shrink-0"
          >
            <span>
              {(tokenStats?.sessionTokens ?? 0).toLocaleString()} / 1M tok
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            aria-expanded={historyOpen}
            onClick={() => setHistoryOpen((prev) => !prev)}
            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              historyOpen && voiceCommandHistory.length > 0
                ? 'border-[#38BDF8]/50 bg-[#161F30] text-[#38BDF8]'
                : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <History className="h-3.5 w-3.5" />
            <span>Command History ({voiceCommandHistory.length}/10)</span>
          </button>

          <button
            type="button"
            aria-pressed={settings.expressiveVoiceMode !== false}
            onClick={() =>
              onUpdateSettings({
                expressiveVoiceMode: !(settings.expressiveVoiceMode !== false),
              })
            }
            title="Emotionally Intelligent Voice AI: adapts warmth, pacing, and emphasis to conversational emotion"
            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              settings.expressiveVoiceMode !== false
                ? 'border-[#34D399]/60 bg-[#161F30] text-[#34D399]'
                : 'border-[#24324A] bg-[#080C14] text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <HeartHandshake className="h-3.5 w-3.5" />
            <span>
              Expressive Voice {settings.expressiveVoiceMode !== false ? 'On' : 'Off'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setHelpModalOpen(true)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs font-medium text-[#E5C07B] transition-colors hover:border-[#E5C07B]/60 whitespace-nowrap shrink-0"
          >
            <HelpCircle className="h-3.5 w-3.5" />
            <span>Shortcut Help</span>
          </button>
        </div>
      </div>

      {/* Scrollable Voice Command History (last 10 commands) */}
      {historyOpen && (
        <section
          aria-label="Voice Command History"
          className="rounded-xl border border-[#24324A] bg-[#101724] px-3.5 py-2.5"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-medium text-[#94A3B8]">
              <History className="h-3.5 w-3.5 text-[#38BDF8]" />
              <span>Command History</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-tabular text-[11px] text-[#64748B]">
                Last {voiceCommandHistory.length} of 10 voice inputs
              </span>
            </div>
            {voiceCommandHistory.length > 0 && (
              <button
                type="button"
                onClick={onClearCommandHistory}
                className="inline-flex items-center gap-1 text-[11px] text-[#94A3B8] hover:text-[#FB7185]"
              >
                <Trash2 className="h-3 w-3" />
                <span>Clear</span>
              </button>
            )}
          </div>

          {voiceCommandHistory.length === 0 ? (
            <p className="mt-1.5 text-xs text-[#64748B]">
              Speak via microphone or say &ldquo;Hey PRIME&rdquo; to record up to 10 quick-replay commands.
            </p>
          ) : (
            <div className="mt-2 max-h-28 overflow-y-auto pr-1">
              <div className="flex flex-col gap-1">
                {voiceCommandHistory.map((cmd, idx) => (
                  <button
                    key={`${cmd}_${idx}`}
                    type="button"
                    disabled={isProcessing}
                    onClick={() => onReplayVoiceCommand(cmd)}
                    className="flex items-center justify-between gap-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-left text-xs text-[#F1F5F9] transition-colors hover:border-[#E5C07B]/50 hover:bg-[#161F30] disabled:opacity-50"
                  >
                    <span className="min-w-0 truncate">{cmd}</span>
                    <span className="inline-flex shrink-0 items-center gap-1 text-[11px] font-medium text-[#E5C07B]">
                      <RotateCcw className="h-3 w-3" />
                      <span>Re-trigger</span>
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {/* Conversation feed (with inline Visual Walkthrough & Device/Free Fire Analysis Cards) */}
      <div className="min-h-0 flex-1 overflow-y-auto pr-1">
        <div className="flex flex-col gap-5 pb-4">
          {activeHowToGuide && (
            <HowToGuidePanel
              guide={activeHowToGuide}
              onSpeakText={(txt) => onSpeakMessage(txt)}
              onSaveAsTask={(title) => void onAddSuggestedTask(title, 'Normal')}
              onClose={() => onDismissHowToGuide?.()}
            />
          )}

          {activeDeviceAnalysis && (
            <DeviceAnalysisPanel
              analysis={activeDeviceAnalysis}
              playstyle={freeFirePlaystyle}
              fingerGrip={freeFireGrip}
              isRecalculating={isAnalyzingDevice}
              onChangePlaystyle={(style) => onChangeFreeFirePlaystyle?.(style)}
              onChangeFingerGrip={(grip) => onChangeFreeFireGrip?.(grip)}
              onRecalculate={() => onAnalyzeMobile?.()}
              onSpeakText={(txt) => onSpeakMessage(txt)}
              onSaveToVault={(fact) => onSaveFactToVault?.(fact)}
              onNotify={onNotify}
              onClose={() => onDismissDeviceAnalysis?.()}
            />
          )}

          {messages.map((msg) => {
            const traceOpen = !!expandedTraces[msg.id];
            return (
              <article
                key={msg.id}
                className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`w-full max-w-[760px] rounded-xl border px-5 py-4 ${
                    msg.isError
                      ? 'border-[#FB7185]/40 bg-[#FB7185]/10'
                      : msg.isUser
                        ? 'border-[#E5C07B]/35 bg-[#161F30]'
                        : 'border-[#24324A] bg-[#101724]'
                  }`}
                >
                  {/* Header row */}
                  <div className="mb-2 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2 text-xs text-[#94A3B8]">
                      <span
                        className={`font-display font-semibold ${
                          msg.isUser ? 'text-[#E5C07B]' : 'text-[#F1F5F9]'
                        }`}
                      >
                        {msg.isUser ? settings.preferredTitle || 'You' : 'PRIME'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <time className="font-mono-tabular">
                        {new Date(msg.timestampMs).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </time>
                      {!msg.isUser && msg.detectedEmotion && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono-tabular text-[11px] text-[#34D399]">
                            {msg.detectedEmotion}
                          </span>
                        </>
                      )}
                    </div>

                    {!msg.isUser && (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() =>
                            voiceState === 'speaking'
                              ? onStopSpeaking()
                              : onSpeakMessage(msg.text, msg.suggestedVocalStyle)
                          }
                          aria-label={voiceState === 'speaking' ? 'Stop speech' : 'Speak response'}
                          className="rounded-lg p-1.5 text-[#94A3B8] transition-colors hover:bg-[#161F30] hover:text-[#E5C07B]"
                        >
                          {voiceState === 'speaking' ? (
                            <Square className="h-4 w-4" />
                          ) : (
                            <Volume2 className="h-4 w-4" />
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(msg.text);
                            onNotify('Copied response to clipboard.');
                          }}
                          aria-label="Copy response"
                          className="rounded-lg p-1.5 text-[#94A3B8] transition-colors hover:bg-[#161F30] hover:text-[#F1F5F9]"
                        >
                          <Copy className="h-4 w-4" />
                        </button>
                      </div>
                    )}
                  </div>

                  {msg.imageDataUrl && (
                    <img
                      src={msg.imageDataUrl}
                      alt="Uploaded attachment"
                      referrerPolicy="no-referrer"
                      className="mb-3 max-h-60 rounded-lg border border-[#24324A] object-cover"
                    />
                  )}

                  {!msg.isUser && settings.showReasoningTrace && msg.reasoningTrace && (
                    <div className="mb-3 border-b border-[#24324A] pb-2.5">
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedTraces((prev) => ({
                            ...prev,
                            [msg.id]: !prev[msg.id],
                          }))
                        }
                        className="flex w-full items-center justify-between text-left text-xs font-medium text-[#94A3B8] hover:text-[#F1F5F9]"
                      >
                        <span>Human Brain Reflection</span>
                        {traceOpen ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </button>
                      {traceOpen && (
                        <p className="mt-2 text-sm italic leading-relaxed text-[#94A3B8]">
                          {msg.reasoningTrace}
                        </p>
                      )}
                    </div>
                  )}

                  <div
                    className={`whitespace-pre-wrap text-[15px] leading-relaxed ${
                      msg.isError ? 'text-[#FB7185]' : 'text-[#F1F5F9]'
                    }`}
                  >
                    {msg.text}
                  </div>

                  {msg.toolActions && msg.toolActions.length > 0 && (
                    <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-[#24324A] pt-2.5 text-xs text-[#34D399]">
                      {msg.toolActions.map((tool, idx) => (
                        <span key={`${tool.toolName}_${idx}`} className="font-mono-tabular">
                          {tool.toolName}: {tool.summary}
                        </span>
                      ))}
                    </div>
                  )}

                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-3 border-t border-[#24324A] pt-2.5">
                      <p className="mb-1.5 text-xs text-[#94A3B8]">Verified Web Sources</p>
                      <div className="flex flex-wrap gap-3">
                        {msg.sources.map((src) => (
                          <a
                            key={src.uri}
                            href={src.uri}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-xs text-[#E5C07B] underline-offset-4 hover:underline"
                          >
                            <span className="max-w-[220px] truncate">{src.title}</span>
                            <ExternalLink className="h-3 w-3 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </article>
            );
          })}

          {isProcessing && (
            <div className="flex justify-start">
              <div className="w-full max-w-[520px] rounded-xl border border-[#24324A] bg-[#101724] px-5 py-4">
                <div className="h-3 w-24 rounded bg-[#161F30]" />
                <div className="mt-3 h-4 w-4/5 rounded bg-[#161F30]" />
                <div className="mt-2 h-4 w-3/5 rounded bg-[#161F30]" />
              </div>
            </div>
          )}

          {messages.length <= 1 && !isProcessing && (
            <div className="pt-2">
              <p className="mb-2.5 text-xs font-medium text-[#94A3B8]">Suggested prompts</p>
              <div className="flex flex-wrap gap-2">
                {STARTER_PROMPTS.map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => onSend(item.prompt)}
                    className="rounded-lg border border-[#24324A] bg-[#101724] px-3.5 py-2 text-xs font-medium text-[#E5C07B] transition-colors hover:border-[#E5C07B]/60 hover:bg-[#161F30] whitespace-nowrap shrink-0"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div ref={scrollEndRef} />
        </div>
      </div>

      {/* Contextual Suggested Tasks from Conversation */}
      {suggestedTasks.length > 0 && (
        <section
          aria-label="Suggested Tasks from Conversation"
          className="rounded-xl border border-[#24324A] bg-[#101724] px-3.5 py-2.5"
        >
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-medium text-[#94A3B8]">
              Suggested Tasks from Context
            </p>
            <div className="flex items-center gap-2.5">
              <span className="hidden text-[11px] text-[#64748B] sm:inline">
                One-click add to Vault
              </span>
              <button
                type="button"
                disabled={isAddingAllSuggestions || Boolean(addingSuggestionId)}
                onClick={async () => {
                  setIsAddingAllSuggestions(true);
                  try {
                    const batch = suggestedTasks.map((s) => ({
                      title: s.title,
                      priority: s.priority,
                    }));
                    if (onAddAllSuggestedTasks) {
                      await onAddAllSuggestedTasks(batch);
                    } else {
                      for (const item of batch) {
                        await onAddSuggestedTask(item.title, item.priority);
                      }
                    }
                    setAddedSuggestionTitles((prev) => {
                      const next = {...prev};
                      for (const s of batch) next[s.title.toLowerCase()] = true;
                      return next;
                    });
                  } finally {
                    setIsAddingAllSuggestions(false);
                  }
                }}
                className="inline-flex items-center gap-1 rounded-md border border-[#E5C07B]/50 bg-[#161F30] px-2.5 py-1 text-[11px] font-semibold text-[#E5C07B] transition-colors hover:border-[#E5C07B] disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Plus className="h-3 w-3" />
                <span>
                  {isAddingAllSuggestions
                    ? 'Adding all...'
                    : `Add All (${suggestedTasks.length})`}
                </span>
              </button>
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {suggestedTasks.map((item) => {
              const busy = addingSuggestionId === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  disabled={busy}
                  onClick={async () => {
                    setAddingSuggestionId(item.id);
                    try {
                      await onAddSuggestedTask(item.title, item.priority);
                      setAddedSuggestionTitles((prev) => ({
                        ...prev,
                        [item.title.toLowerCase()]: true,
                      }));
                    } finally {
                      setAddingSuggestionId(null);
                    }
                  }}
                  className="inline-flex max-w-full items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9] transition-colors hover:border-[#E5C07B]/60 hover:bg-[#161F30] disabled:opacity-50"
                >
                  {busy ? (
                    <Check className="h-3.5 w-3.5 shrink-0 text-[#34D399]" />
                  ) : (
                    <Plus className="h-3.5 w-3.5 shrink-0 text-[#E5C07B]" />
                  )}
                  <span className="truncate">{item.title}</span>
                  <span aria-hidden="true" className="text-[#64748B]">·</span>
                  <span className="shrink-0 text-[11px] font-medium text-[#E5C07B]">
                    {item.priority === 'Normal' ? 'Medium' : item.priority}
                  </span>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Composer */}
      <div className="rounded-xl border border-[#24324A] bg-[#101724] p-3">
        {smartContextAutoDeep && (
          <div className="mb-2 flex items-center justify-between text-[11px] text-[#E5C07B]">
            <span>Smart Context active · Detailed prompt detected ({draftInput.trim().length} chars)</span>
            <span>Auto Deep Brain on send</span>
          </div>
        )}
        {attachedImageDataUrl && (
          <div className="mb-2.5 flex items-center justify-between gap-3 rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-2">
            <div className="flex items-center gap-3 min-w-0">
              <img
                src={attachedImageDataUrl}
                alt="Pending attachment"
                referrerPolicy="no-referrer"
                className="h-10 w-10 rounded object-cover"
              />
              <span className="truncate text-xs text-[#F1F5F9]">
                Image attached for visual analysis
              </span>
            </div>
            <button
              type="button"
              onClick={() => onAttachImage(null)}
              aria-label="Remove attached image"
              className="rounded p-1 text-[#94A3B8] hover:text-[#F1F5F9]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        <div className="flex items-end gap-2.5">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessing}
            aria-label="Upload image"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-[#24324A] bg-[#161F30] text-[#94A3B8] transition-colors hover:text-[#F1F5F9] disabled:opacity-40"
          >
            <ImagePlus className="h-4 w-4" />
          </button>

          <textarea
            value={draftInput}
            onChange={(ev) => onDraftChange(ev.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
            placeholder="Ask PRIME anything, dictate by voice, or attach an image..."
            className="max-h-32 min-h-[40px] flex-1 resize-none rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
          />

          <button
            type="button"
            onClick={() => {
              if (voiceState === 'speaking' && onBargeInAndListen) {
                onBargeInAndListen();
              } else {
                onMicToggle();
              }
            }}
            title={
              voiceState === 'speaking'
                ? 'Interrupt PRIME and speak immediately (Barge-In)'
                : voiceState === 'listening'
                  ? 'Stop microphone'
                  : 'Start voice input'
            }
            aria-label={
              voiceState === 'speaking'
                ? 'Interrupt and speak'
                : voiceState === 'listening'
                  ? 'Stop microphone'
                  : 'Start microphone'
            }
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border transition-colors ${
              voiceState === 'listening'
                ? 'border-[#38BDF8] bg-[#38BDF8]/15 text-[#38BDF8]'
                : voiceState === 'speaking'
                  ? 'border-[#34D399]/70 bg-[#34D399]/15 text-[#34D399]'
                  : 'border-[#24324A] bg-[#161F30] text-[#E5C07B] hover:border-[#E5C07B]/60'
            }`}
          >
            {voiceState === 'speaking' ? (
              <Mic className="h-4 w-4 animate-pulse" />
            ) : voiceState === 'listening' ? (
              <Square className="h-4 w-4" />
            ) : (
              <Mic className="h-4 w-4" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onSend()}
            disabled={isProcessing || (!draftInput.trim() && !attachedImageDataUrl)}
            className="inline-flex h-10 shrink-0 items-center gap-2 rounded-lg bg-[#E5C07B] px-4 text-sm font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:cursor-not-allowed disabled:opacity-40 whitespace-nowrap"
          >
            <Send className="h-4 w-4" />
            <span>Send</span>
          </button>
        </div>
      </div>

      <HelpShortcutsModal
        open={helpModalOpen}
        wakeWordEnabled={settings.wakeWordEnabled}
        onClose={() => setHelpModalOpen(false)}
        onRunExample={onExecuteVoiceShortcutExample}
      />
    </div>
  );
}
