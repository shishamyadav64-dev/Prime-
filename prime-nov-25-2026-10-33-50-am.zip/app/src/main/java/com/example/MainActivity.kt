package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.prime.PrimeViewModel
import com.example.prime.model.BrainDepth
import com.example.prime.model.VoiceState
import com.example.prime.ui.PrimeCompanionScreen
import com.example.prime.ui.PrimeSkillsScreen
import com.example.prime.ui.PrimeStudioScreen
import com.example.prime.ui.PrimeVaultScreen
import com.example.ui.theme.PrimeBorder
import com.example.ui.theme.PrimeCard
import com.example.ui.theme.PrimeCyan
import com.example.ui.theme.PrimeCyanSoft
import com.example.ui.theme.PrimeGold
import com.example.ui.theme.PrimeGoldSoft
import com.example.ui.theme.PrimeObsidian
import com.example.ui.theme.PrimeSurface
import com.example.ui.theme.PrimeTextPrimary
import com.example.ui.theme.PrimeTextSecondary
import com.example.ui.theme.PrimeTheme

private enum class PrimeTab(val label: String, val icon: ImageVector) {
  COMPANION("PRIME", Icons.Rounded.ChatBubbleOutline),
  SKILLS("Skills", Icons.Rounded.Explore),
  VAULT("Vault", Icons.Rounded.Bookmark),
  STUDIO("Studio", Icons.Rounded.Tune),
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(PrimeObsidian.toArgb()),
      navigationBarStyle = SystemBarStyle.dark(PrimeSurface.toArgb()),
    )
    setContent {
      PrimeTheme {
        PrimeRootApp()
      }
    }
  }
}

@Composable
private fun PrimeRootApp(vm: PrimeViewModel = viewModel()) {
  val context = LocalContext.current
  val settings by vm.settings.collectAsStateWithLifecycle()
  val messages by vm.messages.collectAsStateWithLifecycle()
  val memories by vm.memories.collectAsStateWithLifecycle()
  val tasks by vm.tasks.collectAsStateWithLifecycle()
  val voiceProfiles by vm.voiceProfiles.collectAsStateWithLifecycle()
  val availableDeviceVoices by vm.availableDeviceVoices.collectAsStateWithLifecycle()
  val voiceState by vm.voiceState.collectAsStateWithLifecycle()
  val partialTranscript by vm.partialTranscript.collectAsStateWithLifecycle()
  val audioLevel by vm.audioLevel.collectAsStateWithLifecycle()
  val draftInput by vm.draftInput.collectAsStateWithLifecycle()
  val attachedImagePath by vm.attachedImageUri.collectAsStateWithLifecycle()
  val isProcessing by vm.isProcessing.collectAsStateWithLifecycle()
  val statusBanner by vm.statusBanner.collectAsStateWithLifecycle()

  var currentTab by rememberSaveable { mutableStateOf(PrimeTab.COMPANION) }
  var openVoiceCreatorOnLaunch by rememberSaveable { mutableStateOf(false) }
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(statusBanner) {
    val msg = statusBanner
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      vm.clearStatusBanner()
    }
  }

  val imagePicker =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) vm.attachImageFromUri(uri)
    }

  val audioPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        vm.toggleVoiceListening()
      } else {
        vm.showBanner("Microphone permission is needed for voice input.")
      }
    }

  val handleMicTap: () -> Unit = {
    val hasMic =
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    if (voiceState == VoiceState.SPEAKING || voiceState == VoiceState.LISTENING) {
      vm.toggleVoiceListening()
    } else if (hasMic) {
      vm.toggleVoiceListening()
    } else {
      audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = PrimeObsidian,
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      PrimeTopBar(
        mannerTitle = settings.mannerProfile.title,
        activeVoiceLabel = settings.activeCustomVoiceName,
        brainDepth = settings.brainDepth,
        voiceState = voiceState,
        onToggleBrain = {
          val next =
            if (settings.brainDepth == BrainDepth.HYDROGEN_FAST) BrainDepth.NEON_DEEP
            else BrainDepth.HYDROGEN_FAST
          vm.updateSettings { it.copy(brainDepth = next) }
          vm.showBanner("Switched brain mode to ${next.label}.")
        },
        onCreateVoiceShortcut = {
          openVoiceCreatorOnLaunch = true
          currentTab = PrimeTab.STUDIO
        },
        onGreetOrStop = {
          if (voiceState == VoiceState.SPEAKING) vm.stopVoice() else vm.triggerVoiceGreeting()
        },
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = PrimeSurface,
        contentColor = PrimeTextPrimary,
        tonalElevation = 0.dp,
      ) {
        PrimeTab.entries.forEach { tab ->
          val selected = currentTab == tab
          NavigationBarItem(
            selected = selected,
            onClick = { currentTab = tab },
            icon = { Icon(tab.icon, contentDescription = tab.label) },
            label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
            colors =
              NavigationBarItemDefaults.colors(
                selectedIconColor = PrimeGold,
                selectedTextColor = PrimeGold,
                indicatorColor = PrimeGoldSoft,
                unselectedIconColor = PrimeTextSecondary,
                unselectedTextColor = PrimeTextSecondary,
              ),
          )
        }
      }
    },
  ) { innerPadding ->
    Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      when (currentTab) {
        PrimeTab.COMPANION ->
          PrimeCompanionScreen(
            messages = messages,
            settings = settings,
            voiceState = voiceState,
            audioLevel = audioLevel,
            partialTranscript = partialTranscript,
            draftInput = draftInput,
            attachedImagePath = attachedImagePath,
            isProcessing = isProcessing,
            onDraftChange = vm::updateDraft,
            onSend = vm::sendMessage,
            onPickImage = {
              imagePicker.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            },
            onClearImage = vm::clearAttachedImage,
            onMicTap = handleMicTap,
            onSpeakMessage = vm::speakMessage,
            onStopVoice = vm::stopVoice,
            onNotify = vm::showBanner,
          )

        PrimeTab.SKILLS ->
          PrimeSkillsScreen(
            onActivateSkill = { skill ->
              vm.activateSkill(skill) { currentTab = PrimeTab.COMPANION }
            }
          )

        PrimeTab.VAULT ->
          PrimeVaultScreen(
            tasks = tasks,
            memories = memories,
            onAddTask = vm::addManualTask,
            onToggleTask = vm::toggleTaskCompleted,
            onDeleteTask = vm::deleteTask,
            onAddMemory = vm::addManualMemory,
            onDeleteMemory = vm::deleteMemory,
            onClearMemories = vm::clearAllMemories,
          )

        PrimeTab.STUDIO ->
          PrimeStudioScreen(
            settings = settings,
            voiceProfiles = voiceProfiles,
            availableDeviceVoices = availableDeviceVoices,
            openVoiceCreatorOnLaunch = openVoiceCreatorOnLaunch,
            onConsumeOpenVoiceCreator = { openVoiceCreatorOnLaunch = false },
            onUpdateSettings = vm::updateSettings,
            onPreviewCustomVoice = vm::previewCustomVoice,
            onSaveVoiceProfile = vm::saveAndActivateVoiceProfile,
            onActivateVoiceProfile = vm::activateVoiceProfile,
            onDeleteVoiceProfile = vm::deleteVoiceProfile,
            onTestGreetingVoice = vm::triggerVoiceGreeting,
            onClearChat = {
              vm.clearConversation()
              currentTab = PrimeTab.COMPANION
            },
          )
      }
    }
  }
}

@Composable
private fun PrimeTopBar(
  mannerTitle: String,
  activeVoiceLabel: String?,
  brainDepth: BrainDepth,
  voiceState: VoiceState,
  onToggleBrain: () -> Unit,
  onCreateVoiceShortcut: () -> Unit,
  onGreetOrStop: () -> Unit,
) {
  Surface(
    color = PrimeSurface,
    border = BorderStroke(1.dp, PrimeBorder),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier =
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          color = PrimeGoldSoft,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, PrimeGold.copy(alpha = 0.45f)),
          modifier = Modifier.size(36.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Rounded.AutoAwesome,
              contentDescription = null,
              tint = PrimeGold,
              modifier = Modifier.size(20.dp),
            )
          }
        }
        Column {
          Text(
            text = "PRIME",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = PrimeTextPrimary,
          )
          Text(
            text =
              if (!activeVoiceLabel.isNullOrBlank()) "$mannerTitle • $activeVoiceLabel"
              else mannerTitle,
            style = MaterialTheme.typography.labelSmall,
            color = PrimeTextSecondary,
          )
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Surface(
          onClick = onCreateVoiceShortcut,
          color = PrimeGoldSoft,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, PrimeGold.copy(alpha = 0.5f)),
        ) {
          Text(
            text = if (!activeVoiceLabel.isNullOrBlank()) "Voices" else "+ Voice",
            style = MaterialTheme.typography.labelMedium,
            color = PrimeGold,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
          )
        }

        val isDeep = brainDepth == BrainDepth.NEON_DEEP
        Surface(
          onClick = onToggleBrain,
          color = if (isDeep) PrimeCyanSoft else PrimeCard,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, if (isDeep) PrimeCyan else PrimeBorder),
        ) {
          Text(
            text = if (isDeep) "Deep" else "Fast",
            style = MaterialTheme.typography.labelMedium,
            color = if (isDeep) PrimeCyan else PrimeTextSecondary,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
          )
        }

        Spacer(modifier = Modifier.width(2.dp))

        IconButton(onClick = onGreetOrStop, modifier = Modifier.size(36.dp)) {
          Icon(
            imageVector =
              if (voiceState == VoiceState.SPEAKING) Icons.Rounded.Stop
              else Icons.Rounded.RecordVoiceOver,
            contentDescription = "Voice Greeting",
            tint = PrimeGold,
          )
        }
      }
    }
  }
}
