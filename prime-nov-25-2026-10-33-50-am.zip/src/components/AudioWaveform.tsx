import {useEffect, useRef} from 'react';
import type {VoiceState} from '../types/prime.ts';
import {consumeVoicePulse, sampleLiveSpectrum} from '../utils/audioAnalyser.ts';

interface AudioWaveformProps {
  voiceState: VoiceState;
  partialTranscript?: string;
}

const BAR_COUNT = 44;

export function AudioWaveform({voiceState, partialTranscript}: AudioWaveformProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const smoothedBarsRef = useRef<Float32Array>(new Float32Array(BAR_COUNT));
  const phaseRef = useRef(0);
  const transcriptLenRef = useRef(0);

  const isListening = voiceState === 'listening';
  const isSpeaking = voiceState === 'speaking';
  const isActive = isListening || isSpeaking;

  useEffect(() => {
    const nextLen = partialTranscript?.length ?? 0;
    if (nextLen > transcriptLenRef.current) {
      // Nudge bar energy when speech recognition streams fresh words
      for (let i = 0; i < BAR_COUNT; i++) {
        const dist = Math.abs(i - BAR_COUNT / 2) / (BAR_COUNT / 2);
        smoothedBarsRef.current[i] = Math.max(
          smoothedBarsRef.current[i],
          (1 - dist * 0.55) * (0.45 + Math.random() * 0.4),
        );
      }
    }
    transcriptLenRef.current = nextLen;
  }, [partialTranscript]);

  useEffect(() => {
    if (!isActive) return;

    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    let width = container.clientWidth || 640;
    let height = container.clientHeight || 56;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = Math.max(200, container.clientWidth);
      height = Math.max(44, container.clientHeight);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();

    const observer = new ResizeObserver(resize);
    observer.observe(container);

    const spectrumBuffer = new Uint8Array(new ArrayBuffer(64));
    let rafId = 0;

    const renderFrame = () => {
      const primaryColor = isListening ? '#38BDF8' : '#34D399';
      const secondaryColor = '#E5C07B';

      const hasRealAudio = sampleLiveSpectrum(spectrumBuffer);
      const pulse = consumeVoicePulse();
      phaseRef.current += prefersReducedMotion ? 0.02 : isSpeaking ? 0.12 : 0.085;
      const t = phaseRef.current;

      ctx.clearRect(0, 0, width, height);

      // Subtle centerline reference
      const midY = height / 2;
      ctx.strokeStyle = 'rgba(36, 50, 74, 0.7)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, midY);
      ctx.lineTo(width, midY);
      ctx.stroke();

      const bars = smoothedBarsRef.current;
      const horizontalPad = 8;
      const usableWidth = width - horizontalPad * 2;
      const step = usableWidth / BAR_COUNT;
      const barWidth = Math.max(2, Math.min(4.5, step * 0.45));
      const maxAmp = height * 0.42;

      for (let i = 0; i < BAR_COUNT; i++) {
        const centerFactor = 1 - Math.abs(i - (BAR_COUNT - 1) / 2) / (BAR_COUNT * 0.56);
        let targetEnergy = 0.08;

        if (prefersReducedMotion) {
          targetEnergy = 0.25 * Math.max(0.2, centerFactor);
        } else if (hasRealAudio) {
          // Fold symmetric FFT bins from the center outward for balanced stereo silhouette
          const mirrorIndex = Math.floor(
            (Math.abs(i - (BAR_COUNT - 1) / 2) / (BAR_COUNT / 2)) * 26,
          );
          const rawBin = spectrumBuffer[Math.min(spectrumBuffer.length - 1, mirrorIndex)] ?? 0;
          targetEnergy = Math.max(0.08, Math.pow(rawBin / 255, 0.85) * (0.45 + centerFactor * 0.65));
        } else {
          // Smooth multi-harmonic modulation synced with speech/word-boundary pulses
          const harmonicA = Math.sin(t * 1.6 + i * 0.34);
          const harmonicB = Math.cos(t * 2.3 - i * 0.21);
          const carrier = 0.5 + 0.5 * (harmonicA * 0.6 + harmonicB * 0.4);
          const envelope = (isSpeaking ? 0.38 : 0.26) + pulse * 0.6;
          targetEnergy = Math.max(0.08, carrier * envelope * Math.max(0.25, centerFactor));
        }

        bars[i] = bars[i] * 0.72 + targetEnergy * 0.28;

        const barHalfH = Math.max(2, bars[i] * maxAmp);
        const x = horizontalPad + i * step + (step - barWidth) / 2;
        const y = midY - barHalfH;
        const fullH = barHalfH * 2;

        const barGrad = ctx.createLinearGradient(x, y, x, y + fullH);
        barGrad.addColorStop(0, primaryColor);
        barGrad.addColorStop(0.5, secondaryColor);
        barGrad.addColorStop(1, primaryColor);

        ctx.fillStyle = barGrad;
        ctx.globalAlpha = 0.28 + Math.min(0.72, bars[i] * 0.9);
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, fullH, barWidth / 2);
        ctx.fill();
      }

      // Flowing continuous harmonic ribbon overlay across the spectrum
      ctx.globalAlpha = 0.9;
      const lineGrad = ctx.createLinearGradient(0, 0, width, 0);
      lineGrad.addColorStop(0, 'rgba(56, 189, 248, 0.15)');
      lineGrad.addColorStop(0.25, primaryColor);
      lineGrad.addColorStop(0.5, secondaryColor);
      lineGrad.addColorStop(0.75, primaryColor);
      lineGrad.addColorStop(1, 'rgba(229, 192, 123, 0.15)');

      ctx.strokeStyle = lineGrad;
      ctx.lineWidth = 1.75;
      ctx.beginPath();

      for (let i = 0; i < BAR_COUNT; i++) {
        const x = horizontalPad + i * step + step / 2;
        const sign = i % 2 === 0 ? 1 : -1;
        const offset = bars[i] * maxAmp * 0.85 * Math.sin(t * 1.4 + i * 0.45) * sign * 0.7;
        const y = midY + offset;
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          const prevX = horizontalPad + (i - 1) * step + step / 2;
          const prevSign = (i - 1) % 2 === 0 ? 1 : -1;
          const prevY =
            midY +
            bars[i - 1] * maxAmp * 0.85 * Math.sin(t * 1.4 + (i - 1) * 0.45) * prevSign * 0.7;
          const cpX = (prevX + x) / 2;
          ctx.quadraticCurveTo(cpX, prevY, x, y);
        }
      }
      ctx.stroke();
      ctx.globalAlpha = 1;

      rafId = window.requestAnimationFrame(renderFrame);
    };

    rafId = window.requestAnimationFrame(renderFrame);

    return () => {
      window.cancelAnimationFrame(rafId);
      observer.disconnect();
    };
  }, [isActive, isListening, isSpeaking]);

  if (!isActive) return null;

  return (
    <section
      aria-label={isListening ? 'Live voice input waveform' : 'PRIME speech output waveform'}
      className="flex items-center gap-4 rounded-xl border border-[#24324A] bg-[#080C14] px-4 py-2.5"
    >
      <div className="shrink-0">
        <p
          className={`text-xs font-semibold ${
            isListening ? 'text-[#38BDF8]' : 'text-[#34D399]'
          }`}
        >
          {isListening ? 'Listening' : 'Speaking'}
        </p>
        <p className="text-[11px] text-[#94A3B8]">
          {isListening ? 'Microphone active' : 'Voice output'}
        </p>
      </div>

      <div ref={containerRef} className="h-12 min-w-0 flex-1">
        <canvas ref={canvasRef} className="block h-full w-full" />
      </div>
    </section>
  );
}
