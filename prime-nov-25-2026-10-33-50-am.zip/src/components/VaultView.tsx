import {useEffect, useMemo, useState} from 'react';
import {
  AlertTriangle,
  ArrowUpDown,
  Check,
  CheckSquare,
  ChevronDown,
  ChevronUp,
  Clock,
  Download,
  Eye,
  EyeOff,
  GripVertical,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  Square,
  Tag,
  Trash2,
  X,
} from 'lucide-react';
import type {MemoryItem, SubTask, TaskItem} from '../types/prime.ts';
import {formatRemainingTime, isTaskOverdue, resolveTaskDueMs} from '../utils/taskHelpers.ts';

interface VaultViewProps {
  memories: MemoryItem[];
  tasks: TaskItem[];
  requestedTab?: 'agenda' | 'memories' | null;
  clearMemorySignal?: number;
  onAddTask: (
    title: string,
    priority: TaskItem['priority'],
    dueNote: string,
    dueAtMs?: number | null,
    autoStartOnDue?: boolean,
    tags?: string[],
  ) => Promise<void>;
  onToggleTask: (id: string) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
  onUpdateTaskDetails: (
    id: string,
    patch: {
      notes?: string;
      subTasks?: SubTask[];
      tags?: string[];
      dueNote?: string;
      dueAtMs?: number | null;
      autoStartOnDue?: boolean;
    },
  ) => Promise<void>;
  onBulkToggleTasks: (ids: string[]) => Promise<void>;
  onBulkDeleteTasks: (ids: string[]) => Promise<void>;
  onReorderTasks: (orderedIds: string[]) => Promise<void>;
  onAddMemory: (category: MemoryItem['category'], fact: string) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  onClearMemories: () => Promise<void>;
  onRetryTask?: (id: string) => Promise<void>;
  onRetryAllFailed?: () => Promise<void>;
  onRefresh: () => Promise<void>;
  onNotify: (msg: string) => void;
}

type TaskSortOrder = 'manual' | 'priority_desc' | 'priority_asc' | 'newest';
type TaskPriorityFilter = 'All' | 'High' | 'Normal' | 'Low';

const PRIORITIES: Array<{value: TaskItem['priority']; label: string}> = [
  {value: 'High', label: 'High'},
  {value: 'Normal', label: 'Medium'},
  {value: 'Low', label: 'Low'},
];

const PRIORITY_FILTERS: Array<{value: TaskPriorityFilter; label: string}> = [
  {value: 'All', label: 'All'},
  {value: 'High', label: 'High'},
  {value: 'Normal', label: 'Medium'},
  {value: 'Low', label: 'Low'},
];

const SORT_OPTIONS: Array<{value: TaskSortOrder; label: string}> = [
  {value: 'manual', label: 'Custom'},
  {value: 'priority_desc', label: 'High → Low'},
  {value: 'priority_asc', label: 'Low → High'},
  {value: 'newest', label: 'Latest'},
];

const MEMORY_CATEGORIES: MemoryItem['category'][] = [
  'Preference',
  'Goal',
  'Identity',
  'Routine',
  'Learned',
  'Note',
];

function getPriorityRank(priority: TaskItem['priority'] | string): number {
  const norm = String(priority).toLowerCase();
  if (norm === 'high') return 3;
  if (norm === 'low') return 1;
  return 2;
}

function getPriorityLabel(priority: TaskItem['priority'] | string): string {
  const norm = String(priority).toLowerCase();
  if (norm === 'high') return 'High';
  if (norm === 'low') return 'Low';
  return 'Medium';
}

function sortTasksByMode(list: TaskItem[], sortOrder: TaskSortOrder): TaskItem[] {
  if (sortOrder === 'manual') {
    return list;
  }
  const copy = [...list];
  if (sortOrder === 'newest') {
    return copy.sort((a, b) => b.createdAtMs - a.createdAtMs);
  }
  return copy.sort((a, b) => {
    const rankDiff = getPriorityRank(a.priority) - getPriorityRank(b.priority);
    if (rankDiff !== 0) {
      return sortOrder === 'priority_desc' ? -rankDiff : rankDiff;
    }
    return b.createdAtMs - a.createdAtMs;
  });
}

function formatDateLabel(ms: number): string {
  return new Date(ms).toLocaleDateString([], {
    month: 'short',
    day: 'numeric',
  });
}

function toDatetimeLocalValue(ms: number | null | undefined): string {
  if (!ms || !Number.isFinite(ms)) return '';
  const d = new Date(ms);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function csvEscape(val: string): string {
  const s = String(val ?? '');
  if (/[",\n\r]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function parseTagInput(raw: string): string[] {
  const parts = raw.split(',');
  const seen = new Set<string>();
  const tags: string[] = [];
  for (const part of parts) {
    const cleaned = part
      .trim()
      .replace(/^#+/, '')
      .replace(/\s+/g, ' ')
      .slice(0, 28);
    if (!cleaned) continue;
    const key = cleaned.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    tags.push(cleaned);
    if (tags.length >= 12) break;
  }
  return tags;
}

function mergeUniqueTags(existing: string[] | undefined, incoming: string[]): string[] {
  const combined = [...(existing ?? []), ...incoming];
  const seen = new Set<string>();
  const result: string[] = [];
  for (const raw of combined) {
    const cleaned = raw.trim().replace(/^#+/, '').replace(/\s+/g, ' ').slice(0, 28);
    if (!cleaned) continue;
    const key = cleaned.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(cleaned);
    if (result.length >= 12) break;
  }
  return result;
}

export function VaultView({
  memories,
  tasks,
  requestedTab,
  clearMemorySignal,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onUpdateTaskDetails,
  onBulkToggleTasks,
  onBulkDeleteTasks,
  onReorderTasks,
  onAddMemory,
  onDeleteMemory,
  onClearMemories,
  onRetryTask,
  onRetryAllFailed,
  onRefresh,
  onNotify,
}: VaultViewProps) {
  const [activeTab, setActiveTab] = useState<'agenda' | 'memories'>('agenda');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Live clock for overdue & countdown indicators
  const [nowMs, setNowMs] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNowMs(Date.now()), 5000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (requestedTab) setActiveTab(requestedTab);
  }, [requestedTab]);

  useEffect(() => {
    if (clearMemorySignal && clearMemorySignal > 0) {
      setActiveTab('memories');
      if (memories.length > 0) {
        setConfirmClearOpen(true);
      }
    }
  }, [clearMemorySignal, memories.length]);

  // Task form state
  const [taskTitle, setTaskTitle] = useState('');
  const [taskPriority, setTaskPriority] = useState<TaskItem['priority']>('Normal');
  const [taskDue, setTaskDue] = useState('');
  const [taskDueDatetime, setTaskDueDatetime] = useState('');
  const [taskAutoStart, setTaskAutoStart] = useState(false);
  const [taskTagsInput, setTaskTagsInput] = useState('');
  const [isSubmittingTask, setIsSubmittingTask] = useState(false);

  // Task search, sorting, filtering, bulk selection, drag-and-drop & expansion state
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<TaskSortOrder>('priority_desc');
  const [priorityFilter, setPriorityFilter] = useState<TaskPriorityFilter>('All');
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [showCompleted, setShowCompleted] = useState(true);
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>([]);
  const [isBulkSubmitting, setIsBulkSubmitting] = useState(false);
  const [confirmBulkDeleteOpen, setConfirmBulkDeleteOpen] = useState(false);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dragOverTarget, setDragOverTarget] = useState<{
    id: string;
    position: 'before' | 'after';
  } | null>(null);

  // Expandable task notes, subtasks & tags
  const [expandedTaskIds, setExpandedTaskIds] = useState<Record<string, boolean>>({});
  const [noteDrafts, setNoteDrafts] = useState<Record<string, string>>({});
  const [subTaskDrafts, setSubTaskDrafts] = useState<Record<string, string>>({});
  const [tagDrafts, setTagDrafts] = useState<Record<string, string>>({});

  // Memory form state
  const [memCategory, setMemCategory] = useState<MemoryItem['category']>('Preference');
  const [memFact, setMemFact] = useState('');
  const [isSubmittingMem, setIsSubmittingMem] = useState(false);

  // Clear confirmation modal
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  const pendingTasks = useMemo(() => tasks.filter((t) => !t.isCompleted), [tasks]);
  const allCompletedTasks = useMemo(() => tasks.filter((t) => t.isCompleted), [tasks]);

  // Aggregate unique custom tags across all agenda items
  const tagOptions = useMemo(() => {
    const map = new Map<string, {key: string; label: string; total: number; pending: number}>();
    for (const task of tasks) {
      for (const rawTag of task.tags ?? []) {
        const clean = rawTag.trim();
        if (!clean) continue;
        const key = clean.toLowerCase();
        const existing = map.get(key);
        if (existing) {
          existing.total += 1;
          if (!task.isCompleted) existing.pending += 1;
        } else {
          map.set(key, {
            key,
            label: clean,
            total: 1,
            pending: task.isCompleted ? 0 : 1,
          });
        }
      }
    }
    return Array.from(map.values()).sort(
      (a, b) => b.pending - a.pending || a.label.localeCompare(b.label),
    );
  }, [tasks]);

  useEffect(() => {
    if (
      selectedTag !== 'All' &&
      selectedTag !== '__grouped__' &&
      !tagOptions.some((opt) => opt.key === selectedTag)
    ) {
      setSelectedTag('All');
    }
  }, [selectedTag, tagOptions]);

  // Summary analytics
  const summaryStats = useMemo(() => {
    const total = tasks.length;
    const done = allCompletedTasks.length;
    const completionPct = total === 0 ? 0 : Math.round((done / total) * 100);
    const highCount = tasks.filter((t) => getPriorityRank(t.priority) === 3).length;
    const mediumCount = tasks.filter((t) => getPriorityRank(t.priority) === 2).length;
    const lowCount = tasks.filter((t) => getPriorityRank(t.priority) === 1).length;
    const overdueCount = pendingTasks.filter((t) => isTaskOverdue(t, nowMs)).length;
    const failedCount = pendingTasks.filter(
      (t) => t.status === 'failed' || Boolean(t.lastError) || isTaskOverdue(t, nowMs),
    ).length;
    return {
      total,
      done,
      pending: pendingTasks.length,
      completionPct,
      highCount,
      mediumCount,
      lowCount,
      overdueCount,
      failedCount,
    };
  }, [tasks, allCompletedTasks.length, pendingTasks, nowMs]);

  const normalizedQuery = searchQuery.trim().toLowerCase();

  const matchesActiveFilters = (t: TaskItem): boolean => {
    if (
      priorityFilter !== 'All' &&
      getPriorityRank(t.priority) !== getPriorityRank(priorityFilter)
    ) {
      return false;
    }
    if (
      selectedTag !== 'All' &&
      selectedTag !== '__grouped__' &&
      !(t.tags ?? []).some((tag) => tag.trim().toLowerCase() === selectedTag)
    ) {
      return false;
    }
    if (normalizedQuery) {
      if (!t.title.toLowerCase().includes(normalizedQuery)) return false;
    }
    return true;
  };

  const sortedPendingTasks = useMemo(
    () => sortTasksByMode(pendingTasks.filter(matchesActiveFilters), sortOrder),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [pendingTasks, priorityFilter, selectedTag, normalizedQuery, sortOrder],
  );

  const groupedPendingSections = useMemo(() => {
    if (selectedTag !== '__grouped__') return [];
    const groups = new Map<string, {key: string; label: string; tasks: TaskItem[]}>();
    const untagged: TaskItem[] = [];

    for (const task of sortedPendingTasks) {
      const taskTags = (task.tags ?? []).map((t) => t.trim()).filter(Boolean);
      if (taskTags.length === 0) {
        untagged.push(task);
        continue;
      }
      for (const rawTag of taskTags) {
        const key = rawTag.toLowerCase();
        const existing = groups.get(key);
        if (existing) {
          existing.tasks.push(task);
        } else {
          groups.set(key, {key, label: `#${rawTag}`, tasks: [task]});
        }
      }
    }

    const ordered = Array.from(groups.values()).sort((a, b) =>
      a.label.localeCompare(b.label),
    );
    if (untagged.length > 0) {
      ordered.push({key: '__untagged__', label: 'Untagged', tasks: untagged});
    }
    return ordered;
  }, [selectedTag, sortedPendingTasks]);

  const completedTasks = useMemo(
    () => sortTasksByMode(allCompletedTasks.filter(matchesActiveFilters), sortOrder),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [allCompletedTasks, priorityFilter, selectedTag, normalizedQuery, sortOrder],
  );

  useEffect(() => {
    const validIds = new Set(tasks.map((t) => t.id));
    setSelectedTaskIds((prev) => {
      const next = prev.filter((id) => validIds.has(id));
      return next.length === prev.length ? prev : next;
    });
  }, [tasks]);

  const visibleTaskIds = useMemo(() => {
    const ids = sortedPendingTasks.map((t) => t.id);
    if (showCompleted) {
      ids.push(...completedTasks.map((t) => t.id));
    }
    return ids;
  }, [sortedPendingTasks, completedTasks, showCompleted]);

  const selectedSet = useMemo(() => new Set(selectedTaskIds), [selectedTaskIds]);

  const selectedPendingIds = useMemo(
    () => tasks.filter((t) => selectedSet.has(t.id) && !t.isCompleted).map((t) => t.id),
    [tasks, selectedSet],
  );

  const selectedCompletedIds = useMemo(
    () => tasks.filter((t) => selectedSet.has(t.id) && t.isCompleted).map((t) => t.id),
    [tasks, selectedSet],
  );

  const allVisibleSelected =
    visibleTaskIds.length > 0 && visibleTaskIds.every((id) => selectedSet.has(id));

  const toggleSelectTask = (id: string) => {
    setSelectedTaskIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleToggleSelectAllVisible = () => {
    if (allVisibleSelected) {
      setSelectedTaskIds([]);
    } else {
      setSelectedTaskIds(visibleTaskIds);
    }
  };

  const handleBulkToggleIds = async (ids: string[]) => {
    if (ids.length === 0 || isBulkSubmitting) return;
    setIsBulkSubmitting(true);
    try {
      await onBulkToggleTasks(ids);
      setSelectedTaskIds([]);
    } finally {
      setIsBulkSubmitting(false);
    }
  };

  const handleConfirmBulkDelete = async () => {
    if (selectedTaskIds.length === 0 || isBulkSubmitting) return;
    setIsBulkSubmitting(true);
    try {
      await onBulkDeleteTasks(selectedTaskIds);
      setSelectedTaskIds([]);
      setConfirmBulkDeleteOpen(false);
    } finally {
      setIsBulkSubmitting(false);
    }
  };

  const commitPendingOrder = async (nextVisibleIds: string[]) => {
    const visibleSet = new Set(nextVisibleIds);
    const basePending = sortTasksByMode(pendingTasks, sortOrder);
    let cursor = 0;
    const mergedPendingIds = basePending.map((t) =>
      visibleSet.has(t.id) ? nextVisibleIds[cursor++] : t.id,
    );
    const fullOrderedIds = [
      ...mergedPendingIds,
      ...tasks.filter((t) => t.isCompleted).map((t) => t.id),
    ];
    setSortOrder('manual');
    await onReorderTasks(fullOrderedIds);
  };

  const handleDropOnTask = async (targetId: string, position: 'before' | 'after') => {
    const sourceId = draggedTaskId;
    setDraggedTaskId(null);
    setDragOverTarget(null);
    if (!sourceId || sourceId === targetId) return;

    const currentVisible = sortedPendingTasks.map((t) => t.id);
    const withoutSource = currentVisible.filter((id) => id !== sourceId);
    const targetIdx = withoutSource.indexOf(targetId);
    if (targetIdx === -1) return;
    const insertIdx = position === 'after' ? targetIdx + 1 : targetIdx;
    withoutSource.splice(insertIdx, 0, sourceId);
    await commitPendingOrder(withoutSource);
  };

  const handleStepTaskOrder = async (taskId: string, direction: -1 | 1) => {
    const currentVisible = sortedPendingTasks.map((t) => t.id);
    const idx = currentVisible.indexOf(taskId);
    const nextIdx = idx + direction;
    if (idx === -1 || nextIdx < 0 || nextIdx >= currentVisible.length) return;
    const copy = [...currentVisible];
    const [item] = copy.splice(idx, 1);
    copy.splice(nextIdx, 0, item);
    await commitPendingOrder(copy);
  };

  const handleTaskSubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const trimmed = taskTitle.trim();
    if (!trimmed || isSubmittingTask) return;
    setIsSubmittingTask(true);
    try {
      const parsedDueMs = taskDueDatetime ? Date.parse(taskDueDatetime) : null;
      const validDueMs =
        parsedDueMs !== null && Number.isFinite(parsedDueMs) ? parsedDueMs : null;
      const parsedTags = parseTagInput(taskTagsInput);
      await onAddTask(
        trimmed,
        taskPriority,
        taskDue.trim(),
        validDueMs,
        taskAutoStart,
        parsedTags,
      );
      setTaskTitle('');
      setTaskDue('');
      setTaskDueDatetime('');
      setTaskAutoStart(false);
      setTaskTagsInput('');
      setTaskPriority('Normal');
    } finally {
      setIsSubmittingTask(false);
    }
  };

  const handleQuickTimerPreset = (minutesFromNow: number) => {
    const target = Date.now() + minutesFromNow * 60_000;
    setTaskDueDatetime(toDatetimeLocalValue(target));
    setTaskAutoStart(true);
  };

  const toggleExpandTask = (task: TaskItem) => {
    setExpandedTaskIds((prev) => {
      const nextOpen = !prev[task.id];
      if (nextOpen && noteDrafts[task.id] === undefined) {
        setNoteDrafts((d) => ({...d, [task.id]: task.notes ?? ''}));
      }
      return {...prev, [task.id]: nextOpen};
    });
  };

  const handleAddSubTask = async (task: TaskItem) => {
    const title = (subTaskDrafts[task.id] ?? '').trim();
    if (!title) return;
    const nextSubTasks: SubTask[] = [
      ...(task.subTasks ?? []),
      {
        id: `sub_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        title,
        isCompleted: false,
      },
    ];
    setSubTaskDrafts((prev) => ({...prev, [task.id]: ''}));
    await onUpdateTaskDetails(task.id, {subTasks: nextSubTasks});
  };

  const handleToggleSubTask = async (task: TaskItem, subId: string) => {
    const nextSubTasks = (task.subTasks ?? []).map((s) =>
      s.id === subId ? {...s, isCompleted: !s.isCompleted} : s,
    );
    await onUpdateTaskDetails(task.id, {subTasks: nextSubTasks});
  };

  const handleDeleteSubTask = async (task: TaskItem, subId: string) => {
    const nextSubTasks = (task.subTasks ?? []).filter((s) => s.id !== subId);
    await onUpdateTaskDetails(task.id, {subTasks: nextSubTasks});
  };

  const handleSaveTaskNotes = async (task: TaskItem) => {
    const notes = noteDrafts[task.id] ?? task.notes ?? '';
    await onUpdateTaskDetails(task.id, {notes});
    onNotify(`Saved notes for "${task.title}".`);
  };

  const handleAddTaskTags = async (task: TaskItem) => {
    const incoming = parseTagInput(tagDrafts[task.id] ?? '');
    if (incoming.length === 0) return;
    const nextTags = mergeUniqueTags(task.tags, incoming);
    setTagDrafts((prev) => ({...prev, [task.id]: ''}));
    await onUpdateTaskDetails(task.id, {tags: nextTags});
  };

  const handleRemoveTaskTag = async (task: TaskItem, tagToRemove: string) => {
    const nextTags = (task.tags ?? []).filter(
      (tag) => tag.toLowerCase() !== tagToRemove.toLowerCase(),
    );
    await onUpdateTaskDetails(task.id, {tags: nextTags});
  };

  const handleExportJson = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      tasks,
      memories,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prime-vault-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Exported Vault tasks and memories as JSON.');
  };

  const handleExportCsv = () => {
    const rows: string[] = [
      [
        'Type',
        'ID',
        'Category/Priority',
        'Title/Fact',
        'Status',
        'Tags',
        'DueNote',
        'Notes',
        'CreatedAt',
      ].join(','),
    ];
    for (const t of tasks) {
      rows.push(
        [
          'Task',
          t.id,
          getPriorityLabel(t.priority),
          t.title,
          t.isCompleted ? 'Completed' : isTaskOverdue(t, nowMs) ? 'Overdue' : 'Pending',
          (t.tags ?? []).join('; '),
          t.dueNote || (t.dueAtMs ? new Date(t.dueAtMs).toISOString() : ''),
          t.notes || '',
          new Date(t.createdAtMs).toISOString(),
        ]
          .map(csvEscape)
          .join(','),
      );
    }
    for (const m of memories) {
      rows.push(
        [
          'Memory',
          m.id,
          m.category,
          m.fact,
          'Stored',
          '',
          '',
          '',
          new Date(m.createdAtMs).toISOString(),
        ]
          .map(csvEscape)
          .join(','),
      );
    }
    const blob = new Blob([rows.join('\n')], {type: 'text/csv;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prime-vault-backup-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('Exported Vault tasks and memories as CSV.');
  };

  const handleRefreshClick = async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      await onRefresh();
      setNowMs(Date.now());
      onNotify('Vault & Agenda refreshed.');
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleMemorySubmit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const trimmed = memFact.trim();
    if (!trimmed || isSubmittingMem) return;
    setIsSubmittingMem(true);
    try {
      await onAddMemory(memCategory, trimmed);
      setMemFact('');
    } finally {
      setIsSubmittingMem(false);
    }
  };

  const ringRadius = 20;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset =
    ringCircumference - (summaryStats.completionPct / 100) * ringCircumference;

  return (
    <div className="flex h-full flex-col gap-5 overflow-y-auto pr-1">
      {/* Header & controls */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#24324A] pb-4">
        <div>
          <h1 className="font-display text-2xl font-semibold text-[#F1F5F9]">
            Vault &amp; Executive Agenda
          </h1>
          <p className="mt-1 text-sm text-[#94A3B8]">
            Manage persistent personal context and prioritized focus items remembered by PRIME.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-2.5 py-1">
            <Tag className="h-3.5 w-3.5 shrink-0 text-[#38BDF8]" />
            <select
              aria-label="Filter tasks by tag"
              value={selectedTag}
              onChange={(ev) => {
                setActiveTab('agenda');
                setSelectedTag(ev.target.value);
              }}
              className="bg-transparent text-xs font-medium text-[#F1F5F9] focus:outline-none"
            >
              <option value="All" className="bg-[#101724] text-[#F1F5F9]">
                All Tags ({tasks.length})
              </option>
              <option value="__grouped__" className="bg-[#101724] text-[#E5C07B]">
                Group by Custom Tags
              </option>
              {tagOptions.map((opt) => (
                <option key={opt.key} value={opt.key} className="bg-[#101724] text-[#F1F5F9]">
                  #{opt.label} ({opt.total})
                </option>
              ))}
            </select>
          </div>

          <button
            type="button"
            disabled={isRefreshing}
            onClick={handleRefreshClick}
            aria-label="Refresh Vault"
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#94A3B8] transition-colors hover:border-[#E5C07B]/60 hover:text-[#F1F5F9] whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? 'animate-spin text-[#E5C07B]' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            type="button"
            onClick={handleExportJson}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#94A3B8] transition-colors hover:border-[#E5C07B]/60 hover:text-[#E5C07B] whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export JSON</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#94A3B8] transition-colors hover:border-[#E5C07B]/60 hover:text-[#E5C07B] whitespace-nowrap shrink-0"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>

          {summaryStats.failedCount > 0 && onRetryAllFailed && (
            <button
              type="button"
              onClick={() => void onRetryAllFailed()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#FB7185]/60 bg-[#101724] px-3 py-1.5 text-xs font-semibold text-[#FB7185] transition-colors hover:border-[#FB7185] whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Do Again Failed ({summaryStats.failedCount})</span>
            </button>
          )}

          <div className="flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#101724] p-1">
            <button
              type="button"
              onClick={() => setActiveTab('agenda')}
              className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 font-mono-tabular ${
                activeTab === 'agenda'
                  ? 'bg-[#161F30] text-[#E5C07B]'
                  : 'text-[#94A3B8] hover:text-[#F1F5F9]'
              }`}
            >
              Agenda · {pendingTasks.length}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('memories')}
              className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 font-mono-tabular ${
                activeTab === 'memories'
                  ? 'bg-[#161F30] text-[#E5C07B]'
                  : 'text-[#94A3B8] hover:text-[#F1F5F9]'
              }`}
            >
              Memory Vault · {memories.length}
            </button>
          </div>
        </div>
      </div>

      {/* Top Local Search Input Bar for Visible Tasks */}
      {activeTab === 'agenda' && (
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#64748B]" />
          <input
            type="search"
            aria-label="Search tasks by title"
            value={searchQuery}
            onChange={(ev) => setSearchQuery(ev.target.value)}
            placeholder="Search visible tasks by title..."
            className="w-full rounded-xl border border-[#24324A] bg-[#101724] py-2.5 pl-10 pr-28 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
          />
          {searchQuery && (
            <div className="absolute right-3 top-1/2 flex -translate-y-1/2 items-center gap-2">
              <span className="text-xs font-mono-tabular text-[#94A3B8]">
                {sortedPendingTasks.length + (showCompleted ? completedTasks.length : 0)} match
              </span>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Clear task search"
                className="rounded p-1 text-[#94A3B8] hover:text-[#F1F5F9]"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Summary Dashboard with Completion & Priority Distribution Charts */}
      <section
        aria-label="Vault Task Summary"
        className="grid grid-cols-1 gap-4 rounded-xl border border-[#24324A] bg-[#101724] p-4 md:grid-cols-12"
      >
        {/* Completion Ring + KPI */}
        <div className="flex items-center gap-4 md:col-span-5">
          <svg
            width="52"
            height="52"
            viewBox="0 0 52 52"
            className="-rotate-90 shrink-0"
            aria-hidden="true"
          >
            <circle
              cx="26"
              cy="26"
              r={ringRadius}
              fill="none"
              stroke="#161F30"
              strokeWidth="6"
            />
            <circle
              cx="26"
              cy="26"
              r={ringRadius}
              fill="none"
              stroke="#34D399"
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={ringCircumference}
              strokeDashoffset={ringOffset}
            />
          </svg>
          <div className="min-w-0">
            <p className="text-xs font-medium text-[#94A3B8]">Task Completion</p>
            <p className="font-display text-xl font-semibold text-[#F1F5F9] font-mono-tabular">
              {summaryStats.completionPct}%
            </p>
            <p className="text-xs text-[#94A3B8] font-mono-tabular">
              {summaryStats.done} of {summaryStats.total} done
              {summaryStats.overdueCount > 0 ? (
                <span className="text-[#FB7185]"> · {summaryStats.overdueCount} overdue</span>
              ) : null}
            </p>
          </div>
        </div>

        {/* Priority Distribution Stacked Bar Chart */}
        <div className="flex flex-col justify-center gap-2 md:col-span-7">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono-tabular">
            <span>Priority Distribution</span>
            <span>
              <span className="text-[#E5C07B]">High {summaryStats.highCount}</span> ·{' '}
              <span className="text-[#38BDF8]">Med {summaryStats.mediumCount}</span> ·{' '}
              <span className="text-[#94A3B8]">Low {summaryStats.lowCount}</span> ·{' '}
              <span>Vault {memories.length}</span>
            </span>
          </div>

          <div
            className="flex h-3 w-full overflow-hidden rounded-full bg-[#080C14]"
            role="img"
            aria-label={`Priority distribution: ${summaryStats.highCount} high, ${summaryStats.mediumCount} medium, ${summaryStats.lowCount} low`}
          >
            {summaryStats.total === 0 ? (
              <div className="h-full w-full bg-[#161F30]" />
            ) : (
              <>
                <div
                  className="h-full bg-[#E5C07B] transition-all duration-200"
                  style={{width: `${(summaryStats.highCount / summaryStats.total) * 100}%`}}
                />
                <div
                  className="h-full bg-[#38BDF8] transition-all duration-200"
                  style={{width: `${(summaryStats.mediumCount / summaryStats.total) * 100}%`}}
                />
                <div
                  className="h-full bg-[#64748B] transition-all duration-200"
                  style={{width: `${(summaryStats.lowCount / summaryStats.total) * 100}%`}}
                />
              </>
            )}
          </div>
        </div>
      </section>

      {activeTab === 'agenda' ? (
        <div className="flex flex-col gap-5">
          {/* Add Task Form */}
          <form
            onSubmit={handleTaskSubmit}
            className="rounded-xl border border-[#24324A] bg-[#101724] p-5"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-sm font-semibold text-[#F1F5F9]">Add Focus Task</h2>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-[#94A3B8]">Quick timer:</span>
                {[
                  {label: '+1m', mins: 1},
                  {label: '+15m', mins: 15},
                  {label: '+1h', mins: 60},
                ].map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => handleQuickTimerPreset(preset.mins)}
                    className="rounded-md border border-[#24324A] bg-[#080C14] px-2 py-0.5 font-mono-tabular text-[#E5C07B] hover:border-[#E5C07B]"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-12">
              <input
                type="text"
                value={taskTitle}
                onChange={(ev) => setTaskTitle(ev.target.value)}
                placeholder="Describe a task or reminder..."
                className="md:col-span-5 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
              />
              <select
                aria-label="Task priority"
                value={taskPriority}
                onChange={(ev) => setTaskPriority(ev.target.value as TaskItem['priority'])}
                className="md:col-span-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              >
                {PRIORITIES.map((p) => (
                  <option key={p.value} value={p.value}>
                    {p.label} Priority
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={taskDue}
                onChange={(ev) => setTaskDue(ev.target.value)}
                placeholder="Note (e.g. Today 5 PM)"
                className="md:col-span-2 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
              />
              <input
                type="datetime-local"
                aria-label="Due date and time"
                value={taskDueDatetime}
                onChange={(ev) => setTaskDueDatetime(ev.target.value)}
                className="md:col-span-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              />
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex min-w-0 flex-1 flex-wrap items-center gap-3">
                <div className="relative min-w-[220px] flex-1 max-w-md">
                  <Tag className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#64748B]" />
                  <input
                    type="text"
                    aria-label="Task tags"
                    value={taskTagsInput}
                    onChange={(ev) => setTaskTagsInput(ev.target.value)}
                    placeholder="Tags (comma-separated, e.g. Work, Finance)"
                    className="w-full rounded-lg border border-[#24324A] bg-[#080C14] py-1.5 pl-8 pr-3 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                  />
                </div>
                {tagOptions.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-[#94A3B8]">
                    <span>Reuse:</span>
                    {tagOptions.slice(0, 5).map((opt) => (
                      <button
                        key={opt.key}
                        type="button"
                        onClick={() => {
                          const merged = mergeUniqueTags(parseTagInput(taskTagsInput), [opt.label]);
                          setTaskTagsInput(merged.join(', '));
                        }}
                        className="font-mono-tabular text-[#38BDF8] hover:text-[#E5C07B] hover:underline whitespace-nowrap shrink-0"
                      >
                        #{opt.label}
                      </button>
                    ))}
                  </div>
                )}
                <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-[#94A3B8]">
                  <input
                    type="checkbox"
                    checked={taskAutoStart}
                    onChange={(ev) => setTaskAutoStart(ev.target.checked)}
                    className="h-3.5 w-3.5 rounded border-[#24324A] bg-[#080C14] accent-[#E5C07B]"
                  />
                  <span>Auto-start when time limit is over</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={!taskTitle.trim() || isSubmittingTask}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#E5C07B] px-4 py-2 text-sm font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap"
              >
                <Plus className="h-4 w-4" />
                <span>Add Task</span>
              </button>
            </div>
          </form>

          {/* Agenda Controls */}
          <section className="flex flex-col gap-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-sm font-semibold text-[#94A3B8] font-mono-tabular">
                Active Priorities ({sortedPendingTasks.length})
              </h2>

              <div className="flex flex-wrap items-center gap-2">
                <div
                  role="group"
                  aria-label="Filter tasks by priority"
                  className="flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#101724] p-1"
                >
                  {PRIORITY_FILTERS.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      aria-pressed={priorityFilter === opt.value}
                      onClick={() => setPriorityFilter(opt.value)}
                      className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        priorityFilter === opt.value
                          ? 'bg-[#161F30] text-[#E5C07B]'
                          : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>

                <div
                  role="group"
                  aria-label="Sort tasks by priority"
                  className="flex items-center gap-1 rounded-lg border border-[#24324A] bg-[#101724] p-1"
                >
                  <span className="flex items-center px-1.5 text-[#64748B]" aria-hidden="true">
                    <ArrowUpDown className="h-3.5 w-3.5" />
                  </span>
                  {SORT_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      aria-pressed={sortOrder === opt.value}
                      onClick={() => setSortOrder(opt.value)}
                      className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        sortOrder === opt.value
                          ? 'bg-[#161F30] text-[#E5C07B]'
                          : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  aria-pressed={!showCompleted}
                  onClick={() => setShowCompleted((prev) => !prev)}
                  className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 font-mono-tabular ${
                    showCompleted
                      ? 'border-[#24324A] bg-[#101724] text-[#94A3B8] hover:border-[#E5C07B]/60 hover:text-[#F1F5F9]'
                      : 'border-[#E5C07B]/50 bg-[#161F30] text-[#E5C07B]'
                  }`}
                >
                  {showCompleted ? (
                    <EyeOff className="h-3.5 w-3.5" />
                  ) : (
                    <Eye className="h-3.5 w-3.5" />
                  )}
                  <span>
                    {showCompleted ? 'Hide Completed' : 'Show Completed'} · {completedTasks.length}
                  </span>
                </button>

                {visibleTaskIds.length > 0 && (
                  <button
                    type="button"
                    aria-pressed={allVisibleSelected}
                    onClick={handleToggleSelectAllVisible}
                    className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                      allVisibleSelected
                        ? 'border-[#E5C07B]/60 bg-[#161F30] text-[#E5C07B]'
                        : 'border-[#24324A] bg-[#101724] text-[#94A3B8] hover:border-[#E5C07B]/60 hover:text-[#F1F5F9]'
                    }`}
                  >
                    {allVisibleSelected ? (
                      <CheckSquare className="h-3.5 w-3.5" />
                    ) : (
                      <Square className="h-3.5 w-3.5" />
                    )}
                    <span>{allVisibleSelected ? 'Deselect All' : 'Select All'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Tag Grouping & Filter Bar */}
            <div
              role="group"
              aria-label="Filter tasks by tag"
              className="flex flex-wrap items-center gap-1.5 rounded-xl border border-[#24324A] bg-[#101724] px-3 py-2"
            >
              <span className="inline-flex items-center gap-1.5 pr-1 text-xs font-medium text-[#94A3B8]">
                <Tag className="h-3.5 w-3.5 text-[#38BDF8]" />
                <span>Tag Group</span>
              </span>
              <button
                type="button"
                aria-pressed={selectedTag === 'All'}
                onClick={() => setSelectedTag('All')}
                className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 font-mono-tabular ${
                  selectedTag === 'All'
                    ? 'bg-[#161F30] text-[#E5C07B]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                All Tags · {tasks.length}
              </button>
              <button
                type="button"
                aria-pressed={selectedTag === '__grouped__'}
                onClick={() =>
                  setSelectedTag((prev) => (prev === '__grouped__' ? 'All' : '__grouped__'))
                }
                className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 font-mono-tabular ${
                  selectedTag === '__grouped__'
                    ? 'bg-[#161F30] text-[#E5C07B]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                Grouped by Tag
              </button>
              {tagOptions.length === 0 ? (
                <span className="text-xs text-[#64748B]">
                  Add custom tags to tasks to group related agenda items here.
                </span>
              ) : (
                tagOptions.map((opt) => (
                  <button
                    key={opt.key}
                    type="button"
                    aria-pressed={selectedTag === opt.key}
                    onClick={() =>
                      setSelectedTag((prev) => (prev === opt.key ? 'All' : opt.key))
                    }
                    className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 font-mono-tabular ${
                      selectedTag === opt.key
                        ? 'bg-[#161F30] text-[#E5C07B]'
                        : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                    }`}
                  >
                    #{opt.label} · {opt.total}
                  </button>
                ))
              )}
            </div>

            {/* Bulk Selection Action Bar */}
            {selectedTaskIds.length > 0 && (
              <div
                role="region"
                aria-label="Bulk task actions"
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#E5C07B]/45 bg-[#161F30] px-4 py-2.5"
              >
                <div className="flex items-center gap-2 text-xs font-mono-tabular text-[#E5C07B]">
                  <span className="font-semibold">{selectedTaskIds.length} selected</span>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={isBulkSubmitting}
                    onClick={() => handleBulkToggleIds(selectedTaskIds)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#24324A] bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] transition-colors hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap shrink-0"
                  >
                    <Check className="h-3.5 w-3.5 text-[#E5C07B]" />
                    <span>{isBulkSubmitting ? 'Updating...' : 'Toggle Status'}</span>
                  </button>

                  {selectedPendingIds.length > 0 && (
                    <button
                      type="button"
                      disabled={isBulkSubmitting}
                      onClick={() => handleBulkToggleIds(selectedPendingIds)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-[#34D399]/40 bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#34D399] transition-colors hover:bg-[#080C14] disabled:opacity-40 whitespace-nowrap shrink-0"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Mark Complete ({selectedPendingIds.length})</span>
                    </button>
                  )}

                  {selectedCompletedIds.length > 0 && (
                    <button
                      type="button"
                      disabled={isBulkSubmitting}
                      onClick={() => handleBulkToggleIds(selectedCompletedIds)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-[#38BDF8]/40 bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#38BDF8] transition-colors hover:bg-[#080C14] disabled:opacity-40 whitespace-nowrap shrink-0"
                    >
                      <span>Reopen ({selectedCompletedIds.length})</span>
                    </button>
                  )}

                  <button
                    type="button"
                    disabled={isBulkSubmitting}
                    onClick={() => setConfirmBulkDeleteOpen(true)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#FB7185]/45 bg-[#101724] px-3 py-1.5 text-xs font-medium text-[#FB7185] transition-colors hover:bg-[#FB7185]/10 disabled:opacity-40 whitespace-nowrap shrink-0"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete Selected</span>
                  </button>

                  <button
                    type="button"
                    disabled={isBulkSubmitting}
                    onClick={() => setSelectedTaskIds([])}
                    aria-label="Clear selection"
                    className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-[#94A3B8] hover:text-[#F1F5F9]"
                  >
                    <X className="h-3.5 w-3.5" />
                    <span>Clear</span>
                  </button>
                </div>
              </div>
            )}

            {sortedPendingTasks.length === 0 ? (
              <div className="rounded-xl border border-dashed border-[#24324A] bg-[#101724] p-8 text-center">
                <p className="text-sm text-[#F1F5F9]">
                  {normalizedQuery
                    ? `No active tasks match "${searchQuery}".`
                    : selectedTag !== 'All' && selectedTag !== '__grouped__'
                      ? `No active tasks tagged "#${tagOptions.find((t) => t.key === selectedTag)?.label ?? selectedTag}".`
                      : priorityFilter === 'All'
                        ? 'Your agenda is clear.'
                        : `No ${getPriorityLabel(priorityFilter)} priority tasks pending.`}
                </p>
                <p className="mt-1 text-xs text-[#94A3B8]">
                  {normalizedQuery ||
                  priorityFilter !== 'All' ||
                  (selectedTag !== 'All' && selectedTag !== '__grouped__')
                    ? 'Clear your filters or add a new task above.'
                    : 'Add a focus item above or ask PRIME in chat to schedule tasks for you.'}
                </p>
                {(normalizedQuery || priorityFilter !== 'All' || selectedTag !== 'All') && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setPriorityFilter('All');
                      setSelectedTag('All');
                    }}
                    className="mt-3 rounded-lg border border-[#24324A] bg-[#161F30] px-3.5 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B]"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            ) : selectedTag === '__grouped__' ? (
              <div className="flex flex-col gap-5">
                {groupedPendingSections.map((group) => (
                  <div key={group.key} className="flex flex-col gap-2">
                    <div className="flex items-center justify-between border-b border-[#24324A] pb-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          if (group.key !== '__untagged__') setSelectedTag(group.key);
                        }}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#38BDF8] font-mono-tabular hover:text-[#E5C07B]"
                      >
                        <Tag className="h-3.5 w-3.5" />
                        <span>{group.label}</span>
                      </button>
                      <span className="text-xs font-mono-tabular text-[#64748B]">
                        {group.tasks.length} {group.tasks.length === 1 ? 'task' : 'tasks'}
                      </span>
                    </div>
                    <div className="flex flex-col gap-2.5">
                      {group.tasks.map((task) => {
                        const isSelected = selectedSet.has(task.id);
                        const isExpanded = !!expandedTaskIds[task.id];
                        const resolvedDueMs = resolveTaskDueMs(task);
                        const overdue = isTaskOverdue(task, nowMs);
                        const subTasks = task.subTasks ?? [];
                        const completedSubs = subTasks.filter((s) => s.isCompleted).length;

                        return (
                          <div
                            key={`${group.key}_${task.id}`}
                            className={`relative rounded-xl border px-4 py-3.5 transition-colors ${
                              overdue
                                ? 'border-[#FB7185]/70 border-l-4 border-l-[#FB7185] bg-[#FB7185]/[0.06] hover:bg-[#FB7185]/[0.10]'
                                : isSelected
                                  ? 'border-[#E5C07B]/60 bg-[#161F30]'
                                  : 'border-[#24324A] bg-[#101724] hover:bg-[#161F30]'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-4">
                              <div className="flex items-start gap-2.5 min-w-0">
                                <button
                                  type="button"
                                  role="checkbox"
                                  aria-checked={isSelected}
                                  aria-label={`Select "${task.title}"`}
                                  onClick={() => toggleSelectTask(task.id)}
                                  className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors ${
                                    isSelected
                                      ? 'border-[#E5C07B] bg-[#E5C07B] text-[#080C14]'
                                      : 'border-[#334155] bg-[#080C14] text-transparent hover:border-[#E5C07B]/70'
                                  }`}
                                >
                                  <Check className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => onToggleTask(task.id)}
                                  aria-label={`Mark "${task.title}" complete`}
                                  className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-[#24324A] bg-[#080C14] text-transparent transition-colors hover:border-[#34D399]"
                                >
                                  <Check className="h-3 w-3" />
                                </button>
                                <div className="min-w-0">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <p className="text-sm font-medium text-[#F1F5F9]">{task.title}</p>
                                    {(task.status === 'failed' || task.lastError) && (
                                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#FB7185]">
                                        <AlertTriangle className="h-3.5 w-3.5" />
                                        <span>Failed</span>
                                      </span>
                                    )}
                                    {overdue && (
                                      <span className="inline-flex items-center gap-1 rounded border border-[#FB7185]/60 bg-[#FB7185]/15 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-[#FB7185]">
                                        <AlertTriangle className="h-3 w-3" />
                                        <span>Overdue</span>
                                      </span>
                                    )}
                                  </div>
                                  {(task.tags ?? []).length > 0 && (
                                    <div
                                      className="mt-1.5 flex flex-wrap items-center gap-1.5"
                                      aria-label="Task tags"
                                    >
                                      {(task.tags ?? []).map((tag) => {
                                        const tagKey = tag.trim().toLowerCase();
                                        const active = selectedTag === tagKey;
                                        return (
                                          <button
                                            key={tag}
                                            type="button"
                                            aria-pressed={active}
                                            onClick={() =>
                                              setSelectedTag((prev) =>
                                                prev === tagKey ? 'All' : tagKey,
                                              )
                                            }
                                            className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium font-mono-tabular transition-colors ${
                                              active
                                                ? 'border-[#E5C07B] bg-[#E5C07B]/15 text-[#E5C07B]'
                                                : 'border-[#38BDF8]/35 bg-[#38BDF8]/10 text-[#38BDF8] hover:border-[#E5C07B]/60 hover:text-[#E5C07B]'
                                            }`}
                                          >
                                            #{tag}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  )}
                                  <p className="mt-1 text-xs text-[#94A3B8] font-mono-tabular">
                                    <span
                                      className={
                                        task.priority === 'High'
                                          ? 'text-[#E5C07B]'
                                          : task.priority === 'Low'
                                            ? 'text-[#64748B]'
                                            : 'text-[#38BDF8]'
                                      }
                                    >
                                      {getPriorityLabel(task.priority)}
                                    </span>
                                    {task.dueNote ? ` · ${task.dueNote}` : ''}
                                    {resolvedDueMs !== null && (
                                      <span className={overdue ? ' text-[#FB7185]' : ' text-[#E5C07B]'}>
                                        {` · ${formatRemainingTime(resolvedDueMs, nowMs)}`}
                                      </span>
                                    )}
                                    {subTasks.length > 0
                                      ? ` · ${completedSubs}/${subTasks.length} sub-tasks`
                                      : ''}
                                    {` · Added ${formatDateLabel(task.createdAtMs)}`}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                {(overdue || task.status === 'failed' || Boolean(task.lastError)) &&
                                  onRetryTask && (
                                    <button
                                      type="button"
                                      onClick={() => void onRetryTask(task.id)}
                                      title="Do this task again and reschedule timer"
                                      aria-label={`Do again "${task.title}"`}
                                      className="inline-flex items-center gap-1 rounded-lg border border-[#FB7185]/50 bg-[#080C14] px-2.5 py-1 text-xs font-semibold text-[#FB7185] transition-colors hover:border-[#FB7185] whitespace-nowrap"
                                    >
                                      <RotateCcw className="h-3.5 w-3.5" />
                                      <span>Do Again</span>
                                    </button>
                                  )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelectedTag(group.key === '__untagged__' ? 'All' : group.key);
                                    toggleExpandTask(task);
                                  }}
                                  aria-expanded={isExpanded}
                                  aria-label={
                                    isExpanded ? `Collapse "${task.title}"` : `Expand "${task.title}"`
                                  }
                                  className="rounded-lg p-1.5 text-[#94A3B8] transition-colors hover:bg-[#080C14] hover:text-[#E5C07B]"
                                >
                                  {isExpanded ? (
                                    <ChevronUp className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => onDeleteTask(task.id)}
                                  aria-label={`Delete "${task.title}"`}
                                  className="rounded-lg p-1.5 text-[#64748B] transition-colors hover:bg-[#080C14] hover:text-[#FB7185]"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {sortedPendingTasks.map((task) => {
                  const isSelected = selectedSet.has(task.id);
                  const isDragging = draggedTaskId === task.id;
                  const isDragBefore =
                    dragOverTarget?.id === task.id && dragOverTarget.position === 'before';
                  const isDragAfter =
                    dragOverTarget?.id === task.id && dragOverTarget.position === 'after';
                  const isExpanded = !!expandedTaskIds[task.id];
                  const resolvedDueMs = resolveTaskDueMs(task);
                  const overdue = isTaskOverdue(task, nowMs);
                  const subTasks = task.subTasks ?? [];
                  const completedSubs = subTasks.filter((s) => s.isCompleted).length;

                  return (
                    <div
                      key={task.id}
                      draggable={!isBulkSubmitting && sortedPendingTasks.length > 1 && !isExpanded}
                      onDragStart={(ev) => {
                        setDraggedTaskId(task.id);
                        ev.dataTransfer.effectAllowed = 'move';
                        ev.dataTransfer.setData('text/plain', task.id);
                      }}
                      onDragOver={(ev) => {
                        if (!draggedTaskId || draggedTaskId === task.id) return;
                        ev.preventDefault();
                        ev.dataTransfer.dropEffect = 'move';
                        const rect = ev.currentTarget.getBoundingClientRect();
                        const position =
                          ev.clientY < rect.top + rect.height / 2 ? 'before' : 'after';
                        if (
                          dragOverTarget?.id !== task.id ||
                          dragOverTarget.position !== position
                        ) {
                          setDragOverTarget({id: task.id, position});
                        }
                      }}
                      onDragLeave={(ev) => {
                        if (!ev.currentTarget.contains(ev.relatedTarget as Node)) {
                          setDragOverTarget((prev) => (prev?.id === task.id ? null : prev));
                        }
                      }}
                      onDrop={(ev) => {
                        ev.preventDefault();
                        const rect = ev.currentTarget.getBoundingClientRect();
                        const position =
                          ev.clientY < rect.top + rect.height / 2 ? 'before' : 'after';
                        handleDropOnTask(task.id, position);
                      }}
                      onDragEnd={() => {
                        setDraggedTaskId(null);
                        setDragOverTarget(null);
                      }}
                      className={`relative rounded-xl border px-4 py-3.5 transition-colors ${
                        isDragging
                          ? 'opacity-45 border-[#E5C07B]/50 bg-[#161F30]'
                          : overdue
                            ? 'border-[#FB7185]/70 border-l-4 border-l-[#FB7185] bg-[#FB7185]/[0.06] hover:bg-[#FB7185]/[0.10]'
                            : isSelected
                              ? 'border-[#E5C07B]/60 bg-[#161F30]'
                              : 'border-[#24324A] bg-[#101724] hover:bg-[#161F30]'
                      } ${
                        isDragBefore
                          ? 'border-t-2 border-t-[#E5C07B]'
                          : isDragAfter
                            ? 'border-b-2 border-b-[#E5C07B]'
                            : ''
                      }`}
                    >
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <button
                            type="button"
                            onKeyDown={(ev) => {
                              if (ev.key === 'ArrowUp') {
                                ev.preventDefault();
                                handleStepTaskOrder(task.id, -1);
                              } else if (ev.key === 'ArrowDown') {
                                ev.preventDefault();
                                handleStepTaskOrder(task.id, 1);
                              }
                            }}
                            aria-label={`Drag to reorder "${task.title}" (or use Up/Down arrow keys)`}
                            title="Drag to reorder (or focus and press Up/Down arrows)"
                            className="mt-0.5 flex h-5 w-4 shrink-0 cursor-grab items-center justify-center rounded text-[#475569] transition-colors hover:text-[#E5C07B] active:cursor-grabbing focus-visible:outline-1 focus-visible:outline-[#E5C07B]"
                          >
                            <GripVertical className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            role="checkbox"
                            aria-checked={isSelected}
                            aria-label={`Select "${task.title}"`}
                            onClick={() => toggleSelectTask(task.id)}
                            className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors ${
                              isSelected
                                ? 'border-[#E5C07B] bg-[#E5C07B] text-[#080C14]'
                                : 'border-[#334155] bg-[#080C14] text-transparent hover:border-[#E5C07B]/70'
                            }`}
                          >
                            <Check className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onToggleTask(task.id)}
                            aria-label={`Mark "${task.title}" complete`}
                            className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-[#24324A] bg-[#080C14] text-transparent transition-colors hover:border-[#34D399]"
                          >
                            <Check className="h-3 w-3" />
                          </button>
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <p className="text-sm font-medium text-[#F1F5F9]">{task.title}</p>
                              {(task.status === 'failed' || task.lastError) && (
                                <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#FB7185]">
                                  <AlertTriangle className="h-3.5 w-3.5" />
                                  <span>Failed</span>
                                </span>
                              )}
                              {overdue && (
                                <span className="inline-flex items-center gap-1 rounded border border-[#FB7185]/60 bg-[#FB7185]/15 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-[#FB7185]">
                                  <AlertTriangle className="h-3 w-3" />
                                  <span>Overdue</span>
                                </span>
                              )}
                            </div>
                            {(task.tags ?? []).length > 0 && (
                              <div
                                className="mt-1.5 flex flex-wrap items-center gap-1.5"
                                aria-label="Task tags"
                              >
                                {(task.tags ?? []).map((tag) => {
                                  const tagKey = tag.trim().toLowerCase();
                                  const active = selectedTag === tagKey;
                                  return (
                                    <button
                                      key={tag}
                                      type="button"
                                      aria-pressed={active}
                                      onClick={() =>
                                        setSelectedTag((prev) =>
                                          prev === tagKey ? 'All' : tagKey,
                                        )
                                      }
                                      className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium font-mono-tabular transition-colors ${
                                        active
                                          ? 'border-[#E5C07B] bg-[#E5C07B]/15 text-[#E5C07B]'
                                          : 'border-[#38BDF8]/35 bg-[#38BDF8]/10 text-[#38BDF8] hover:border-[#E5C07B]/60 hover:text-[#E5C07B]'
                                      }`}
                                    >
                                      #{tag}
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                            {task.lastError && (
                              <p className="mt-0.5 text-xs text-[#FB7185]">{task.lastError}</p>
                            )}
                            <p className="mt-1 text-xs text-[#94A3B8] font-mono-tabular">
                              <span
                                className={
                                  task.priority === 'High'
                                    ? 'text-[#E5C07B]'
                                    : task.priority === 'Low'
                                      ? 'text-[#64748B]'
                                      : 'text-[#38BDF8]'
                                }
                              >
                                {getPriorityLabel(task.priority)}
                              </span>
                              {task.dueNote ? ` · ${task.dueNote}` : ''}
                              {resolvedDueMs !== null && (
                                <span className={overdue ? ' text-[#FB7185]' : ' text-[#E5C07B]'}>
                                  {` · ${formatRemainingTime(resolvedDueMs, nowMs)}`}
                                </span>
                              )}
                              {task.autoStartOnDue ? ' · Auto-start' : ''}
                              {task.retryCount && task.retryCount > 0
                                ? ` · Retried ${task.retryCount}x`
                                : ''}
                              {subTasks.length > 0
                                ? ` · ${completedSubs}/${subTasks.length} sub-tasks`
                                : ''}
                              {task.notes ? ' · Notes' : ''}
                              {` · Added ${formatDateLabel(task.createdAtMs)}`}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {(overdue || task.status === 'failed' || Boolean(task.lastError)) &&
                            onRetryTask && (
                              <button
                                type="button"
                                onClick={() => void onRetryTask(task.id)}
                                title="Do this task again and reschedule timer"
                                aria-label={`Do again "${task.title}"`}
                                className="inline-flex items-center gap-1 rounded-lg border border-[#FB7185]/50 bg-[#080C14] px-2.5 py-1 text-xs font-semibold text-[#FB7185] transition-colors hover:border-[#FB7185] whitespace-nowrap"
                              >
                                <RotateCcw className="h-3.5 w-3.5" />
                                <span>Do Again</span>
                              </button>
                            )}
                          <button
                            type="button"
                            onClick={() => toggleExpandTask(task)}
                            aria-expanded={isExpanded}
                            aria-label={isExpanded ? `Collapse "${task.title}"` : `Expand "${task.title}"`}
                            className="rounded-lg p-1.5 text-[#94A3B8] transition-colors hover:bg-[#080C14] hover:text-[#E5C07B]"
                          >
                            {isExpanded ? (
                              <ChevronUp className="h-4 w-4" />
                            ) : (
                              <ChevronDown className="h-4 w-4" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteTask(task.id)}
                            aria-label={`Delete "${task.title}"`}
                            className="rounded-lg p-1.5 text-[#64748B] transition-colors hover:bg-[#080C14] hover:text-[#FB7185]"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>

                      {/* Expandable Sub-Tasks, Notes & Time-Limit Auto-Start Controls */}
                      {isExpanded && (
                        <div className="mt-3 flex flex-col gap-3 border-t border-[#24324A] pt-3 pl-7">
                          {/* Sub-tasks checklist */}
                          <div>
                            <p className="mb-1.5 text-xs font-medium text-[#94A3B8]">
                              Sub-tasks ({completedSubs}/{subTasks.length})
                            </p>
                            {subTasks.length > 0 && (
                              <div className="mb-2 flex flex-col gap-1.5">
                                {subTasks.map((sub) => (
                                  <div
                                    key={sub.id}
                                    className="flex items-center justify-between gap-2 rounded-lg border border-[#24324A]/70 bg-[#080C14] px-2.5 py-1.5"
                                  >
                                    <button
                                      type="button"
                                      onClick={() => handleToggleSubTask(task, sub.id)}
                                      className="flex items-center gap-2 min-w-0 text-left"
                                    >
                                      <span
                                        className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                                          sub.isCompleted
                                            ? 'border-[#34D399] bg-[#34D399]/20 text-[#34D399]'
                                            : 'border-[#334155] text-transparent'
                                        }`}
                                      >
                                        <Check className="h-2.5 w-2.5" />
                                      </span>
                                      <span
                                        className={`truncate text-xs ${
                                          sub.isCompleted
                                            ? 'text-[#64748B] line-through'
                                            : 'text-[#F1F5F9]'
                                        }`}
                                      >
                                        {sub.title}
                                      </span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteSubTask(task, sub.id)}
                                      aria-label={`Remove sub-task "${sub.title}"`}
                                      className="text-[#64748B] hover:text-[#FB7185]"
                                    >
                                      <X className="h-3.5 w-3.5" />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            )}
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={subTaskDrafts[task.id] ?? ''}
                                onChange={(ev) =>
                                  setSubTaskDrafts((prev) => ({
                                    ...prev,
                                    [task.id]: ev.target.value,
                                  }))
                                }
                                onKeyDown={(ev) => {
                                  if (ev.key === 'Enter') {
                                    ev.preventDefault();
                                    handleAddSubTask(task);
                                  }
                                }}
                                placeholder="Add a sub-task..."
                                className="flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                              />
                              <button
                                type="button"
                                onClick={() => handleAddSubTask(task)}
                                disabled={!(subTaskDrafts[task.id] ?? '').trim()}
                                className="rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40"
                              >
                                Add
                              </button>
                            </div>
                          </div>

                          {/* Detailed Notes */}
                          <div>
                            <div className="mb-1 flex items-center justify-between gap-2">
                              <label className="text-xs font-medium text-[#94A3B8]">
                                Detailed Notes
                              </label>
                              <button
                                type="button"
                                onClick={() => handleSaveTaskNotes(task)}
                                className="text-xs font-medium text-[#E5C07B] hover:underline"
                              >
                                Save Notes
                              </button>
                            </div>
                            <textarea
                              rows={2}
                              value={noteDrafts[task.id] ?? task.notes ?? ''}
                              onChange={(ev) =>
                                setNoteDrafts((prev) => ({...prev, [task.id]: ev.target.value}))
                              }
                              placeholder="Add detailed context, links, or checklist notes..."
                              className="w-full rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-xs leading-relaxed text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                            />
                          </div>

                          {/* Due limit & Auto-start toggle */}
                          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#24324A]/60 pt-2 text-xs">
                            <div className="flex items-center gap-2">
                              <Clock className="h-3.5 w-3.5 text-[#94A3B8]" />
                              <input
                                type="datetime-local"
                                value={toDatetimeLocalValue(task.dueAtMs)}
                                onChange={(ev) => {
                                  const nextMs = ev.target.value
                                    ? Date.parse(ev.target.value)
                                    : null;
                                  onUpdateTaskDetails(task.id, {
                                    dueAtMs:
                                      nextMs !== null && Number.isFinite(nextMs) ? nextMs : null,
                                  });
                                }}
                                className="rounded border border-[#24324A] bg-[#080C14] px-2.5 py-1 text-xs text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
                              />
                            </div>

                            <label className="inline-flex cursor-pointer items-center gap-2 text-xs text-[#94A3B8]">
                              <input
                                type="checkbox"
                                checked={!!task.autoStartOnDue}
                                onChange={(ev) =>
                                  onUpdateTaskDetails(task.id, {
                                    autoStartOnDue: ev.target.checked,
                                  })
                                }
                                className="h-3.5 w-3.5 rounded border-[#24324A] bg-[#080C14] accent-[#E5C07B]"
                              />
                              <span>
                                Auto-start when time limit over
                                {task.autoStartedAtMs ? ' (Triggered)' : ''}
                              </span>
                            </label>
                          </div>

                          {/* Custom Tags Editor */}
                          <div className="border-t border-[#24324A]/60 pt-2.5">
                            <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2">
                              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#94A3B8]">
                                <Tag className="h-3.5 w-3.5 text-[#38BDF8]" />
                                <span>Tags</span>
                              </span>
                              {(task.tags ?? []).length > 0 && (
                                <div className="flex flex-wrap items-center gap-2 text-xs font-mono-tabular">
                                  {(task.tags ?? []).map((tag, idx) => (
                                    <span key={tag} className="inline-flex items-center gap-1 text-[#38BDF8]">
                                      {idx > 0 ? <span className="text-[#475569]">·</span> : null}
                                      <span>#{tag}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleRemoveTaskTag(task, tag)}
                                        aria-label={`Remove tag "${tag}"`}
                                        className="text-[#64748B] hover:text-[#FB7185]"
                                      >
                                        <X className="h-3 w-3" />
                                      </button>
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={tagDrafts[task.id] ?? ''}
                                onChange={(ev) =>
                                  setTagDrafts((prev) => ({
                                    ...prev,
                                    [task.id]: ev.target.value,
                                  }))
                                }
                                onKeyDown={(ev) => {
                                  if (ev.key === 'Enter') {
                                    ev.preventDefault();
                                    handleAddTaskTags(task);
                                  }
                                }}
                                placeholder="Add tags (comma-separated)..."
                                className="flex-1 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-1.5 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
                              />
                              <button
                                type="button"
                                onClick={() => handleAddTaskTags(task)}
                                disabled={!(tagDrafts[task.id] ?? '').trim()}
                                className="rounded-lg border border-[#24324A] bg-[#161F30] px-3 py-1.5 text-xs font-medium text-[#E5C07B] hover:border-[#E5C07B] disabled:opacity-40 whitespace-nowrap"
                              >
                                Add Tag
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Completed Tasks */}
          {showCompleted && completedTasks.length > 0 && (
            <section className="flex flex-col gap-2.5 pt-2">
              <h2 className="font-display text-sm font-semibold text-[#64748B]">
                Completed ({completedTasks.length})
              </h2>
              {completedTasks.map((task) => {
                const isSelected = selectedSet.has(task.id);
                return (
                  <div
                    key={task.id}
                    className={`flex items-center justify-between gap-4 rounded-xl border px-4 py-3 transition-colors ${
                      isSelected
                        ? 'border-[#E5C07B]/60 bg-[#161F30]'
                        : 'border-[#24324A]/60 bg-[#101724]/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <button
                        type="button"
                        role="checkbox"
                        aria-checked={isSelected}
                        aria-label={`Select "${task.title}"`}
                        onClick={() => toggleSelectTask(task.id)}
                        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors ${
                          isSelected
                            ? 'border-[#E5C07B] bg-[#E5C07B] text-[#080C14]'
                            : 'border-[#334155] bg-[#080C14] text-transparent hover:border-[#E5C07B]/70'
                        }`}
                      >
                        <Check className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onToggleTask(task.id)}
                        aria-label={`Reopen "${task.title}"`}
                        className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-[#34D399]/60 bg-[#34D399]/15 text-[#34D399]"
                      >
                        <Check className="h-3 w-3" />
                      </button>
                      <div className="min-w-0">
                        <p className="truncate text-sm text-[#64748B] line-through">{task.title}</p>
                        {(task.tags ?? []).length > 0 && (
                          <div
                            className="mt-1 flex flex-wrap items-center gap-1.5"
                            aria-label="Completed task tags"
                          >
                            {(task.tags ?? []).map((tag) => {
                              const tagKey = tag.trim().toLowerCase();
                              const active = selectedTag === tagKey;
                              return (
                                <button
                                  key={tag}
                                  type="button"
                                  aria-pressed={active}
                                  onClick={() =>
                                    setSelectedTag((prev) => (prev === tagKey ? 'All' : tagKey))
                                  }
                                  className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-medium font-mono-tabular transition-colors ${
                                    active
                                      ? 'border-[#E5C07B] bg-[#E5C07B]/15 text-[#E5C07B]'
                                      : 'border-[#24324A] bg-[#080C14] text-[#64748B] hover:border-[#38BDF8]/50 hover:text-[#38BDF8]'
                                  }`}
                                >
                                  #{tag}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onDeleteTask(task.id)}
                      aria-label={`Delete "${task.title}"`}
                      className="rounded-lg p-1.5 text-[#64748B] transition-colors hover:text-[#FB7185]"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                );
              })}
            </section>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-5">
          {/* Add Memory Form */}
          <form
            onSubmit={handleMemorySubmit}
            className="rounded-xl border border-[#24324A] bg-[#101724] p-5"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-sm font-semibold text-[#F1F5F9]">
                Store Permanent Memory
              </h2>
              {memories.length > 0 && (
                <button
                  type="button"
                  onClick={() => setConfirmClearOpen(true)}
                  className="text-xs font-medium text-[#FB7185] hover:underline"
                >
                  Clear Vault
                </button>
              )}
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-12">
              <select
                value={memCategory}
                onChange={(ev) => setMemCategory(ev.target.value as MemoryItem['category'])}
                className="md:col-span-3 rounded-lg border border-[#24324A] bg-[#080C14] px-3 py-2 text-sm text-[#F1F5F9] focus:border-[#E5C07B] focus:outline-none"
              >
                {MEMORY_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={memFact}
                onChange={(ev) => setMemFact(ev.target.value)}
                placeholder="E.g., I prefer concise executive briefs at 8 AM..."
                className="md:col-span-7 rounded-lg border border-[#24324A] bg-[#080C14] px-3.5 py-2 text-sm text-[#F1F5F9] placeholder-[#64748B] focus:border-[#E5C07B] focus:outline-none"
              />
              <button
                type="submit"
                disabled={!memFact.trim() || isSubmittingMem}
                className="md:col-span-2 inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#E5C07B] px-4 py-2 text-sm font-semibold text-[#080C14] transition-colors hover:bg-[#ECCE93] disabled:opacity-40 whitespace-nowrap"
              >
                <Plus className="h-4 w-4" />
                <span>Save Fact</span>
              </button>
            </div>
          </form>

          {/* Memory list */}
          {memories.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[#24324A] bg-[#101724] p-8 text-center">
              <p className="text-sm text-[#F1F5F9]">No saved memories yet.</p>
              <p className="mt-1 text-xs text-[#94A3B8]">
                Tell PRIME your preferences or goals in chat, or add a permanent fact above.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              {memories.map((mem) => (
                <article
                  key={mem.id}
                  className="flex items-start justify-between gap-3 rounded-xl border border-[#24324A] bg-[#101724] p-4"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-[#E5C07B] font-mono-tabular">
                      {mem.category} · {formatDateLabel(mem.createdAtMs)}
                    </p>
                    <p className="mt-1.5 text-sm leading-relaxed text-[#F1F5F9]">{mem.fact}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteMemory(mem.id)}
                    aria-label="Delete memory"
                    className="rounded-lg p-1.5 text-[#64748B] transition-colors hover:bg-[#161F30] hover:text-[#FB7185]"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </article>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Bulk Delete Tasks Confirmation Modal */}
      {confirmBulkDeleteOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        >
          <div className="w-full max-w-md rounded-xl border border-[#24324A] bg-[#101724] p-6">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Delete {selectedTaskIds.length} Selected{' '}
              {selectedTaskIds.length === 1 ? 'Task' : 'Tasks'}?
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
              This will permanently remove {selectedTaskIds.length}{' '}
              {selectedTaskIds.length === 1 ? 'task' : 'tasks'} from your PRIME Agenda. This action
              cannot be undone.
            </p>
            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                disabled={isBulkSubmitting}
                onClick={() => setConfirmBulkDeleteOpen(false)}
                className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-sm font-medium text-[#F1F5F9] hover:border-[#94A3B8] disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isBulkSubmitting}
                onClick={handleConfirmBulkDelete}
                className="rounded-lg bg-[#FB7185] px-4 py-2 text-sm font-semibold text-[#080C14] hover:opacity-90 disabled:opacity-40"
              >
                {isBulkSubmitting ? 'Deleting...' : `Delete ${selectedTaskIds.length}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear Vault Confirmation Modal */}
      {confirmClearOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
        >
          <div className="w-full max-w-md rounded-xl border border-[#24324A] bg-[#101724] p-6">
            <h3 className="font-display text-lg font-semibold text-[#F1F5F9]">
              Clear Memory Vault?
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-[#94A3B8]">
              This will permanently remove all {memories.length} remembered facts from PRIME&apos;s
              long-term memory. Your agenda tasks and saved custom voices will remain intact.
            </p>
            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmClearOpen(false)}
                className="rounded-lg border border-[#24324A] bg-[#161F30] px-4 py-2 text-sm font-medium text-[#F1F5F9] hover:border-[#94A3B8]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={async () => {
                  await onClearMemories();
                  setConfirmClearOpen(false);
                }}
                className="rounded-lg bg-[#FB7185] px-4 py-2 text-sm font-semibold text-[#080C14] hover:opacity-90"
              >
                Clear All Memories
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
